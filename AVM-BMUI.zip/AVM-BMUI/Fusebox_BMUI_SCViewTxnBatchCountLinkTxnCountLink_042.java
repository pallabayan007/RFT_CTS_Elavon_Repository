
import java.io.File;

import resources.Fusebox_BMUI_SCViewTxnBatchCountLinkTxnCountLink_042Helper;
import Driver.DriverScript;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class Fusebox_BMUI_SCViewTxnBatchCountLinkTxnCountLink_042 extends Fusebox_BMUI_SCViewTxnBatchCountLinkTxnCountLink_042Helper
{
	/**
	 * Script Name   : <b>Fusebox_BMUI_SCViewTxnBatchCountLinkTxnCountLink_042</b>
	 * Generated     : <b>Feb 2, 2012 6:11:29 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/02/02
	 * @author sxghos1
	 */
	
	public static int iteration =0;
	public static int subiteration = 1;
	public static String testcase=""; 
	public static String desc = null;	
	public static boolean error = false;
	String businessComponent="";
	long iterationCount = 0;
	boolean skipKeyword = false;
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
//		String[] bc = new String[1];
		
		//To run a TestCase directly, give Scenario, test case, description, iteration start, and iteration end.
//		String Scenario = "Scenario3";
		testcase = this.getClass().getName();
		desc ="desc";
//		int start = 1;
//		int end =1;
		
		String path = Util.homePath;
//		String dbpath =path+"\\Datatables\\"+Scenario+".xls";
//		Util.timestamp = "Run_"+Util.getCurrentDatenTime("dd-MM-yy")+"_"+Util.getCurrentDatenTime("H-mm-ss a");
		String resultPath = path+"\\Results\\"+Util.timestamp;
//		String ExcelResPath = resultPath+"\\Excel Results";
		Util.HtmlScenarioResPath = resultPath+"\\HTML Results\\"+testcase;
//		String RFTResPath = resultPath+"\\RFT Results";
//		String ScreenshotsPath = resultPath+"\\Screenshots";
		
		error = false;
//		String onError = Util.GetValue("OnError", "NextTestCase");
		
		//This section is created for RQM initiated execution only
		try{
			if(Util.isRQMExecution){
				Util.isRQMRunmanager = true;
				DriverScript.isRQMExecDriver = true;
				logInfo("Testing through RQM");				
//				logInfo(""+args.length+args[0].toString()+"");				
	      		if(args.length>0){
	      			Util.setDatatable(testcase,args[0].toString());
	      		}
	      		else{
	      			Util.setDatatable(testcase,"");
	      		}
	      		callScript("Driver.DriverScript");
	      		return;
	      	}
		}
		catch(Exception e){
			logInfo(e.getMessage());
		}		
		//End of section is created for RQM initiated execution only
		
//		System.out.println(RFTResPath);
		
		try 
		{        
//			new File(ExcelResPath).mkdirs();
//			new File(Util.HtmslScenarioResPath).mkdirs();
//			new File(RFTResPath).mkdirs();
			new File(Util.screenshotPath).mkdirs();
//			CRAFT_Report.createTestcaseHeader(Util.indvResPath+"\\"+testcase+".html", Util.screenshotPath);
		}
		catch(Exception ex){}	
		
		
		
		try{
			//Iterating through the data pool
			CRAFT_Report.insertScenario(testcase);
			CRAFT_Report.LogInfo("Start Scenario","Invoking Scenario: "+testcase,Status.DONE);
			while(!dpDone()){
				Util.skipKeyword = false;
				skipKeyword = false;
				iterationCount++;
//				CRAFT_Report.createTestcaseHeader(Util.HtmlScenarioResPath+"\\"+testcase+".html", ExcelResPath+"\\"+testcase+".xls",ScreenshotsPath);
				CRAFT_Report.insertIteration((int)iterationCount);				
				
				//Calling business component user log on
				businessComponent = "Business_Components.UserLogon";
				String[] userId = new String[2];
				userId[0] = dpString("User ID");
				userId[1] = dpString("Password");
				callScript(businessComponent,userId);
				//---------End of business component---------
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
				
				if(!skipKeyword){
					//Calling business component Gateway BMUI Hierarchy Choice
					businessComponent = "Business_Components.GatewayBMUIHierarchyChoice";	
					String[] gateHeir = new String[2];
					gateHeir[0] = dpString("Hierarchy Name");
					gateHeir[1] = dpString("View");
					callScript(businessComponent,gateHeir);
					//---------End of business component---------
				}
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
				
				if(!skipKeyword){
					//Calling business component SCBatchListThruIncGBSBatchCountLink
					businessComponent = "Business_Components.SCBatchListThruIncGBSBatchCountLink";	
					String[] batchStatusPOS = new String[2];
					batchStatusPOS[0] = dpString("Batch Status POS Count Link");
					batchStatusPOS[1] = dpString("Batch Stage");
					
					callScript(businessComponent,batchStatusPOS);
					//---------End of business component---------
				}
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}				
				
				if(!skipKeyword){
					//Calling business component ClickTxnCount
					businessComponent = "Business_Components.ClickTxnCount";	
					String[] clickTxnCount = new String[2];
					clickTxnCount[0] = dpString("Batch Status");
					clickTxnCount[1] = dpString("System Batch Row No");				
					
					callScript(businessComponent,clickTxnCount);				
					//---------End of business component---------
				}
				
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
				
				if(!skipKeyword){
					//Calling business component View Txn
					businessComponent = "Business_Components.ViewTxn";	
					String[] viewTxn = new String[1];
					viewTxn[0] = dpString("Reference No");
					
					callScript(businessComponent,viewTxn);				
					//---------End of business component---------
				}
				
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
				
				if(!skipKeyword){
					//Calling business component user log off
					businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
				}
				
				
				//Scenario end report
				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
				
				//Check for single or multiple iteration
				if(!Util.allIterationReq){
					break;
				}//End of if for single or multiple iterations
				else{
					dpNext();
				}//End of else for single or multiple iterations				
				
			}//End data pool iteration	
			
//			//Scenario end report
//			if(!error && !CRAFT_Report.error
//					  && Util.scenarioStatus)
//			{
//				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
//			}
//			else
//			{
////				reportError(onError);
//				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
//			}
			
		}//End of try for scenario execution
		catch(Exception ex){
			ex.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing scenario: "+testcase,ex.toString(),Status.BC_FAILED);
			//Calling business component user log off
			String businessComponent = "Business_Components.UserLogoff";			
			callScript(businessComponent);
			//---------End of business component---------
		
		}//End of catch for scenario execution		
		finally{
			//Reseting the run manager to false in case it is initiated by RQM
			if(Util.isRQMRunmanager){
				Util.resetDatatable(testcase);
				Util.isRQMExecution = true;
				Util.isRQMRunmanager = false;
			}
		}  
//		return bc;
		
		
	}//End of testMain()
	
}//End of class


