package Driver;

import resources.Driver.DriverScriptHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import java.io.*;
import java.net.InetAddress;

import ApplicationProperties.EnvironmentVariables;
import SupportLibraries.*;
import SupportLibraries.CRAFT_Report.Status;
import java.sql.*;
import java.util.*;
import java.util.Date;

import javax.sql.rowset.CachedRowSet;
import javax.swing.JOptionPane;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;


/**
 * Description   : Functional Test Script
 * @author 
 */
public class DriverScript extends DriverScriptHelper
{
	/**
	 * Script Name   : <b>DriverScript</b>
	 * Generated     : <b>Mar 6, 2009 2:55:47 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  
	 * @author 163497, 163392
	 */
	public static int iteration =0;
	public static int subiteration = 1;
	public static String testcase=""; 
	public static String desc = null;
	public static String indvTS = "";
	public static boolean error = false;
	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	String HtmlResPath= "";
	String scenarioName = "";
	int runmanagerSize = 0;
	public static boolean isRQMExecDriver = false;
	String computername = "";
	String craftReportLink = "";
	//Count variable for passed and failed Test Scripts
	ArrayList<String> array_ExecutedTS = new ArrayList<String>();
	ArrayList<String> array_NotExecutedTS = new ArrayList<String>();
	ArrayList<String> array_PassedTS = new ArrayList<String>();
	ArrayList<String> array_FailedTS = new ArrayList<String>();
	ArrayList<String> array_tsExecTime = new ArrayList<String>();
	ArrayList<String> array_tsId = new ArrayList<String>();
	ArrayList<String> array_run = new ArrayList<String>();
	ArrayList<String> array_iteration = new ArrayList<String>();
	
	public void testMain(Object[] args) 
	{
		//To run a TestCase directly, give Scenario, test case, description, iteration start, and iteration end.
//		String Scenario = "Scenario3";
//		CRAFT_Report.summaryStart = Util.getLastsetTimeinmili();
		testcase = this.getClass().getName();
		desc ="desc";
//		int start = 1;
//		int end = 1;			
			
		String path = Util.homePath;
//		String dbpath =path+"\\Datatables\\"+Scenario+".xls";
		Util.timestamp = "Run_"+System.getProperty("user.name", "No System User Name Found")+"_"+Util.getCurrentDatenTime("dd-MM-yy")+"_"+Util.getCurrentDatenTime("H-mm-ss a");
		String resultPath = path+"\\Results\\"+Util.timestamp;
//		String ExcelResPath = resultPath+"\\Excel Results";
		HtmlResPath = resultPath+"\\HTML Results";
		Util.indvResPath = HtmlResPath+"\\Individual Results";
		String RFTResPath = resultPath+"\\RFT Results";
//		String ScreenshotsPath = resultPath+"\\Screenshots";
		Util.screenshotPath = resultPath+"\\Screenshots";
		String runmanagerPath = Util.homePath+"\\Run Manager.xls"; 
		Util.isRQMExecution=false;
		
		//Script execution start time
		long driverScriptStartTime = new Date().getTime();
		CRAFT_Report.summaryStart = Util.getCurrentDatenTime("H-mm-ss a");
		
		//For counting the total number of automation test scripts run
		int totalNo_TestScripts = 0;
		int totalNo_TestScriptExecuted = 0;
		int totalNo_TestScriptNotExecuted = 0;
		int totalNo_PassedTestScripts = 0;
		int totalNo_FailedTestScripts = 0;
//		//Count variable for passed and failed Test Scripts
//		ArrayList<String> array_ExecutedTS = new ArrayList<String>();
//		ArrayList<String> array_NotExecutedTS = new ArrayList<String>();
//		ArrayList<String> array_PassedTS = new ArrayList<String>();
//		ArrayList<String> array_FailedTS = new ArrayList<String>();
		
		System.out.println(RFTResPath);
		logInfo("Starting Driver Script");
		try 
		{        
//			new File(ExcelResPath).mkdirs();
			new File(HtmlResPath).mkdirs();
			new File(Util.indvResPath).mkdirs();
			new File(RFTResPath).mkdirs();
			new File(Util.screenshotPath).mkdirs();
		}
		catch(Exception ex){}
		
		/*
		 * Code for run manager update
		 */
			try{
				setCurrentLogFilter(DISABLE_LOGGING);
				conn = CRAFT_DB.getExcelODBCConnection(runmanagerPath);
				stmt = conn.createStatement();
				
				String excelQuery = "SELECT * FROM [Main$]";
				rs = stmt.executeQuery(excelQuery);

				while(rs.next())
				{					
					array_tsId.add(rs.getString("TS ID"));
					array_run.add(rs.getString("Run"));
					array_iteration.add(rs.getString("IterationRequired"));								
				}
				
				System.out.println("array_tsId:"+array_tsId);
				System.out.println("array_run:"+array_run);
				System.out.println("array_iteration"+array_iteration);
				
				int loop = 0;
				runmanagerSize = array_tsId.size();
				System.out.println("runmanagerSize: "+runmanagerSize);
				dpReset();
				
				while(!dpDone()
						&& loop<runmanagerSize){
					setDatapool("TS ID",array_tsId.get(loop));
				if(array_run.get(loop).equalsIgnoreCase("1")){
						setDatapool("Run","True");
					}
					else if(array_run.get(loop).equalsIgnoreCase("0")){
						setDatapool("Run","False");
					}
					else{
						System.out.println("INVALID INPUT IN RUN MANAGER EXCEL FILE");
						logTestResult("INVALID INPUT IN RUN MANAGER EXCEL FILE",false);
					}
					setDatapool("IterationRequired",array_iteration.get(loop));
					storeDatapool();
					
					System.out.println("before loop: "+loop);
					loop++;
					System.out.println("after loop: "+loop);
					
					dpNext();
				}
				dpReset();
				
				rs.close();
				stmt.close();
				conn.close();
				setCurrentLogFilter(ENABLE_LOGGING);
			}
			catch(Exception e){
				e.getMessage();				
			}		
		/*
		 * End of Code for run manager update
		 */
		
		
		int runloopcount = 0;
		//Looping through the data pool values
		while(!dpDone()
				&& runloopcount<runmanagerSize){
			try{				
			 if(dpString("Run").equalsIgnoreCase("True")){
				 //Starting the individual result report
				 indvTS = dpString("TS ID");
				 
				 //Inserting link for custom CRAFT results on RFT log
				 if(!isRQMExecDriver){
					 computername=InetAddress.getLocalHost().getHostAddress();
					 craftReportLink = "<a href='" +"\\\\"+computername+"\\"+Util.indvResPath+ "\\"+indvTS+".html"+"'"+"target=" + "_blank" + "><font color = blue><B> LINK TO CUSTOM CRAFT HTML REPORT </B></font>";
					 craftReportLink = craftReportLink.replace(":", "$");
					 logInfo(craftReportLink);
					 //						logTestResult(craftReportLink,true);
				 }				    
				//End of Inserting link for custom CRAFT results on RFT log
					
				 CRAFT_Report.createTestcaseHeader(Util.indvResPath+"\\"+indvTS+".html", Util.screenshotPath);
				//Counting the number of test script executed	
				totalNo_TestScriptExecuted = totalNo_TestScriptExecuted+1;
				if(dpString("IterationRequired").contains("One Iteration")){
					Util.allIterationReq = false;
				}
				else if(dpString("IterationRequired").contains("All Iterations")){
					Util.allIterationReq = true;
				}
				System.out.println("Util.allIterationReq: "+Util.allIterationReq);
				//Storing the test script ID as Executed TS
				array_ExecutedTS.add(dpString("TS ID"));
				sleep(2);
			
				//Setting the scenario status as true before Calling the scenario script
				Util.scenarioStatus = true;
				//Script execution start time
				long scenarioStartTime = new Date().getTime();				
				executeTestCase(dpString("TS ID"));				
				
				//Script execution end time
				long scenarioEndTime = new Date().getTime();
			
				//Checking the test script executed passed or failed
				if(Util.scenarioStatus){
					System.out.println("Test Script "+dpString("TS ID")+" executed Successfully");
					logTestResult("Test Script "+dpString("TS ID")+" executed Successfully",true);
					//Storing the test script ID as passed TS
					array_PassedTS.add(dpString("TS ID"));
					//Counting the total number of test scripts passed
					totalNo_PassedTestScripts = totalNo_PassedTestScripts+1;
					setCurrentLogFilter(DISABLE_LOGGING);
					setDatapool("RunStatus","Passed");	
					String tsExecTime = Util.timerTotalTime(Math.round(scenarioEndTime - scenarioStartTime));
					setDatapool("Execution Time",tsExecTime);
					array_tsExecTime.add(dpString("TS ID")+"_"+tsExecTime);
					setCurrentLogFilter(ENABLE_LOGGING);
									
				}
				else{
					System.out.println("Test Script "+dpString("TS ID")+" Failed");
					logTestResult("Test Script "+dpString("TS ID")+" Failed", false);
					//Storing the test script ID as failed TS
					array_FailedTS.add(dpString("TS ID"));
					setCurrentLogFilter(DISABLE_LOGGING);
					setDatapool("RunStatus","Failed");
					String tsExecTime = Util.timerTotalTime(Math.round(scenarioEndTime - scenarioStartTime));
					setDatapool("Execution Time",tsExecTime);
					array_tsExecTime.add(dpString("TS ID")+"_"+tsExecTime);
					setCurrentLogFilter(ENABLE_LOGGING);
			
				}
				CRAFT_Report.closeTestcaseReport(Util.indvResPath+"\\"+indvTS+".html");
			  }//End of if for Run flag check
			 else if(dpString("Run").equalsIgnoreCase("False")){//Else of if for Run flag check
				 array_NotExecutedTS.add(dpString("TS ID"));
				 setCurrentLogFilter(DISABLE_LOGGING);
				 setDatapool("RunStatus","Not Executed");
				 setDatapool("Execution Time","Not Executed");
				 setCurrentLogFilter(ENABLE_LOGGING);
				 
			 }//End of else for Run flag check
			 else{
				 System.out.println("Invalid run status mentioned in run manager datapool");
//				 error = true;
//				 Util.scenarioStatus = false;
//				 CRAFT_Report.LogInfo(tsComponenetName, "Delete button is enabled in Batch List Page while no records are selected", Status.BC_FAILED);
				 setCurrentLogFilter(DISABLE_LOGGING);
				 setDatapool("RunStatus","");
				 setDatapool("Execution Time","");
				 setCurrentLogFilter(ENABLE_LOGGING);
			 }
			 
			 //Saving the modified data pool values
			 storeDatapool();
			 
			}//End of try block
			catch (Exception Ex){
				System.out.println(Ex.getMessage());
				logError(Ex.getMessage());
				setCurrentLogFilter(DISABLE_LOGGING);
				//Saving the modified data pool values
				storeDatapool();
				setCurrentLogFilter(ENABLE_LOGGING);
				
			}//End of catch block	
			//Counting the total number of test scripts
			totalNo_TestScripts = totalNo_TestScripts+1;
			System.out.println("before runloopcount: "+runloopcount);
			runloopcount++;
			System.out.println("after runloopcount: "+runloopcount);
			dpNext();		
		}//End of data pool looping
		
		//Reseting the data pool to set the cursor at the beginning of the pool again
		dpReset();
		//Calculating the total failed script run
		totalNo_FailedTestScripts = totalNo_TestScriptExecuted - totalNo_PassedTestScripts;
		//Calculating the total number of test script skipped from the test suite
		totalNo_TestScriptNotExecuted = totalNo_TestScripts - totalNo_TestScriptExecuted;
		
		
		System.out.println("Driver Script completed successfully");
		logTestResult("Driver Script completed successfully", true);
		logInfo("Total Number of Automation Test Scripts in the Autoamtion Test Suite: "+totalNo_TestScripts);
		logInfo("Total Number of Automation Test Scripts Executed from the Test Suite: "+totalNo_TestScriptExecuted);
		logInfo("Total Number of Automation Test Scripts Not Executed from the Test Suite: "+totalNo_TestScriptNotExecuted);
		logInfo("Total Number of Passed Automation Test Scripts Run: "+totalNo_PassedTestScripts);
		logInfo("Total Number of Failed Automation Test Scripts Run: "+totalNo_FailedTestScripts);
		logInfo("Test Script Ids of Executed Automation Test Scripts: "+array_ExecutedTS);
		logInfo("Test Script Ids of Passed Automation Test Scripts: "+array_PassedTS);
		logInfo("Test Script Ids of Failed Automation Test Scripts: "+array_FailedTS);
		logInfo("Test Script Ids of Not Executed Automation Test Scripts: "+array_NotExecutedTS);
		
		
//		CRAFT_Report.closeTestcaseReport(HtmlResPath+"\\"+testcase+".html");
		  
		try
		{
			String src =path+"_logs\\Driver.DriverScript";
			System.out.println(src);
		    String dest = RFTResPath;
		    System.out.println(dest);
		    Util.copyDirectory(src, dest);
		}
		catch(Exception e1){}
		//Script execution end time
		long driverScriptEndTime = new Date().getTime();
		CRAFT_Report.summaryEnd = Util.getCurrentDatenTime("H-mm-ss a");
		CRAFT_Report.summaryTotalExeTime = Util.timerTotalTime(Math.round(driverScriptEndTime - driverScriptStartTime));
		System.out.println("Script Execution Time: "
							+CRAFT_Report.summaryTotalExeTime);
		logInfo("Script Execution Time: "
				+CRAFT_Report.summaryTotalExeTime);
		//Creating the summary report file
		try{
			CRAFT_Report.overallExecuted = totalNo_TestScriptExecuted;
			CRAFT_Report.overallPass = totalNo_PassedTestScripts;
			CRAFT_Report.overallFail = totalNo_FailedTestScripts;
			CRAFT_Report.overallNotExecuted = totalNo_TestScriptNotExecuted;
			CRAFT_Report.totalScrNo = totalNo_TestScripts;
			CRAFT_Report.createSummaryHeader(HtmlResPath+"\\"+testcase+".html", EnvironmentVariables.projectName);
			
			//Looping through the data pool for summary results
			while(!dpDone()){
				String tsId = dpString("TS ID");
				String execTime = "";				
				//Extracting the execution time for the test script
				for(int loopcount=0;loopcount<array_tsExecTime.size();loopcount++){					
					if(array_tsExecTime.get(loopcount).contains(tsId)){
						String time = array_tsExecTime.get(loopcount);
						execTime = time.substring(time.lastIndexOf("_")+1, time.length());	
						break;
					}	
					else{
						continue;						
					}
				}
				if(execTime.isEmpty()){
					execTime = "NOT EXECUTED";
				}
//				String scrDescription = tsId.substring(tsId.indexOf("BMUI")+5, tsId.lastIndexOf("_"));
//				String projName = EnvironmentVariables.projectName;
//				System.out.println(projName);
//				String appName = projName.substring(projName.indexOf("-")+1, projName.length());
//				System.out.println(appName+" : "+appName.length());
				String appName = "BMUI";
				String scrDescription = tsId.substring(tsId.indexOf(appName)+appName.length()+1, tsId.lastIndexOf("_"));
				String runStatus = getStatus(tsId);
				
				
				//Eliminating not executed test scripts in summary report
				if(runStatus.equalsIgnoreCase("NOT EXECUTED")){
					dpNext();
				}
				else if(runStatus.equalsIgnoreCase("PASSED")
						|| runStatus.equalsIgnoreCase("FAILED")){
					System.out.println(tsId+" : "+scrDescription+" : "+runStatus+" : "+execTime);
					CRAFT_Report.LogSummary(tsId, scrDescription, runStatus, execTime);	
					dpNext();
				}
				else{
					dpNext();
				}	
							
			}//End of while for summary report
			
			//Reseting the data pool
			dpReset();
//			CRAFT_Report.closeSummary(HtmlResPath+"\\"+testcase+".html");

		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		finally{
			CRAFT_Report.closeSummary(HtmlResPath+"\\"+testcase+".html");
			try{
				if(isRQMExecDriver){
					isRQMExecDriver =false;
					//Inserting link for custom CRAFT results on RFT log for RQM integration
					String computername=InetAddress.getLocalHost().getHostAddress();
//					String craftReportLink = "CDATA[<a href='" +"\\\\"+computername+"\\"+Util.indvResPath+ "\\"+testcase+".html"+"'"+"target=" + "_blank" + "><font color = blue><B> LINK TO CUSTOM CRAFT HTML REPORT </B></font>]";
//					craftReportLink = craftReportLink.replace(":", "$");
//					System.out.println("Inside the finally for RQM results");
//					logInfo(craftReportLink);
					String customCRAFTResultPath = "\\\\"+computername+"\\"+Util.indvResPath;
					logInfo("The custom CRAFT result can be found on the path: "+customCRAFTResultPath);
//					String rqmLogFilePath = Util.homePath+"_logs"+"\\"+indvTS+"\\"+"rational_ft_log.html";
//					Util.htmlFileContentReplacement(rqmLogFilePath, "&lt;", "<");
//					Util.htmlFileContentReplacement(rqmLogFilePath, "&gt;", ">");
//					System.out.println("Inside the finally for RQM results");
//					logInfo("Inside the finally for RQM results");
				}
				else{
					startBrowser(HtmlResPath+"\\"+testcase+".html");
				}
			}
			catch(Exception e){
				e.getMessage();
			}
		}
		//End of summary result creation
		
	}//End of testMain()
	
	//Setting parameter for driver script name
	public static void setParam(String TestCase,String desc)
	{
		DriverScript.testcase = TestCase;
		DriverScript.desc =desc;
		
	}//End of setParam()
	
	//Setting parameter for driver script name
	public void executeTestCase(String scenarioName)
	{
		error = false;
//		String onError = Util.GetValue("OnError", "NextIteration");
		try{
//			CRAFT_Report.LogInfo("Start Component","Invoking Business component: ",Status.DONE);			
//			scenarioName = "Fusebox_OCM_ManualCaseCreation_001";
			callScript(scenarioName);
			if(!error&&!CRAFT_Report.error
					 && Util.scenarioStatus)
			{
				CRAFT_Report.LogInfo("Scenario Execution",scenarioName,Status.PASS);
			}
			else
			{
//				reportError(onError);
				CRAFT_Report.LogInfo("Scenario Execution",scenarioName,Status.FAIL);
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
			error = true;
			CRAFT_Report.LogInfo("Unhandled Exception occured while calling scenario \""+scenarioName+"\" from Driver Script",ex.toString(),Status.FAIL);
		
		}

	}//End of function executeTestCase()
	

//Function for getting the test scripts statuses for the summary result
	String getStatus(String tcid)
	{
		String val="";
		Boolean flag=false;
		try{
			for(int counter=0;counter<array_PassedTS.size();counter++ ){
				if(array_PassedTS.get(counter).equalsIgnoreCase(tcid)){
					flag=true;
					break;
				}
				else{
					continue;
				}
			}
			if(flag==true){
				val= "PASSED";
			}
			else{
				for(int counter=0;counter<array_FailedTS.size();counter++ ){
					if(array_FailedTS.get(counter).equalsIgnoreCase(tcid)){
						flag=true;
						break;
					}
					else{
						continue;
					}
				}
				if(flag==true){
					val= "FAILED";
				}
				else{
					for(int counter=0;counter<array_NotExecutedTS.size();counter++ ){
						if(array_NotExecutedTS.get(counter).equalsIgnoreCase(tcid)){
							flag=true;
							break;
						}
						else{
							continue;
						}
					}
					if(flag==true){
						val= "NOT EXECUTED";
					} 
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return val; 
	}
//End of function getStatus()

	
//	private void reportError(String onError)
//	{
//		if(onError.equals("nextIteration"))
//		{
//			CRAFT_Report.LogInfo("Error found", "Moving to next Iteration", Status.FAIL);
//		}
//		else if(onError.equals("nextTestCase"))
//		{
//			CRAFT_Report.LogInfo("Error found", "Moving to next TestCase", Status.FAIL);
//		}
//		else if(onError.equals("stop"))
//		{
//			CRAFT_Report.LogInfo("Error found", "Stopping the execution", Status.FAIL);
//			CRAFT_Report.closeTestcaseReportandUpdateSummary(HtmlResPath+"\\"+testcase+".html");
//			CRAFT_Report.closeSummary();
//			stop();
//		}
//	}//End of report error

}//End of class

