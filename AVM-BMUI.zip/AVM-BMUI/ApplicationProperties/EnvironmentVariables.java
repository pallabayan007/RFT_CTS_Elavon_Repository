package ApplicationProperties;
import java.net.InetAddress;

import resources.ApplicationProperties.EnvironmentVariablesHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxsouvi
 *� 2011, Cognizant Technology Solutions. All Rights Reserved. The information contained herein is subject to change without notice.
 */
public class EnvironmentVariables extends EnvironmentVariablesHelper
{	
	/**
	 * Script Name   : <b>EnvironmentVariables</b>
	 * Generated     : <b>Sep 6, 2011 7:56:28 AM</b>
	 * Subject   	 : 
	 * Test Purpose  : 
	 * /Requirement(s)
	 * Covered
	 * Original Host : WinXP Version2002 Service Pack 3
	 * Assumption(s) : 
	 * @since  2011/09/06
	 * @author sxsouvi
	 */
	
	//URL for the AVM
	public final static String AVMUrl = "https://gatewaytest.novainfo.net/ui/portal.html";
	
	//URL for the AVM Dev Environment
//	public final static String AVMUrl = "https://dweb06.nova.prv/ui/portal.html";
	
	//Path variable for the RFT project location
//	public final static String homepath_Util = "C:\\Documents and Settings\\axbane1.NA\\IBM\\RFT\\Workspace\\AVM-BMUI";
	public final static String homepath_Util = RationalTestScript.getCurrentProject().getLocation().toString();
	
	//Project Name 
	public final static String projectName = RationalTestScript.getCurrentProject().getLocation().toString()
											 .substring(RationalTestScript.getCurrentProject().getLocation().toString().lastIndexOf("\\")+1,
													    RationalTestScript.getCurrentProject().getLocation().toString().length());
	
}

