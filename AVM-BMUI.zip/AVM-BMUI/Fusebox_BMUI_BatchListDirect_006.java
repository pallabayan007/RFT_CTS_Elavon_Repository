
import java.io.File;

import resources.Fusebox_BMUI_BatchListDirect_006Helper;
import Driver.DriverScript;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class Fusebox_BMUI_BatchListDirect_006 extends Fusebox_BMUI_BatchListDirect_006Helper
{
	/**
	 * Script Name   : <b>Fusebox_BMUI_Batch_List_Direct_006</b>
	 * Generated     : <b>Nov 8, 2011 3:21:25 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/08
	 * @author axbane1
	 */
		
	public static int iteration =0;
	public static int subiteration = 1;
	public static String testcase=""; 
	public static String desc = null;	
	public static boolean error = false;
	String businessComponent="";
	long iterationCount = 0;
	boolean skipKeyword = false;
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
//		String[] bc = new String[1];
		
		//To run a TestCase directly, give Scenario, test case, description, iteration start, and iteration end.
//		String Scenario = "Scenario3";
		testcase = this.getClass().getName();
		desc ="desc";
//		int start = 1;
//		int end =1;
		
		String path = Util.homePath;
//		String dbpath =path+"\\Datatables\\"+Scenario+".xls";
//		Util.timestamp = "Run_"+Util.getCurrentDatenTime("dd-MM-yy")+"_"+Util.getCurrentDatenTime("H-mm-ss a");
		String resultPath = path+"\\Results\\"+Util.timestamp;
//		String ExcelResPath = resultPath+"\\Excel Results";
		Util.HtmlScenarioResPath = resultPath+"\\HTML Results\\"+testcase;
//		String RFTResPath = resultPath+"\\RFT Results";
//		String ScreenshotsPath = resultPath+"\\Screenshots";
		
		error = false;
//		String onError = Util.GetValue("OnError", "NextTestCase");
		
		//This section is created for RQM initiated execution only
		try{
			if(Util.isRQMExecution){
				Util.isRQMRunmanager = true;
				DriverScript.isRQMExecDriver = true;
				logInfo("Testing through RQM");				
//				logInfo(""+args.length+args[0].toString()+"");				
	      		if(args.length>0){
	      			Util.setDatatable(testcase,args[0].toString());
	      		}
	      		else{
	      			Util.setDatatable(testcase,"");
	      		}
	      		callScript("Driver.DriverScript");
	      		return;
	      	}
		}
		catch(Exception e){
			logInfo(e.getMessage());
		}		
		//End of section is created for RQM initiated execution only
		
//		System.out.println(RFTResPath);
		
		try 
		{        
//			new File(ExcelResPath).mkdirs();
//			new File(Util.HtmslScenarioResPath).mkdirs();
//			new File(RFTResPath).mkdirs();
			new File(Util.screenshotPath).mkdirs();
//			CRAFT_Report.createTestcaseHeader(Util.indvResPath+"\\"+testcase+".html", Util.screenshotPath);
		}
		catch(Exception ex){}	
		
		
		
		try{
			//Iterating through the data pool
			CRAFT_Report.insertScenario(testcase);
			CRAFT_Report.LogInfo("Start Scenario","Invoking Scenario: "+testcase,Status.DONE);
			while(!dpDone()){
				Util.skipKeyword = false;
				skipKeyword = false;
				iterationCount++;
//				CRAFT_Report.createTestcaseHeader(Util.HtmlScenarioResPath+"\\"+testcase+".html", ExcelResPath+"\\"+testcase+".xls",ScreenshotsPath);
				CRAFT_Report.insertIteration((int)iterationCount);				
				
				//Calling business component user log on
				businessComponent = "Business_Components.UserLogon";
				String[] userId = new String[2];
				userId[0] = dpString("User ID");
				userId[1] = dpString("Password");
				callScript(businessComponent,userId);
				//---------End of business component---------
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
				
				if(!skipKeyword){
					//Calling business component BatchListDirect
					businessComponent = "Business_Components.BatchListDirect";				
					callScript(businessComponent);
					//---------End of business component---------
				}
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}				
				
				if(!skipKeyword){
					//Calling business component user log off
					businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
				}
				
				
				//Scenario end report
				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
				
				//Check for single or multiple iteration
				if(!Util.allIterationReq){
					break;
				}//End of if for single or multiple iterations
				else{
					dpNext();
				}//End of else for single or multiple iterations				
				
			}//End data pool iteration	
			
//			//Scenario end report
//			if(!error && !CRAFT_Report.error
//					  && Util.scenarioStatus)
//			{
//				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
//			}
//			else
//			{
////				reportError(onError);
//				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
//			}
			
		}//End of try for scenario execution
		catch(Exception ex){
			ex.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing scenario: "+testcase,ex.toString(),Status.BC_FAILED);
			//Calling business component user log off
			String businessComponent = "Business_Components.UserLogoff";			
			callScript(businessComponent);
			//---------End of business component---------
		
		}//End of catch for scenario execution		
		finally{
			//Reseting the run manager to false in case it is initiated by RQM
			if(Util.isRQMRunmanager){
				Util.resetDatatable(testcase);
				Util.isRQMExecution = true;
				Util.isRQMRunmanager = false;
			}
		}	  
//		return bc;
		
		
	}//End of test main

}

