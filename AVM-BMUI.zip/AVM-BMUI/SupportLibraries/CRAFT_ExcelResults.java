package SupportLibraries;
import resources.SupportLibraries.CRAFT_ExcelResultsHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import java.io.File;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.sql.Statement;
import Driver.*;
import SupportLibraries.CRAFT_Report.Status;

/**
 * Description   : Functional Test Script
 * @author 
 *
 */
public class CRAFT_ExcelResults extends CRAFT_ExcelResultsHelper
{	
	/**
	 * Script Name   : <b>CRAFT_ExcelResults</b>
	 * Generated     : <b>Sep 7, 2011 4:59:54 AM</b>
	 * Subject   	 : 
	 * Test Purpose  : 
	 * /Requirement(s)
	 * Covered
	 * Original Host : WinXP Version2002 Service Pack 3
	 * Assumption(s) : 
	 * @since  
	 * @author 
	 */
	static long start = 0;
	static long end = 0;
	static String duration = "";
	static int Pass =0;
	static int Fail = 0;
	static int overallPass = 0;
	static int overallFail = 0;
	public static String SummaryExcelfile = null;
	public static String TestCaseExcelfile = null;
	
	
	public CRAFT_ExcelResults() {
		// TODO Auto-generated constructor stub
	}
	
	 //#############################################################################
	//Function Name    	: addRowtoSummary
	//Description     	: Function to add a row to summary
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public static void addRowtoSummary()
	{
		String strReportedEventSheet = "ReportedEvents";
		String time = Util.getCurrentDatenTime("H:mm:ss");
		Connection c1 = null;
		Statement st1 = null;
		String query =null;
		try {
			String s = SummaryExcelfile;
			String status = "";
		    if(Fail>0)
		    {
		     		overallFail++;
		     		status = "FAIL";
		     }
		     else if(Pass > 0)
		     {
		     		overallPass++;
		     		status = "PASS";
		     }
		     else
		     {
		     		status = "DONE";
		     }
			 query = "INSERT INTO ["+strReportedEventSheet+"$] values ('"+DriverScript.testcase+"','"+DriverScript.desc+"','"+ duration +"','"+status+"')";
			 Pass = 0;
			 Fail =0;
			
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+SummaryExcelfile+";READONLY=FALSE");
			st1 = c1.createStatement();
			st1.executeUpdate(query);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				st1.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			try {
				c1.close();
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
		}
		
	}
	 //#############################################################################
	//Function Name    	: addRowtoTestCase
	//Description     	: Function to add a row to TestCase  report
	//Input Parameters 	: strStepName, strDescription, strStatus
	//Return Value    	:None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public static void addRowtoTestCase(String strStepName,String strDescription,Status strStatus)
	{
		if(strStatus.equals(Status.PASS))
		 {
			Pass++;
		 }
		 if(strStatus.equals(Status.FAIL))
		 {
			Fail++;
		 }
		String strReportedEventSheet = "ReportedEvents";
		String time = Util.getCurrentDatenTime("H:mm:ss");
		Connection c1 = null;
		Statement st1 = null;
		String query =null;
		try {
			String s = TestCaseExcelfile;
			query = "INSERT INTO ["+strReportedEventSheet+"$] values ('"+DriverScript.iteration+"','"+ strStepName +"','"+strDescription+"','"+strStatus +"','"+time+"')";
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+TestCaseExcelfile+";READONLY=FALSE");
			st1 = c1.createStatement();
			st1.executeUpdate(query);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				st1.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			try {
				c1.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}
	 //#############################################################################
	//Function Name    	: createTestCaseHeader
	//Description     	: Function to create a TestCase Header
	//Input Parameters 	: TestCaseExcelfile
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	
	public static void createTestCaseHeader(String TestCaseExcelfile)
	{
		CRAFT_ExcelResults.TestCaseExcelfile = TestCaseExcelfile;
		new File(TestCaseExcelfile);
		String strReportedEventSheet = "ReportedEvents";
		Connection c1 =null;
		Statement st1 = null;
		String query = null;
		Util.getCurrentDatenTime("dd MMMMM yyyy");
		start = Util.getLastsetTimeinmili();
		try {
			String s = TestCaseExcelfile;
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+TestCaseExcelfile+";READONLY=FALSE");
			query = "Create table ["+strReportedEventSheet+"] (Iteration varchar(200),Step_Name varchar(200),Description varchar(200),Status varchar(200),Time_Stamp varchar(200))";
			st1 = c1.createStatement();
			st1.executeUpdate(query); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				c1.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
	}
	 //#############################################################################
	//Function Name    	:  createSummaryHeader
	//Description     	: Function to create a Summary Header
	//Input Parameters 	: SummaryExcelfile
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public static void createSummaryHeader(String SummaryExcelfile)
	{
		CRAFT_ExcelResults.SummaryExcelfile = SummaryExcelfile;
		new File(SummaryExcelfile);
		String strReportedEventSheet = "ReportedEvents";
		Connection c1 =null;
		Statement st1 = null;
		String query = null;
		Util.getCurrentDatenTime("dd MMMMM yyyy");
		start = Util.getLastsetTimeinmili();
		try {
			String s = SummaryExcelfile;
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+SummaryExcelfile+";READONLY=FALSE");
			if(SummaryExcelfile.endsWith("Summary.xls"))
			{
				query = "Create table ["+strReportedEventSheet+"] (TC_ID  varchar(200),Description varchar(200),Execution_Time varchar(200),Status varchar(200))";
			}
			else
			{
				 query = "Create table ["+strReportedEventSheet+"] (Iteration varchar(200),Subiteration varchar(200),Step_Name varchar(200),Description varchar(200),Status varchar(200),Time_Stamp varchar(200))";
			}
			st1 = c1.createStatement();
			st1.executeUpdate(query); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				c1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}
	 //#############################################################################
	//Function Name    	: closeTestCase
	//Description     	: Function to close the testcase report file
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public static void closeTestCase()
	{
		end = Util.getLastsetTimeinmili();
		long diff = end - start;
		duration = Util.getFormattedTime(diff);
		String strReportedEventSheet = "ReportedEvents";
		String time = Util.getCurrentDatenTime("H:mm:ss");
		Connection c1 = null;
		Statement st1 = null;
		try {
			String s = TestCaseExcelfile;
			String query = "INSERT INTO ["+strReportedEventSheet+"$] values ('','','Execution Duration','','"+duration+"')";
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+TestCaseExcelfile+";READONLY=FALSE");
			st1 = c1.createStatement();
			st1.executeUpdate(query);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				st1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				c1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	 //#############################################################################
	//Function Name    	: closeSummary
	//Description     	: Function to close the summary report file
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	
	public static void closeSummary()
	{
		overallFail = 0;
		overallPass = 0;
	}

}

