package SupportLibraries;
import resources.SupportLibraries.UtilHelper;
import ApplicationProperties.EnvironmentVariables;

import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;


/**
 * Description   : Functional Test Script
 * @author sxsouvi
 *� 2011, Cognizant Technology Solutions. All Rights Reserved. The information contained herein is subject to change without notice.
 */


/*
 * This class is created to extend abstract class RationalTestScript
 * Also it makes use of non-static methods of RationalTestScript
 */
class UtilRationalTestScript extends RationalTestScript{
	
	//#############################################################################
	//Function Name    	: utilsetCurrentLogFilterDisable
	//Description     	: Function to inherit setCurrentLogFilter(DISABLE_LOGGING) 
	//					  of RationalTestScript class
	//Input Parameters 	: 
	//Return Value    	: 
	//Author		: Ayan Banerjee
	//Date Created	: 05/01/2012
	//#############################################################################
	public void utilsetCurrentLogFilterDisable(){
		this.setCurrentLogFilter(DISABLE_LOGGING);
	}
	
	//#############################################################################
	//Function Name    	: utilsetCurrentLogFilterEnable
	//Description     	: Function to inherit setCurrentLogFilter(ENABLE_LOGGING) 
	//					  of RationalTestScript class
	//Input Parameters 	: 
	//Return Value    	: 
	//Author		: Ayan Banerjee
	//Date Created	: 05/01/2012
	//#############################################################################
	public void utilsetCurrentLogFilterEnable(){
		this.setCurrentLogFilter(ENABLE_LOGGING);
	}
	
}//End of class UtilRationalTestScript


public class Util extends UtilHelper
{	
	/**
	 * Script Name   : <b>Util</b>
	 * Generated     : <b>Sep 15, 2011 4:58:22 AM</b>
	 * Subject   	 : 
	 * Test Purpose  : 
	 * /Requirement(s)
	 * Covered
	 * Original Host : WinXP Version2002 Service Pack 3
	 * Assumption(s) : 
	 * @since  2011/09/07
	 * @author sxsouvi
	 */
	static Calendar cc = null;
	public static String homePath = EnvironmentVariables.homepath_Util;
	public static String timestamp = "";
	public static String HtmlScenarioResPath = "";
	public static Boolean debug = false;
	public static boolean scenarioStatus = true;
	public static boolean allIterationReq = true;
	public static String indvResPath = "";
	public static String screenshotPath = "";
	public static boolean isRQMExecution = true;
	public static boolean isRQMRunmanager = false;	
	public static boolean skipKeyword = false;


	
	//#############################################################################
	//Function Name    	: SetValue
	//Description     	: Function to set the value for a key in the config file.
	//Input Parameters 	: key,  val
	//Return Value    	: None
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created	: 31/10/2008
	//#############################################################################
	public static void SetValue(String key, String val)
    {
		BufferedReader br = null;
        BufferedWriter bw = null;

        String path = Util.homePath+"\\CRAFT.ini";
        String newpath = path+"1";
        String line = "";
        File f = null;
        File f1 = null;
        try
        {
            f = new File(path);
            f.createNewFile();
            f1 = new File(newpath);
            f1.createNewFile();

            br = new BufferedReader(new FileReader(path));
            bw = new BufferedWriter(new FileWriter(newpath));
            String regex = "=";
            boolean found = false;
            String keyval = key+"="+val;

            while((line = br.readLine())!=null)
            {
                if(line.trim().length()>0)
                {
                    String[] pairs = line.split(regex);

                    if(pairs[0].trim().equals(key))
                    {
                        bw.newLine();
                        bw.write(keyval);
                        found = true;
                    }
                    else
                    {
                        bw.newLine();
                        bw.write(line);
                    }
                }
            }

            if(!found)
            {
                bw.newLine();
                bw.write(keyval);
            }
        }
        catch(Exception ex)
        {
        }
        finally
        {
            try
            {
                bw.close();
            }
            catch(Exception ex)
            {
            }
            try
            {
                br.close();
            }
            catch(Exception ex)
            {
            }
        }

        try
        {
            FileCopy(newpath, path);
        }
        catch(Exception ex)
        {
        }
        try
        {
        	f1.delete();
        }
        catch(Exception ex)
        {
        	
        }
    }


    //#############################################################################
	//Function Name    	: GetValue
	//Description     	: Function to get the value from the config file
	//Input Parameters 	: key, def
	//Return Value    	: Value
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created	: 31/10/2008
	//#############################################################################
    public static String GetValue(String key, String def)
    {
        BufferedReader br = null;

        String path =Util.homePath+"\\CRAFT.ini";
        if(Util.debug)
        {
        	System.out.println("get val path="+path+", key = "+key);
        }
        String line = "";
        String val = "";
        Boolean found = false;
        try
        {
            File f = new File(path);
            f.createNewFile();

            br = new BufferedReader(new FileReader(path));

            String regex = "=";

            while((line = br.readLine())!=null)
            {
                if(line.trim().length()>0)
                {
                    String[] pairs = line.split(regex);

                    if(pairs[0].trim().equals(key))
                    {
                        val = pairs[1];
                        found = true;
                    }
                }
            }
        }
        catch(Exception ex)
        {
        }
        finally
        {
            try
            {
                br.close();
            }
            catch(Exception ex)
            {
            }
            if(!found)
            {
                val = def;
                try
                {
                	Util.SetValue(key, def);
                }
                catch(Exception ex)
                {
                }
            }
        }

        return val;
    }

    //#############################################################################
	//Function Name    	: FileCopy
	//Description     	: Function to Copy a file
	//Input Parameters 	:  source dest
	//Return Value    	: None
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created	: 31/10/2008
	//#############################################################################
    public static void FileCopy(String source, String dest)
    {
        File inputFile = new File(source);
        File outputFile =  new File(dest);

        FileInputStream in = null;
        FileOutputStream out = null;
        try
        {
        	new File(source).createNewFile();
        	new File(dest).createNewFile();
            in = new FileInputStream(inputFile);
            out = new FileOutputStream(outputFile);
            int c;

            while ((c = in.read()) != -1)
            {
            	
                out.write(c);
            }
        }
        catch(Exception ex)
        {
        	ex.toString();
        	ex.printStackTrace();
        }

        try
        {
            in.close();
        }
        catch(Exception ex)
        {
        }
        try
        {
            out.close();
        }
        catch(Exception ex)
        {
        }
    }
    

   //#############################################################################
	//Function Name    	: copyDirectory
	//Description     	: Function to copy directory
	//Input Parameters 	:  src,  dest
	//Return Value    	: None
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created	: 31/10/2008
	//#############################################################################
    public static void copyDirectory(String src, String dest)
    {
    	File[] f = new File(src).listFiles();
    	if(Util.debug)
    	{
    		JOptionPane.showMessageDialog(null, "Inside directorycopy function"+src+" to "+dest, "Message", JOptionPane.OK_OPTION);
    	}
    	for (File file : f) {
    		String fileNamealone = file.getName();
    		try
    		{
    			new File(dest+"\\"+fileNamealone).createNewFile();
    			String source = src+"\\"+fileNamealone;
    			String destin = dest+"\\"+fileNamealone;
    			FileCopy(source, destin);
    		}
    		catch(Exception e)
    		{
    			
    		}
		}
  
    }
    

    //#############################################################################
	//Function Name    	: getCurrentDatenTime
	//Description     	: Function to get Current Date and Time
	//Input Parameters 	: format
	//Return Value    	: Current Time
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created		: 31/10/2008
	//#############################################################################
    public static String getCurrentDatenTime(String format)
    {
    	Calendar cal = Calendar.getInstance();
    	cc = cal;
    	SimpleDateFormat sdf = new SimpleDateFormat(format);
	    return sdf.format(cal.getTime());
    }
    

   //#############################################################################
	//Function Name    	: getLastsetTimeinmili
	//Description     	: Function to get Last set Time in miliseconds
	//Input Parameters 	: None
	//Return Value    	: Last set Time 
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created		: 31/10/2008
	//#############################################################################
    public static long getLastsetTimeinmili()
    {
    	return cc.getTimeInMillis();
    }
    

    //#############################################################################
	//Function Name    	: getFormattedTime
	//Description     	: Function to get Formatted Time
	//Input Parameters 	: time
	//Return Value    	: FormattedTime
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created	: 31/10/2008
	//#############################################################################
    public static String getFormattedTime(long time)
    {
    	long timeMillis = time;   
    	long time1 = timeMillis / 1000;   
    	String seconds = Integer.toString((int)(time1 % 60));   
    	String minutes = Integer.toString((int)((time1 % 3600) / 60));   
    	String hours = Integer.toString((int)(time1 / 3600));   
    	for (int i = 0; i < 2; i++) {   
    	if (seconds.length() < 2) {   
    	seconds = "0" + seconds;   
    	}   
    	if (minutes.length() < 2) {   
    	minutes = "0" + minutes;   
    	}   
    	if (hours.length() < 2) {   
    	hours = "0" + hours;   
    	}   
    	}  
    	return hours+": "+minutes+": "+seconds;

    	/*
    	Calendar cal = Calendar.getInstance();
    	DateFormat d = null;
    	cc = cal;
    	
	    SimpleDateFormat sdf = new SimpleDateFormat(format);
	    d = sdf.getInstance();
	    cal.setTimeInMillis(diff);
	    return sdf.format(cal.getTime());*/
    }

	//#############################################################################
	//Function Name    	: takeScreenShot
	//Description     	: Function to take screenshot
	//Input Parameters 	: Path
	//Return Value    	: None
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created	: 31/10/2008
	//#############################################################################
	public static void takeScreenShot(String path)
	{
		try  
		{  
		      //Get the screen size  
		      Toolkit toolkit = Toolkit.getDefaultToolkit();  
		      Dimension screenSize = toolkit.getScreenSize();  
		      Rectangle rect = new Rectangle(0, 0,  
		                                     screenSize.width,  
		                                     screenSize.height);  
		      Robot robot = new Robot();  
		      BufferedImage image = robot.createScreenCapture(rect);  
		      File file;  
		    
		      //Save the screenshot as a png  
		     // file = new File(path);  
		      //ImageIO.write(image, "png", file);  
		    
		      //Save the screenshot as a jpg  
		      file = new File(path);  
		      ImageIO.write(image, "jpg", file);  
		}  
		catch (Exception e)  
		{  
		      System.out.println(e.getMessage());  
		}  
	}
	
	//#####################################################################################
	//Function Name    	: timerTotalTime
	//Description     	: Function to return time in a format HH:MM:SS.
	//Input Parameters 	: Total time in milliseconds 
	//Return Value    	: String of time in a format HH:MM:SS
	//Author		: (Ayan Banerjee)
	//Date Created	: 26/07/2011
	//#####################################################################################

	/*
	 * This is method will accept a time value in milliseconds
	 * It returns a string of time value broken up into hours,minutes & seconds
	 * with the corresponding stamps
	 */	
	public static String timerTotalTime(long totalScriptExecutionTime){
			
		try{
			
			if(Long.toString(totalScriptExecutionTime).equals(null)){
				System.out.println("NULL string encountered for time passing on timerTotalTime method on CRAFTRFTUserSupportLibrary");
				logError("NULL string encountered for time passing on timerTotalTime method on CRAFTRFTUserSupportLibrary");
				return "";
				
			}
			
			String totalExecutionTime = "";
			//Script execution time calculation
			int totalScriptExecutionTime_TotalSeconds = Math.round((int)totalScriptExecutionTime)/1000;
			int totalScriptExecutionTime_Seconds = totalScriptExecutionTime_TotalSeconds%60;
			int totalScriptExecutionTime_TotalMinutes = totalScriptExecutionTime_TotalSeconds/60;
			int totalScriptExecutionTime_Minutes = totalScriptExecutionTime_TotalMinutes%60;
			int totalScriptExecutionTime_Hours = totalScriptExecutionTime_TotalMinutes/60;
			
			totalExecutionTime = Integer.toString(totalScriptExecutionTime_Hours)+" Hours: "
											+Integer.toString(totalScriptExecutionTime_Minutes)+" Minutes: "
											+Integer.toString(totalScriptExecutionTime_Seconds)+" Seconds";
		
			return totalExecutionTime;
			
		}//End of try block
		catch(Exception e){
			System.out.println(e.getMessage());
			logError("UserSupportLibrary method 'commaSeparatedWordDetails' failed for: "+e.getMessage());
			return "";
		
		}	
		
	}//End of function timerTotalTime()
	
	//#####################################################################################
	//Function Name    	: timerTotalTime
	//Description     	: Function to return time in a format HH-MM-SS. Depending on formating
	//					: either _ will be given or hours,minutes tags
	//Input Parameters 	: Total time in milliseconds , Format required/not
	//Return Value    	: String of time in a format HH:MM:SS
	//Author		: (Ayan Banerjee)
	//Date Created	: 13/10/2011
	//#####################################################################################

	/*
	 * This is method will accept a time value in milliseconds
	 * It returns a string of time value broken up into hours,minutes & seconds
	 * with the corresponding stamps
	 */	
	public static String timerTotalTime(long currentTimeInMilli,boolean formatRequired){
        
        try{
              
              if(Long.toString(currentTimeInMilli).equals(null)){
                    System.out.println("NULL string encountered for time passing on timerTotalTime method on CRAFTRFTUserSupportLibrary");
                    logError("NULL string encountered for time passing on timerTotalTime method on CRAFTRFTUserSupportLibrary");
                    return "";
                    
              }
              
              String totalExecutionTime = "";
              //Script execution time calculation
              int totalScriptExecutionTime_TotalSeconds = Math.round((int)currentTimeInMilli)/1000;
              int totalScriptExecutionTime_Seconds = totalScriptExecutionTime_TotalSeconds%60;
              int totalScriptExecutionTime_TotalMinutes = totalScriptExecutionTime_TotalSeconds/60;
              int totalScriptExecutionTime_Minutes = totalScriptExecutionTime_TotalMinutes%60;
              int totalScriptExecutionTime_Hours = totalScriptExecutionTime_TotalMinutes/60;
              //Format required or not
              if(formatRequired){
                    totalExecutionTime = Integer.toString(totalScriptExecutionTime_Hours)+" Hours: "
                    +Integer.toString(totalScriptExecutionTime_Minutes)+" Minutes: "
                    +Integer.toString(totalScriptExecutionTime_Seconds)+" Seconds";
              }
              else{
                    totalExecutionTime = Integer.toString(totalScriptExecutionTime_Hours)+"_"
                    +Integer.toString(totalScriptExecutionTime_Minutes)+"_"
                    +Integer.toString(totalScriptExecutionTime_Seconds);
                    totalExecutionTime = totalExecutionTime.replaceAll("-", "");
              }                 
        
              return totalExecutionTime;
              
        }//End of try block
        catch(Exception e){
              System.out.println(e.getMessage());
              logError("UserSupportLibrary method 'commaSeparatedWordDetails' failed for: "+e.getMessage());
              return "";
        
        }     
        
  }//End of function timerTotalTime()
	

	//#############################################################################
	//Function Name    	: getMappedObject
	//Description     	: Function to create a customized object
	//Input Parameters 	: .class property value, custom property id, custom prop value
	//Return Value    	: GuiTestObject Type
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created	: 15/09/2011
	//#############################################################################
	public static GuiTestObject getMappedObject(String classPropValue,String customProp, String customPropValue){
//		try{
		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		TestObject[] mappedObject = getRootTestObject().find(atDescendant(".class",classPropValue,customProp,customPropValue));
//			RegularExpression regEx = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);
//			TestObject[] _mappedObject = getRootTestObject().find(atList(atDescendant(".class","Html.DIV",".id", regEx),atChild(".class", "Html.TABLE")));
//			TestObject[] mappedObject = getRootTestObject().find(atList(atDescendant(".class",classPropValue,customProp,customPropValue)));
			System.out.println("Custom Object length with prop value "+customPropValue+": "+mappedObject.length);
			
			if (mappedObject.length>0){
				GuiTestObject mappedObjectField = (GuiTestObject)mappedObject[0];
				sleep(2);
				utilRFT.utilsetCurrentLogFilterEnable();				
				return mappedObjectField;
			}
			else{
				System.out.println("Object for type \""+classPropValue+"\" with property \""+customProp+"\" and property value \""+customPropValue+"\" not created");
//				logError("Object for type \""+classPropValue+"\" with property \""+customProp+"\" and property value \""+customPropValue+"\" not created");
				utilRFT.utilsetCurrentLogFilterEnable();
				return null;
			}
			
//		}//End of try block
//		catch(Exception e){
//			e.getMessage();
//			
//		}
			
		
	}//End of function getMappedTextObject()
	
	//#############################################################################
	//Function Name    	: getMappedObject
	//Description     	: Function to create a customized object
	//Input Parameters 	: .class property value, custom property id, custom prop value
	//Return Value    	: GuiTestObject Type
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created	: 15/09/2011
	//#############################################################################
	public static GuiTestObject getMappedObject(String parentClassType,
												String parentProp,
												String parentPropValue,
												String childClassType,
												String childClassValue,
												String childProp,
												String childPropValue){
//		try{
		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		TestObject[] mappedObject = getRootTestObject().find(atList(atDescendant(".class",parentClassType,parentProp,parentPropValue),
																		atChild(childClassType,childClassValue,childProp,childPropValue)));
//			RegularExpression regEx = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);
//			TestObject[] _mappedObject = getRootTestObject().find(atList(atDescendant(".class","Html.DIV",".id", regEx),atChild(".class", "Html.TABLE")));
//			TestObject[] mappedObject = getRootTestObject().find(atList(atDescendant(".class",classPropValue,customProp,customPropValue)));
			System.out.println("Custom Object length with prop value "+childPropValue+": "+mappedObject.length);
			
			if (mappedObject.length>0){
				GuiTestObject mappedObjectField = (GuiTestObject)mappedObject[0];
				sleep(2);
				utilRFT.utilsetCurrentLogFilterEnable();
				return mappedObjectField;
			}
			else{
				System.out.println("Object for type \""+childClassValue+"\" with property \""+childProp+"\" and property value \""+childPropValue+"\" not created");
//				logError("Object for type \""+childClassValue+"\" with property \""+childProp+"\" and property value \""+childPropValue+"\" not created");
				utilRFT.utilsetCurrentLogFilterEnable();
				return null;
			}
			
//		}//End of try block
//		catch(Exception e){
//			e.getMessage();
//			
//		}		
		
	}//End of function getMappedTextObject()
	
	//#############################################################################
	//Function Name    	: getGWTMappedObject
	//Description     	: Function to create a customized GWT object
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, custom property id, custom prop value
	//Return Value    	: GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
	public static GuiTestObject getGWTMappedObject(String parentClassType,String customGWTProp,String customGWTPropValue){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		GuiTestObject returnGWTDynaObject = null;
		TestObject[] to = getRootTestObject().find(atDescendant(".class",parentClassType));
		System.out.println("to[] length: "+to.length);
		try{
			//Creating continuous GWT object to check values 
			for(int loopCount = 0; loopCount<to.length; loopCount++){
				System.out.println("to[]: "+to[loopCount].getDescriptiveName());
				if(to[loopCount].getProperty(customGWTProp).toString().contains(customGWTPropValue)){
					System.out.println("Found dynamic object yahoo!!!!!!!!!!!!!!!!!!!!!!");
					GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
					returnGWTDynaObject = mappedGWTDynaObject;
//					selectAll.click();
//					System.out.println("End Time: "+Util.getCurrentDatenTime("H-mm-ss a"));
					break;
				}
				else{
					continue;
				}		

			}//End of for loop	
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
		}//End of catch statement
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObject;
		
	}//End of function getGWTMappedTextObject()
	
	
	//#############################################################################
	//Function Name    	: getGWTMappedObject
	//Description     	: Function to create a customized GWT object
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, custom property id, custom prop value
	//Return Value    	: GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
	public static GuiTestObject getGWTMappedObject(String parentClassType,String customGWTProp,RegularExpression regEx){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		GuiTestObject returnGWTDynaObject = null;
		TestObject[] mappedObject = getRootTestObject().find(atDescendant(".class",parentClassType,customGWTProp,regEx));
		System.out.println("mappedObject[] length: "+mappedObject.length);
		try{
			if (mappedObject.length>0){
				returnGWTDynaObject = (GuiTestObject)mappedObject[0];
				sleep(2);
				
			}
			else{
				System.out.println("Object for type \""+parentClassType+"\" with property \""+customGWTProp+"\" and property value \""+RegularExpression.toString(regEx)+"\" not created");
//				logError("Object for type \""+parentClassType+"\" with property \""+customGWTProp+"\" and property value \""+RegularExpression.toString(regEx)+"\" not created");
				utilRFT.utilsetCurrentLogFilterEnable();
				return null;
			}	
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
		}//End of catch statement
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObject;
		
	}//End of function getGWTMappedTextObject()
	
	//#############################################################################
	//Function Name    	: getGWTMappedObject
	//Description     	: Function to create a customized GWT object
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, custom property id, custom prop value
	//Return Value    	: GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
	public static GuiTestObject getGWTMappedObject(String parentClassType,
													String customGWTProp,
													RegularExpression regEx,
													String childClassType,
													String customGWTChildProp,
													String customGWTChildPropValue){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		GuiTestObject returnGWTDynaObject = null;
		TestObject[] mappedObject = getRootTestObject().find(atList(atDescendant(".class",parentClassType,customGWTProp,regEx),
																		atChild(".class",childClassType,customGWTChildProp,customGWTChildPropValue)));
		System.out.println("mappedObject[] length: "+mappedObject.length);
		try{
			if (mappedObject.length>0){
				returnGWTDynaObject = (GuiTestObject)mappedObject[0];
				sleep(2);
				
			}
			else{
				System.out.println("Object for type \""+parentClassType+"\" with property \""+customGWTProp+"\" and property value \""+RegularExpression.toString(regEx)+"\" not created");
//				logError("Object for type \""+parentClassType+"\" with property \""+customGWTProp+"\" and property value \""+RegularExpression.toString(regEx)+"\" not created");
				utilRFT.utilsetCurrentLogFilterEnable();
				return null;
			}	
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
		}//End of catch statement
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObject;
		
	}//End of function getGWTMappedTextObject()
	

	//#############################################################################
	//Function Name    	: getGWTMappedObjects
	//Description     	: Function to return array of customized GWT objects
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, custom property id, custom prop value
	//Return Value    	: ArrayList of GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
	public static ArrayList<GuiTestObject> getGWTMappedObjects(String parentClassType,String customGWTProp,String customGWTPropValue){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		ArrayList<GuiTestObject> returnGWTDynaObjects = new ArrayList<GuiTestObject>() ;
		TestObject[] to = getRootTestObject().find(atDescendant(".class",parentClassType));
		System.out.println("to[] length: "+to.length);
		try{
			//Creating continuous GWT object to check values 
			for(int loopCount = 0; loopCount<to.length; loopCount++){
				System.out.println("to[]: "+to[loopCount].getDescriptiveName());
				if(((String) to[loopCount].getProperty(customGWTProp)).contains(customGWTPropValue)){
					System.out.println("Found dynamic object yahoo!!!!!!!!!!!!!!!!!!!!!!");
					GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
					returnGWTDynaObjects.add(mappedGWTDynaObject);
//					selectAll.click();
//					System.out.println("End Time: "+Util.getCurrentDatenTime("H-mm-ss a"));					
				}
				else{
					continue;
				}		

			}//End of for loop	
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
		}//End of catch statement
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObjects;
		
	}//End of function getGWTMappedTextObjects()

	//#############################################################################
	//Function Name    	: getGWTMappedObjects
	//Description     	: Function to return array of customized GWT objects
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, parentClassProp,
	//					: parentClassPropValue,custom property id, custom prop value
	//Return Value    	: ArrayList of GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
	public static ArrayList<GuiTestObject> getGWTMappedObjects(String parentClassType,
																String parentClassProp,
																String parentClassPropValue,
																String customGWTProp,
																String customGWTPropValue){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		ArrayList<GuiTestObject> returnGWTDynaObjects = new ArrayList<GuiTestObject>() ;
		TestObject[] to = getRootTestObject().find(atDescendant(".class",parentClassType,parentClassProp,parentClassPropValue));
		System.out.println("to[] length: "+to.length);
		try{
			//Creating continuous GWT object to check values 
			for(int loopCount = 0; loopCount<to.length; loopCount++){
				System.out.println("to[]: "+to[loopCount].getDescriptiveName());
				if(((String) to[loopCount].getProperty(customGWTProp)).contains(customGWTPropValue)){
					System.out.println("Found dynamic object yahoo!!!!!!!!!!!!!!!!!!!!!!");
					GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
					returnGWTDynaObjects.add(mappedGWTDynaObject);
//					selectAll.click();
//					System.out.println("End Time: "+Util.getCurrentDatenTime("H-mm-ss a"));					
				}
				else{
					continue;
				}		

			}//End of for loop	
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
		}//End of catch statement
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObjects;
		
	}//End of function getGWTMappedTextObjects()
	
	//#############################################################################
	//Function Name    	: getGWTMappedObjects
	//Description     	: Function to return array of customized GWT objects
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, parentClassProp,
	//					: parentClassPropValue,custom property id, custom prop value
	//Return Value    	: ArrayList of GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
	public static ArrayList<GuiTestObject> getGWTMappedObjects(String parentClassType,
																String parentClassProp,
																RegularExpression parentClassPropValue,
																String customGWTProp,
																String customGWTPropValue){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		ArrayList<GuiTestObject> returnGWTDynaObjects = new ArrayList<GuiTestObject>() ;
		TestObject[] to = getRootTestObject().find(atDescendant(".class",parentClassType,parentClassProp,parentClassPropValue));
		System.out.println("to[] length: "+to.length);
		try{
			//Creating continuous GWT object to check values 
			for(int loopCount = 0; loopCount<to.length; loopCount++){
				System.out.println("to[]: "+to[loopCount].getDescriptiveName());
				if(((String) to[loopCount].getProperty(customGWTProp)).contains(customGWTPropValue)){
					System.out.println("Found dynamic object yahoo!!!!!!!!!!!!!!!!!!!!!!");
					GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
					returnGWTDynaObjects.add(mappedGWTDynaObject);
//					selectAll.click();
//					System.out.println("End Time: "+Util.getCurrentDatenTime("H-mm-ss a"));					
				}
				else{
					continue;
				}		

			}//End of for loop	
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
		}//End of catch statement
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObjects;
		
	}//End of function getGWTMappedTextObjects()
	
	//#############################################################################
	//Function Name    	: getGWTMappedObjects
	//Description     	: Function to return array of customized GWT objects.This is 
	//					: an overloaded function of getGWTMappedObjects
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, parentClassProp,
	//					: parentClassPropValue,childClassType,custom property id, custom prop value
	//Return Value    	: ArrayList of GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
	public static ArrayList<GuiTestObject> getGWTMappedObjects(String parentClassType,
																String parentClassProp,
																RegularExpression parentClassPropValue,
																String childClassType,
																String customGWTProp,
																String customGWTPropValue){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		ArrayList<GuiTestObject> returnGWTDynaObjects = new ArrayList<GuiTestObject>() ;
		TestObject[] to = getRootTestObject().find(atList(atDescendant(".class",parentClassType,parentClassProp,parentClassPropValue),
															atChild(".class",childClassType,customGWTProp,customGWTPropValue)));
		System.out.println("to[] length: "+to.length);
		try{
			//Creating continuous GWT object to check values 
			for(int loopCount = 0; loopCount<to.length; loopCount++){
				System.out.println("to[]: "+to[loopCount].getDescriptiveName());
				if(((String) to[loopCount].getProperty(customGWTProp)).contains(customGWTPropValue)){
					System.out.println("Found dynamic object yahoo!!!!!!!!!!!!!!!!!!!!!!");
					GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
					returnGWTDynaObjects.add(mappedGWTDynaObject);
//					selectAll.click();
//					System.out.println("End Time: "+Util.getCurrentDatenTime("H-mm-ss a"));					
				}
				else{
					continue;
				}		

			}//End of for loop	
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
		}//End of catch statement
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObjects;
		
	}//End of function getGWTMappedObjects()
	
	//#############################################################################
	//Function Name    	: getGWTMappedObjects
	//Description     	: Function to return array of customized GWT objects.This is 
	//					: an overloaded function of getGWTMappedObjects
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, parentClassProp,
	//					: parentClassPropValue,childClassType,custom property id, custom prop value
	//Return Value    	: ArrayList of GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
	public static ArrayList<GuiTestObject> getGWTMappedObjects(String parentClassType,
																String parentClassProp,
																String parentClassPropValue,
																String childClassType,
																String customGWTProp,
																String customGWTPropValue){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		ArrayList<GuiTestObject> returnGWTDynaObjects = new ArrayList<GuiTestObject>() ;
		TestObject[] to = getRootTestObject().find(atList(atDescendant(".class",parentClassType,parentClassProp,parentClassPropValue),
															atChild(".class",childClassType,customGWTProp,customGWTPropValue)));
		System.out.println("to[] length: "+to.length);
		try{
			//Creating continuous GWT object to check values 
			for(int loopCount = 0; loopCount<to.length; loopCount++){
				System.out.println("to[]: "+to[loopCount].getDescriptiveName());
				if(((String) to[loopCount].getProperty(customGWTProp)).contains(customGWTPropValue)){
					System.out.println("Found dynamic object yahoo!!!!!!!!!!!!!!!!!!!!!!");
					GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
					returnGWTDynaObjects.add(mappedGWTDynaObject);
//					selectAll.click();
//					System.out.println("End Time: "+Util.getCurrentDatenTime("H-mm-ss a"));					
				}
				else{
					continue;
				}		

			}//End of for loop	
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
		}//End of catch statement
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObjects;
		
	}//End of function getGWTMappedObjects()
	
	//#############################################################################
	//Function Name    	: getGWTSelectChildMappedObject
	//Description     	: Function to create a customized GWT object
	//					: parent class type is given to search within its children 
	//					: returns the child which CONTAINS the property values supplied as input
	//Input Parameters 	: String parentClassType,
	//					: String parentClassProp,
	//	       			: String parentClassPropValue,
	//					: String childClassType,
	//					: String customGWTProp,
	//					: String customGWTPropValue,
	//					: RegularExpression regEx
	//Return Value    	: GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 07/10/2011
	//#############################################################################
	public static GuiTestObject getGWTSelectChildMappedObject(String parentClassType,
															String parentClassProp,
															RegularExpression regEx,
															String childClassType,
															String customGWTProp,
															String customGWTPropValue){

		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();
		
		GuiTestObject returnGWTSelectiveDynaObject = null;
//		RegularExpression regEx = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);
		TestObject[] mappedObject = getRootTestObject().find(atList(atDescendant(".class",parentClassType,parentClassProp, regEx),atChild(".class", childClassType, customGWTProp,customGWTPropValue)));
		
		System.out.println("mappedObject[] length: "+mappedObject.length);
		try{		
			System.out.println("Custom Object length with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\": "+mappedObject.length);
			
			if (mappedObject.length>0){
				GuiTestObject mappedObjectField = (GuiTestObject)mappedObject[0];
				sleep(2);
				returnGWTSelectiveDynaObject = mappedObjectField;
			}
			else{
				System.out.println("Object for type \""+childClassType+"\" with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\" not created");
//				logError("Object for type \""+childClassType+"\" with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\" not created");
				return null;
			}
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
			
		}
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTSelectiveDynaObject;
		
	}//End of function getGWTSelectChildMappedObject()
	
	
	//#############################################################################
	//Function Name    	: getGWTSelectiveMappedObjects
	//Description     	: Function to create a customized GWT object
	//					: parent class type is given to search within its children 
	//					: returns the child which CONTAINS the property values supplied as input
	//Input Parameters 	: String parentClassType,
	//					: String parentClassProp,
	//	       			: String parentClassPropValue,
	//					: String childClassType,
	//					: String customGWTProp,
	//					: String customGWTPropValue,
	//					: RegularExpression regEx
	//Return Value    	: GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 07/10/2011
	//#############################################################################
	public static ArrayList<GuiTestObject> getGWTSelectChildMappedObjects(String parentClassType,
															String parentClassProp,
															RegularExpression parentClassPropValue,
															String childClassType,
															String customGWTProp,
															String customGWTPropValue){
		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();

//		GuiTestObject returnGWTSelectiveDynaObject = null;
//		RegularExpression regEx = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);
		TestObject[] mappedObject = getRootTestObject().find(atList(atDescendant(".class",parentClassType,parentClassProp, parentClassPropValue)));
		TestObject[] mappedChildObject = null;
		ArrayList<GuiTestObject> returnGWTDynaObjects = new ArrayList<GuiTestObject>();
		System.out.println("mappedObject[] length: "+mappedObject.length);
		try{		
			System.out.println("Custom parent Object length with property \""+parentClassProp+"\" and property value \""+parentClassPropValue+"\": "+mappedObject.length);
			for(int loop=0;loop<mappedObject.length;loop++){
				mappedChildObject = mappedObject[loop].find(atList(atDescendant(".class",childClassType)));
				System.out.println("Custom Object length with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\": "+mappedChildObject.length);
				//Creating continuous GWT object to check values 
				for(int loopCount = 0; loopCount<mappedChildObject.length; loopCount++){
					System.out.println("mappedChildObject[]: "+mappedChildObject[loopCount].getDescriptiveName());
					if(mappedChildObject[loopCount].getProperty(customGWTProp).toString().contains(customGWTPropValue)){
						System.out.println("Found dynamic child object yahoo!!!!!!!!!!!!!!!!!!!!!!");
//						GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
						returnGWTDynaObjects.add((GuiTestObject) mappedChildObject[loopCount]);						
					}
					else{
						continue;
					}		

				}//End of for loop child object mapping
			}//End of for loop for child object looping
			      
//			if (mappedObject.length>0){
//				GuiTestObject mappedObjectField = (GuiTestObject)mappedObject[0];
//				sleep(2);
//				returnGWTSelectiveDynaObject = mappedObjectField;
//			}
//			else{
//				System.out.println("Object for type \""+childClassType+"\" with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\" not created");
//				logError("Object for type \""+childClassType+"\" with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\" not created");
//				return null;
//			}
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
			
		}
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObjects;
		
	}//End of function getGWTMappedTextObject()
	
	//#############################################################################
	//Function Name    	: getGWTSelectiveMappedObjects
	//Description     	: Function to create a customized GWT object
	//					: parent class type is given to search within its children 
	//					: returns the child which CONTAINS the property values supplied as input
	//Input Parameters 	: String parentClassType,
	//					: String parentClassProp,
	//	       			: String parentClassPropValue,
	//					: String childClassType,
	//					: String customGWTProp,
	//					: String customGWTPropValue,
	//					: RegularExpression regEx
	//Return Value    	: GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 07/10/2011
	//#############################################################################
	public static ArrayList<GuiTestObject> getGWTSelectChildMappedObjects(String parentClassType,
															String parentClassProp,
															RegularExpression parentClassPropValue,
															String childClassType,
															String customGWTProp,
															RegularExpression customGWTPropValue){
		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();

//		GuiTestObject returnGWTSelectiveDynaObject = null;
//		RegularExpression regEx = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);
		TestObject[] mappedObject = getRootTestObject().find(atList(atDescendant(".class",parentClassType,parentClassProp, parentClassPropValue)));
		TestObject[] mappedChildObject = null;
		ArrayList<GuiTestObject> returnGWTDynaObjects = new ArrayList<GuiTestObject>();
		System.out.println("mappedObject[] length: "+mappedObject.length);
		try{		
			System.out.println("Custom Object length with property \""+parentClassProp+"\" and property value \""+parentClassPropValue+"\": "+mappedObject.length);
			for(int loop=0;loop<mappedObject.length;loop++){
				mappedChildObject = mappedObject[loop].find(atList(atDescendant(".class",childClassType)));
				System.out.println("Custom Object length with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\": "+mappedChildObject.length);
				//Creating continuous GWT object to check values 
				for(int loopCount = 0; loopCount<mappedChildObject.length; loopCount++){
					System.out.println("mappedChildObject[]: "+mappedChildObject[loopCount].getDescriptiveName());
					if(mappedChildObject[loopCount].getProperty(customGWTProp).toString().contains(customGWTPropValue.toString())){
						System.out.println("Found dynamic child object yahoo!!!!!!!!!!!!!!!!!!!!!!");
//						GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
						returnGWTDynaObjects.add((GuiTestObject) mappedChildObject[loopCount]);						
					}
					else{
						continue;
					}		

				}//End of for loop child object mapping
			}//End of for loop for child object looping
			      
//			if (mappedObject.length>0){
//				GuiTestObject mappedObjectField = (GuiTestObject)mappedObject[0];
//				sleep(2);
//				returnGWTSelectiveDynaObject = mappedObjectField;
//			}
//			else{
//				System.out.println("Object for type \""+childClassType+"\" with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\" not created");
//				logError("Object for type \""+childClassType+"\" with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\" not created");
//				return null;
//			}
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
			
		}
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObjects;
		
	}//End of function getGWTMappedTextObject()
	
	//#############################################################################
	//Function Name    	: getGWTSelectiveMappedObjects
	//Description     	: Function to create a customized GWT object
	//					: parent class type is given to search within its children 
	//					: returns the child which CONTAINS the property values supplied as input
	//Input Parameters 	: String parentClassType,
	//					: String parentClassProp,
	//	       			: String parentClassPropValue,
	//					: String childClassType,
	//					: String customGWTProp,
	//					: String customGWTPropValue,
	//					: RegularExpression regEx
	//Return Value    	: GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 07/10/2011
	//#############################################################################
	public static ArrayList<GuiTestObject> getGWTSelectChildMappedObjects(String parentClassType,
															String parentClassProp,
															String parentClassPropValue,
															String childClassType,
															String customGWTProp,
															String customGWTPropValue){
		UtilRationalTestScript utilRFT = new UtilRationalTestScript();
		utilRFT.utilsetCurrentLogFilterDisable();

//		GuiTestObject returnGWTSelectiveDynaObject = null;
//		RegularExpression regEx = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);
		TestObject[] mappedObject = getRootTestObject().find(atList(atDescendant(".class",parentClassType,parentClassProp, parentClassPropValue)));
		TestObject[] mappedChildObject = null;
		ArrayList<GuiTestObject> returnGWTDynaObjects = new ArrayList<GuiTestObject>();
		System.out.println("mappedObject[] length: "+mappedObject.length);
		try{		
			System.out.println("Custom Object length with property \""+parentClassProp+"\" and property value \""+parentClassPropValue+"\": "+mappedObject.length);
			for(int loop=0;loop<mappedObject.length;loop++){
				mappedChildObject = mappedObject[loop].find(atList(atDescendant(".class",childClassType)));
				System.out.println("Custom Object length with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\": "+mappedChildObject.length);
				//Creating continuous GWT object to check values 
				for(int loopCount = 0; loopCount<mappedChildObject.length; loopCount++){
					System.out.println("mappedChildObject[]: "+mappedChildObject[loopCount].getDescriptiveName());
					System.out.println("mappedChildObject[]: "+mappedChildObject[loopCount].getProperty(customGWTProp).toString());
					if(mappedChildObject[loopCount].getProperty(customGWTProp).toString().contains(customGWTPropValue)){
						System.out.println("Found dynamic child object yahoo!!!!!!!!!!!!!!!!!!!!!!");
//						GuiTestObject mappedGWTDynaObject = (GuiTestObject) to[loopCount];
						returnGWTDynaObjects.add((GuiTestObject) mappedChildObject[loopCount]);						
					}
					else{
						continue;
					}		

				}//End of for loop child object mapping
			}//End of for loop for child object looping
			System.out.println("returnGWTDynaObjects size: "+returnGWTDynaObjects.size());
			      
//			if (mappedObject.length>0){
//				GuiTestObject mappedObjectField = (GuiTestObject)mappedObject[0];
//				sleep(2);
//				returnGWTSelectiveDynaObject = mappedObjectField;
//			}
//			else{
//				System.out.println("Object for type \""+childClassType+"\" with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\" not created");
//				logError("Object for type \""+childClassType+"\" with property \""+customGWTProp+"\" and property value \""+customGWTPropValue+"\" not created");
//				return null;
//			}
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
			
		}
		
		utilRFT.utilsetCurrentLogFilterEnable();
		
		return returnGWTDynaObjects;
		
	}//End of function getGWTMappedTextObject()
	
	

	//#############################################################################
	//Function Name    	: codeToSetValueInHtmlTable
	//Description     	: Function to set value in html table row
	//					: parent class type is given to search within its children 
	//					: to find the intended dynamic object & return the same
	//Input Parameters 	: .class property type of the parent, custom property id, custom prop value
	//Return Value    	: GuiTestObject Type
	//Author			: Ayan BAnerjee
	//Date Created		: 19/09/2011
	//#############################################################################
		
		public static void codeToSetValueInHtmlTable(
							GuiSubitemTestObject tblObj, 	// HTML Table Object 
							String columnHeaderToSearch, 	// Column Header of the column where data need to be set
							String searchStringInRow, 		// Search text in the row to identify the row in which the value need to be set
							Property[] typeOfControl, 		// Properties of the control that appears dynamically
							String valueToSet				// Value to set in the dynamic control
					                         ) {
		
			StatelessGuiSubitemTestObject tableObj = new StatelessGuiSubitemTestObject(tblObj);
			GuiSubitemTestObject jTable= new GuiSubitemTestObject(tableObj);
			jTable.waitForExistence();
		
			ITestDataTable dataTable =(ITestDataTable)jTable.getTestData("contents");
//			int rowCount = dataTable.getRowCount();		
			int colCount = dataTable.getColumnCount();
			int colIndex = 0;
		
			// Iterate through all the columns and identify the column index where the data need to be entered
			for(colIndex=0; colIndex<colCount; colIndex++)
				if(dataTable.getCell(0, colIndex).toString().contains(columnHeaderToSearch)) { break; }
		
			Property propToSearch[] = new Property[1]; // Property array to hold the property of the object that is to be searched
			propToSearch[0] = new Property(".class", "Html.TR"); // Mention the class corresponding to Table Row of a HTML Table
		
			TestObject rowObject[] = tblObj.find(atDescendant(propToSearch));
		
			for (TestObject tblRow : rowObject) {
				if ( tblRow.getProperty(".text").toString().contains(searchStringInRow) ) {
		
					// Code to click on the specific column of the row
					propToSearch[0] = new Property(".class", "Html.TD");
					TestObject colObject = tblRow.find(atDescendant(propToSearch))[colIndex];
					GuiSubitemTestObject tblCol = new GuiSubitemTestObject(colObject);
					tblCol.click();
		
					//Code to wait for the specific control to appear on the column
					TestObject dynObj = tblCol.find(atDescendant(typeOfControl))[0];
					String objType = dynObj.getProperty(".class").toString();
		
					//Checking the text filed to set values
					if(objType.equalsIgnoreCase("HTML.INPUT.Text")) {
						TextGuiTestObject txtObj = new TextGuiTestObject(dynObj);
						txtObj.setText(valueToSet);
					}else if(objType.equalsIgnoreCase("HTML.SELECT")) {
						TextSelectGuiSubitemTestObject listObj = new TextSelectGuiSubitemTestObject(dynObj);
						listObj.select(valueToSet);
					}//End of else for text check
		
					break; // Break the for loop when the value is set and exit from the method
				}//End of if statement
				
			}//End of for statement		
		
		
		}//End of function codeToSetValueInHtmlTables	

		//#####################################################################################
		//Function Name           : commaSeparatedWordCount
		//Description             : Function to return no. of comma separated words in a string.
		//Input Parameters        : A user string containing several words in comma separated format
		//Return Value            : No. of comma separated words in a string
		//Author                  : (Ayan Banerjee)
		//Date Created : 26/07/2011
		//#####################################################################################

		public static long commaSeparatedWordCount(String totalString){

			try{

				//Check for null values in argument
				if(totalString.equals(null)){
					System.out.println("NULL string encountered for string value supplied on commaSeparatedWordCount method on CRAFTRFTUserSupportLibrary");
					logError("NULL string encountered for string value supplied on commaSeparatedWordCountk method on CRAFTRFTUserSupportLibrary");
					return 0;

				}

				int totalWordNoInGivenString = 0;

				//Variables for finding the location of the "," delimiter in the total  string
				int firstDelimiterIndex = totalString.indexOf(",");
				int lastUserIdIndex = totalString.lastIndexOf(",");


				//Variables for counting the number of delimiter and no. of words in the string                 
				int totalDelimeterNoInGivenString = 0;
				int currentCursorPosition = 0;
				String userStringSub = totalString;
				int firstDelimiterPosition = userStringSub.indexOf(",");


				//Extracting the delimiter and the no of words in the user given string
				if(firstDelimiterIndex!=-1 
						&& lastUserIdIndex!=-1){


					//looping for counting the total number of delimiters
					do{         
						currentCursorPosition = currentCursorPosition+firstDelimiterPosition+1;              
						if(userStringSub.isEmpty()){
							break;
						}
						else {
							if(firstDelimiterPosition!=-1){
								totalDelimeterNoInGivenString = totalDelimeterNoInGivenString+1;                                                          
								userStringSub = userStringSub.substring(currentCursorPosition, userStringSub.length()).trim();
								firstDelimiterPosition = userStringSub.indexOf(",");
								currentCursorPosition = 0;
							}
							else{
								break;
							}                              
						}              
					}while(!userStringSub.isEmpty());
					totalWordNoInGivenString = totalDelimeterNoInGivenString+1;

				}//End of if for extracting the delimiter
				else{//Else for extracting words in case of single word
					//Check for no word in user given string
					if(totalString.isEmpty()){
						totalWordNoInGivenString = 0;
						System.out.println("Blank user given String is supplied");

					}//End of if for no word check
					else{//Else of if for no word check
						totalWordNoInGivenString = totalDelimeterNoInGivenString+1;

					}//End of else for no word check

				}//End of else for single word

				return totalWordNoInGivenString;

			}//End of try block
			catch(Exception e){
				System.out.println(e.getMessage());
//				logError("UserSupportLibrary method 'commaSeparatedWordDetails' failed for: "+e.getMessage());
				return 0;

			}

		}//End of function commaSeparatedWordCount()
		
		//#####################################################################################
		//Function Name           : stringWordCount
		//Description             : Function to return no. of delimiter separated words in a string.
		//Input Parameters        : A user string containing several words in comma separated format
		//Return Value            : No. of comma separated words in a string
		//Author                  : (Ayan Banerjee)
		//Date Created : 26/07/2011
		//#####################################################################################

		public static long stringWordCount(String totalString,String delimiter){

			try{

				//Check for null values in argument
				if(totalString.equals(null)){
					System.out.println("NULL string encountered for string value supplied on commaSeparatedWordCount method on CRAFTRFTUserSupportLibrary");
					logError("NULL string encountered for string value supplied on commaSeparatedWordCountk method on CRAFTRFTUserSupportLibrary");
					return 0;

				}

				int totalWordNoInGivenString = 0;

				//Variables for finding the location of the delimiter in the total  string
				int firstDelimiterIndex = totalString.indexOf(delimiter);
				int lastUserIdIndex = totalString.lastIndexOf(delimiter);


				//Variables for counting the number of delimiter and no. of words in the string                 
				int totalDelimeterNoInGivenString = 0;
				int currentCursorPosition = 0;
				String userStringSub = totalString;
				int firstDelimiterPosition = userStringSub.indexOf(delimiter);


				//Extracting the delimiter and the no of words in the user given string
				if(firstDelimiterIndex!=-1 
						&& lastUserIdIndex!=-1){


					//looping for counting the total number of delimiters
					do{         
						currentCursorPosition = currentCursorPosition+firstDelimiterPosition+1;              
						if(userStringSub.isEmpty()){
							break;
						}
						else {
							if(firstDelimiterPosition!=-1){
								totalDelimeterNoInGivenString = totalDelimeterNoInGivenString+1;                                                          
								userStringSub = userStringSub.substring(currentCursorPosition, userStringSub.length()).trim();
								firstDelimiterPosition = userStringSub.indexOf(delimiter);
								currentCursorPosition = 0;
							}
							else{
								break;
							}                              
						}              
					}while(!userStringSub.isEmpty());
					totalWordNoInGivenString = totalDelimeterNoInGivenString+1;

				}//End of if for extracting the delimiter
				else{//Else for extracting words in case of single word
					//Check for no word in user given string
					if(totalString.isEmpty()){
						totalWordNoInGivenString = 0;
						System.out.println("Blank user given String is supplied");

					}//End of if for no word check
					else{//Else of if for no word check
						totalWordNoInGivenString = totalDelimeterNoInGivenString+1;

					}//End of else for no word check

				}//End of else for single word

				return totalWordNoInGivenString;

			}//End of try block
			catch(Exception e){
				System.out.println(e.getMessage());
//				logError("UserSupportLibrary method 'commaSeparatedWordDetails' failed for: "+e.getMessage());
				return 0;

			}

		}//End of function stringWordCount()


		//#####################################################################################
		//Function Name           : commaSeparatedWordDetails
		//Description             : Function to return individual words of a comma separated string
		//Input Parameters        : a user string containing several words in comma separated format
		//Return Value            : Array of no. of comma separated words in a string
		//Author                  : (Ayan Banerjee)
		//Date Created : 26/07/2011
		//#####################################################################################

		public static java.lang.Object commaSeparatedWordDetails(String totalString,long wordCount){


			try{

				//Check for null arguments
				if(totalString.equals(null)){
					System.out.println("NULL string encountered for string value supplied on commaSeparatedWordDetails method on CRAFTRFTUserSupportLibrary");
					logError("NULL string encountered for string value supplied on commaSeparatedWordDetails method on CRAFTRFTUserSupportLibrary");
					return "";

				}
				if(Long.toString(wordCount).equals(null)){
					System.out.println("NULL string encountered on commaSeparatedWordDetails method on CRAFTRFTUserSupportLibrary");
					logError("NULL string encountered on commaSeparatedWordDetails method on CRAFTRFTUserSupportLibrary");
					return "";

				}

				//Declaring arrays to store the user string from data pool
				String array_IndividualUserGivenWords[] = new String[(int)wordCount];

				//Setting the delimiter locations for extracting the user given string 
				int firstDelimiter = 0;
				int nextDelimiter = 0;
				String userStringNewSub = totalString;

				//checking for more than one no. of words
				if(wordCount>1){
					//Extracting and storing the words into array
					for(int countVariable=0;countVariable<wordCount;countVariable++){
						nextDelimiter = userStringNewSub.indexOf(",");
						//                                                                    System.out.println("nextDelimeter: "+nextDelimiter);
						if(!userStringNewSub.isEmpty()
								&& nextDelimiter!=-1){
							array_IndividualUserGivenWords[countVariable] = userStringNewSub.substring(firstDelimiter, nextDelimiter).trim();


						}
						else{
							if(!userStringNewSub.isEmpty()
									&& nextDelimiter ==-1){
								array_IndividualUserGivenWords[countVariable] = userStringNewSub.substring(firstDelimiter,userStringNewSub.length()).trim();
							}
							else{
								break;
							}

						}
						userStringNewSub = userStringNewSub.substring(nextDelimiter+1, userStringNewSub.length()).trim();

					}//End of for loop for populating word list array
				}//End of if for more than one word check
				else{//Else for extracting words in case of single word
					//Check for no word in user given string
					if(wordCount==0){
						System.out.println("Blank user given String is supplied");

					}//End of if for no word check
					else{//Else of if for no word check
						array_IndividualUserGivenWords[0] = userStringNewSub;

					}//End of else for no word check

				}//End of else for single word

				return array_IndividualUserGivenWords;

			}//End of try block
			catch(Exception e){
				System.out.println(e.getMessage());
//				logError("UserSupportLibrary method 'commaSeparatedWordDetails' failed for: "+e.getMessage());
				return "";
			}

		}//End of function commaSeparatedWordDetails()
		

		//#############################################################################
	    //Function Name         : FileCreate
	    //Description           : Function to Create a file
	    //Input Parameters      : String fullFilePath, String fileContent
	    //Return Value          : None
	    //Author          		: Bappaditya Choudhury
	    //Date Created    		: 09/01/2012
	    //#############################################################################	      

		public static void FileCreate(String fullFilePath, String fileContent)
		{ 
			try {
				Writer output = null;
				File inputsource= new File(fullFilePath); 
				output = new BufferedWriter(new FileWriter(inputsource));
				output.write(fileContent);
				output.close();
				System.out.println("Your file has been written");
			}
			catch (Exception e) {
				e.getMessage();
			}
		}
		
		//#############################################################################
		//Function Name    	: setDatatable
		//Description     	: Function to set the run manager table for RQM execution
		//Input Parameters 	: String scenarioName,String iterations
		//Return Value    	: None
		//Author		: Ayan Banerjee
		//Date Created	: 31/01/2012
		//#############################################################################
		public static void setDatatable(String scenarioName,String iterations){
			try {
				
				
				if(iterations.equals("")){
					iterations="One Iteration";
				}
				else if(iterations.equalsIgnoreCase("alliterations")){
					iterations="All Iterations";
				}
				else{
					iterations="One Iteration";
				}
				
				resetDatatable(scenarioName);
				Connection con = null;
			    String val2="TRUE";
			    String excelPath = homePath+"\\Run Manager.xls";
			    con = CRAFT_DB.getExcelODBCConnection(excelPath);
				Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);				
				String sql2 = "UPDATE [Main$] SET [Run] ="+val2+",[IterationRequired] ='"+iterations+"' WHERE [TS ID]='"+scenarioName+"'";
				stat.executeUpdate(sql2);
				stat.close();
	            con.close();
				
			} catch (SQLException Ex) {
				System.out.println(Ex.getMessage());
				logError(Ex.getMessage());
			}
		}	
		
		
		//#############################################################################
		//Function Name    	: resetDatatable
		//Description     	: Function to reset the run manager table for RQM execution to false
		//Input Parameters 	: String scenarioName
		//Return Value    	: None
		//Author		: Ayan Banerjee
		//Date Created	: 31/01/2012
		//#############################################################################
		public static void resetDatatable(String scenarioName){
			try {
				Connection con = null;
			    String val1="FALSE";
			    String excelPath = homePath+"\\Run Manager.xls";
				con = CRAFT_DB.getExcelODBCConnection(excelPath);
				Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
				String sql1 = "UPDATE [Main$] SET [Run] ="+val1;
				stat.executeUpdate(sql1);
				stat.close();					
	            con.close();
				
			} 
			catch (SQLException Ex) {
				System.out.println(Ex.getMessage());
				logError(Ex.getMessage());
			}
	}
		
		//#############################################################################
		//Function Name    	: fileContentReplace
		//Description     	: Function to replace a content in a file
		//Input Parameters 	: String filepath, String toBeReplaced, String replaceWith
		//Return Value    	: None
		//Author		: Ayan Banerjee
		//Date Created	: 31/01/2012
		//#############################################################################
		public static void fileContentReplace(String filepath, String toBeReplaced, String replaceWith){
			String line=null;
			String lines="";
			FileReader fr;
			try {
				fr = new FileReader(filepath);				 
				BufferedReader br = new BufferedReader(fr);
				while((line=br.readLine()) != null) {   
					lines=lines+line;
				}
				lines.replace(toBeReplaced, replaceWith);
				System.out.println(lines);
				FileWriter fw = new FileWriter(new File(filepath));
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(lines);
				bw.flush();
				fw.close();
				bw.close();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}//End of function fileContentReplace()
		
		//#############################################################################
		//Function Name    	: htmlFileContentReplacement
		//Description     	: Function to replace a string in an html file
		//Input Parameters 	: String reportPath,String scrnshtPath,String scriptId
		//Return Value    	: None
		//Author		: (Ayan Banerjee)
		//Date Created	: 17/02/2012
		//#############################################################################
		
		public static void htmlFileContentReplacement(String reportHtmlFilePath,String toBeReplaced,String replacementString){
			
			//String for reading the rft_logframe html
			StringBuffer rftLogFrameContent = new StringBuffer();
			int ch;			
					
			try{
				//Reading from the RFT result log frame
				FileInputStream rftLogFrameFileStream = new FileInputStream(reportHtmlFilePath);
				DataInputStream in = new DataInputStream(rftLogFrameFileStream);
				
				//Read File Line By Line
				while ((ch = rftLogFrameFileStream.read()) != -1)   {				
					rftLogFrameContent.append((char)ch); 
					
				}//End of while for file reading
				
					//Creating pattern matching 
					String pattern = toBeReplaced;
//					String pattern1 = "<IMG src=";
					String patternReplace = replacementString;
//					String patternReplace1 = "<IMG src="+scrnshtPath+"/";
					Pattern p = Pattern.compile(pattern);
//					Pattern p1 = Pattern.compile(pattsern1);
			        // Create a matcher with an input string
			        Matcher m = p.matcher(rftLogFrameContent);
			        StringBuffer sbReplace = new StringBuffer();		        
			        boolean result = m.find();			        
			        // Loop through and create a new String 
			        // with the replacements
			        while(result) {
			        	 m.appendReplacement(sbReplace, patternReplace);
			        	 result = m.find();
//			        	 System.out.println("Inside while loop");
			        }
//			        System.out.println(""+sb.toString());
			        m.appendTail(sbReplace);       
			        System.out.println(sbReplace.toString());
			        FileWriter fw = new FileWriter(new File(reportHtmlFilePath));
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write(sbReplace.toString());
					bw.flush();
					fw.close();
					bw.close();	
				
				//Close the input stream
				in.close();
				
				logInfo("End of Inside the htmlFileContentReplacement method");
				
			}//End of try for file reading
			catch(Exception e){
				e.getMessage();
				e.getCause();
			}//End of catch for try for file reading	
			
		}//End of function htmlFileContentReplacement
		 
}//End of class Util

