package SupportLibraries;
import resources.SupportLibraries.CRAFT_DBHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.ExecutionException;

import javax.sql.rowset.CachedRowSet;
import javax.swing.JOptionPane;

import SupportLibraries.CRAFT_Report.Status;
import com.sun.rowset.CachedRowSetImpl;

/**
 * Description   : Functional Test Script
 * @author
 *
 */
public class CRAFT_DB extends CRAFT_DBHelper
{	
	/**
	 * Script Name   : <b>CRAFT_DB</b>
	 * 
	 * Subject   	 : 
	 * Test Purpose  : 
	 * /Requirement(s)
	 * Covered
	 * Original Host : WinXP Version2002 Service Pack 3
	 * Assumption(s) : 
	 * @since  
	 * @author
	 */

		// TODO Insert code here
		static Connection c1=null;
		public static String  dbpath =null;
		public static String sheet = null;
		public static int iterationno = 0;
		public static String testcase =null;
		public static int subiter = 0;
		public static String PSheet = null;
		
		
		public CRAFT_DB()
		{
			 
		}


	    //#############################################################################
		//Function Name    	: setparameters
		//Description     	: Function to set the parameters
		//Input Parameters 	:  testcase, iterationno, sheet, subiter, parasheet
		//Return Value    	: None
		//Author		: 
		//Date Created		: 
		//#############################################################################

		public static void setparameters(String testcase,int iterationno,String sheet,int subiter,String parasheet)
		{
			CRAFT_DB.testcase = testcase;
			CRAFT_DB.iterationno = iterationno;
			CRAFT_DB.sheet = sheet;
			CRAFT_DB.subiter = subiter;
			PSheet = parasheet;
		}
		public static void setparameters(String sheet)
		{
			CRAFT_DB.sheet = sheet;
			
		}
		
		//#############################################################################
		//Function Name    	: initialize
		//Description     	: Function to initialize the excel values
		//Input Parameters 	:  testcase, iterationno, subiter,sheet, parasheet, dbpath
		//Return Value    	: strFrameworkRootFolder
		//Author		: 
		//Date Created		: 
		//#############################################################################
		public static void initialize(String testcase,int iterationno,int subiter,String sheet,String parasheet,String dbpath)
		{
			CRAFT_DB.dbpath = dbpath;
			setparameters(testcase, iterationno, sheet, subiter, parasheet);
		}
		public static void initialize(String dbpath, String sheet)
		{
			CRAFT_DB.dbpath = dbpath;
			setparameters(sheet);
		}
		
		//#############################################################################
		//Function Name    	: getConnected
		//Description     	: Function to connect to the database
		//Input Parameters 	: None
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		private static void getConnected()
		{
			//closeConnection();
			try {
//				c1= java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+dbpath+";READONLY=FALSE");
				c1= java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls, *.xlsx, *.xlsm, *.xlsb)};DBQ="+dbpath+";READONLY=FALSE");
			System.out.println("After the connection established");	
			System.out.println("Connected DB Path: "+dbpath);
			} 
			catch (Exception e) {
				System.out.println(dbpath);
				e.printStackTrace();
				
				try {
					c1.close();
					System.out.println("Closing the connection");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
			
		}
			/*try {
				c1= java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Text Driver (*.txt;*.csv)};DBQ="+dbpath+";READONLY=FALSE");
				/*final String DBURL = "jdbc:odbc:"+dbpath;
			
				
				try {
					Class.forName("org.relique.jdbc.csv.CsvDriver");

					//Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver"); 
				    Connection conn = DriverManager.getConnection(   DBURL,   "",      "");
			    } catch (SQLException e) {
					  e.printStackTrace();
					  try {
						  c1.close();
					  } catch (SQLException e1) {
						  e1.printStackTrace();
					  }
				
				   }
			}
			//catch(Exception e){System.out.println(e.toString());}*/

		//#############################################################################
		//Function Name    	:  closeConnection
		//Description     	: Function to close the connection
		//Input Parameters 	: None
		//Return Value    	: None
		//Author		: 
		//Date Created		: 
		//#############################################################################
		private static void closeConnection()
		{
			try {
				c1.close();
				System.out.println("Closing the connection");
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		
		//#############################################################################
		//Function Name    	: executequery
		//Description     	: Function to execute the query
		//Input Parameters 	: query, dbpath
		//Return Value    	: CachedRowSet
		//Author			: 
		//Date Created		: 
		//#############################################################################
		public static CachedRowSet executequery(String query,String dbpath)
		{
			CRAFT_DB.dbpath=dbpath;
			Statement st1 = null;
			ResultSet rs =null;
			CachedRowSetImpl css = null;
			getConnected();
			try {
				st1 = c1.createStatement();
				if(Util.debug)
				{
					JOptionPane.showMessageDialog(null, "query = "+query);
				}
				rs= st1.executeQuery(query);
				System.out.println("Resultset Size: "+rs.getFetchSize());
				System.out.println("Resultset Row Count: "+rs.getRow());
				while(!rs.next()){
					System.out.println(rs.getString(2));
					rs.next();
				}
				css= new CachedRowSetImpl();
				css.populate(rs);
										
			} 
			catch (SQLException e) {
				
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
			return css;
		}
		
		
		
		//#############################################################################
		//Function Name    	: getData
		//Description     	: Function to get the data from the testdata sheet
		//Input Parameters 	: colName
		//Return Value    	: String
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static String getData(String colName) 
		{
			String query = "SELECT "+colName+" FROM ["+sheet+ "$] where TC_ID ='"+testcase+"' and Iteration ='"+iterationno+"'";
			return getDat(colName, query);
		}
		//#############################################################################
		//Function Name    	: getParametrizedData
		//Description     	: Function to get the parametrised  checkpoints from the parametrisedcheckpoint sheet
		//Input Parameters 	: colName
		//Return Value    	: Strdata
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static String getParametrizedData(String colName) 
		{
			String query = "SELECT "+colName+" FROM ["+PSheet+ "$] where TC_ID ='"+testcase+"' and Iteration ='"+iterationno+"'";
			return getDat(colName, query);
		}
		
		
	                //  /*private static String getData(String colName,boolean truncateTime)
		//{
		//	String query = "SELECT "+colName+" FROM ["+sheet+ "$] where TC_ID ='"+testcase+"' and Iteration ="+iterationno;
		//	String data =  getDat(colName, query);
		//	if(truncateTime)
		//	{
		//		data = remtime(data);
		//	}
		//	return data;
		//	
		//}
		//private static String getParametrizedData(String colName,boolean truncateTime)
		//{
		//	String query = "SELECT "+colName+" FROM ["+PSheet+ "$] where TC_ID ="+testcase+" and Iteration ="+iterationno+"";
		//	String data = getDat(colName, query);
		//	if(truncateTime)
		//	{
		//		data = remtime(data);
		//	}
		//	return data;
		//}*/

		//#############################################################################
		//Function Name    	: remtime
		//Description     	: Function to get the remaining time
		//Input Parameters 	: data
		//Return Value    	: StrTime
		//Author		: 
		//Date Created		: 
		//#############################################################################
		public static String remtime(String data)
		{
			
				String[] time = data.split(":");
				if(time.length >2)
				{
					int index = data.indexOf(":");
					index = index-2;
					data = data.substring(0,index);
				}
			
			return data;
		}
		
		//#############################################################################
		//Function Name    	: getDat
		//Description     	: Function to help the getData function retrieve the data from the testdata sheet
		//Input Parameters 	: colName, query
		//Return Value    	: StrData
		//Author		: 
		//Date Created	: 
		//#############################################################################
		private static String getDat(String colName,String query)
		{
			String refchar = Util.GetValue("DataReferenceIdentifier","#");
			String data = null;
			ResultSet rs =null;
			Statement st1 = null;
			String dbpathbackup = dbpath;
			try {
				
				getConnected();
				st1 = c1.createStatement();
				rs= st1.executeQuery(query);
				rs.next();
				int i =0;
				while(i!=subiter-1)
				{
					rs.next();
					i++;
				}
				data = rs.getString(colName);
				if(data.startsWith(refchar))
				{
					String[] ref = data.split(refchar);
					dbpath = dbpath.substring(0,dbpath.lastIndexOf("\\"))+ "\\Common Testdata.xls";
					String query1 = "Select  *  from [Common Testdata$] where TD_ID = '"+ref[1]+"'";
					getConnected();
					st1 = c1.createStatement();
					rs= st1.executeQuery(query1);
					rs.next();
					data = rs.getString(colName);
					dbpath = dbpathbackup;
				}
				
			} catch (SQLException e) {
				CRAFT_Report.LogInfo("Fetching Data from Datatable", "Testcase : "+testcase +" ColumnName : "+colName+" SubiterationNo : "+subiter +"    Exception : "+e.toString(),Status.Failed_to_fetch_data);

				//System.out.println(e.toString());
				System.out.println(colName +"-"+sheet+"-"+testcase+"-"+ iterationno);
				e.printStackTrace();
				
			}
			finally
			{
				try {
					rs.close();
					st1.close();
					closeConnection();
					
					
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
				
			}
			return data;
		}

		//#############################################################################
		//Function Name    	: getExcelODBCConnection
		//Description     	: Function to get connection to both .xls & .xlsx files
		//Input Parameters 	: Excel file path
		//Return Value    	: 
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static Connection getExcelODBCConnection(String excelFilePath)
		{
			String myDB = "";
			Connection con = null;
			try{
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
//					String runmanagerPath = Util.homePath+"\\Run Manager.xls";
					System.out.println("excelFilePath: "+excelFilePath);
					myDB = "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+excelFilePath+";DriverID=22;READONLY=true";
					// String myDB = "jdbc:odbc:MyExcelDSN;DBQ=d:\\excel_2007.xlsx;";
					con = DriverManager.getConnection(myDB, "", "");
				}
				catch(Exception e){}
				return con;
		}
		
		
}//End of class

