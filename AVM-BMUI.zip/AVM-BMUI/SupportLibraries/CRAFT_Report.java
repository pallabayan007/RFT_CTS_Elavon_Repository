package SupportLibraries;
import resources.SupportLibraries.CRAFT_ReportHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.text.html.HTML;
import Driver.DriverScript;

/**
 * Description   : Functional Test Script
 * @author 
 *
 */
public class CRAFT_Report extends CRAFT_ReportHelper
{	
	/**
	 * Script Name   : <b>CRAFT_Report</b>
	 * Generated     : <b></b>
	 * Subject   	 : 
	 * Test Purpose  : 
	 * /Requirement(s)
	 * Covered
	 * Original Host : WinXP Version2002 Service Pack 3
	 * Assumption(s) : 
	 * @since  
	 * @author 
	 */

		// TODO Insert code here
		static String RFTResPath = "";
		public static boolean error = false;
		public enum Status {
		    PASS,FAIL,Failed_to_fetch_data,DONE,BC_PASSED,BC_FAILED
		}
		public void testMain(Object[] args) 
		{
			// TODO Insert code here
		}
		public static String summaryStart = "";
		public static String summaryEnd = "";
		public static String summaryTotalExeTime = "";
		public static int overallPass = 0;
		public static int overallFail = 0;
		public static int overallNotExecuted = 0;
		public static int overallExecuted = 0;
		public static int totalScrNo = 0;
		

		 //#############################################################################
		//Function Name    	: createSummaryHeader
		//Description     	: Function to create the summary header
		//Input Parameters 	: HtmlSummaryFile,ExcelSummaryFile
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static void createSummaryHeader(String HtmlSummaryFile,String ExcelSummaryFile,String projectName)
		{
			 CRAFT_HTMLResults.createSummaryHeader(HtmlSummaryFile,projectName);
//			 CRAFT_ExcelResults.createSummaryHeader(ExcelSummaryFile,projectName);
		}
		public static void createSummaryHeader(String HtmlSummaryFile,String projectName)
		{
			 CRAFT_HTMLResults.createSummaryHeader(HtmlSummaryFile,projectName);			 
		}

		 //#############################################################################
		//Function Name    	: createTestcaseHeader
		//Description     	: Function to create testcase header
		//Input Parameters 	: HtmlTestcaseFile, ExcelTestCaseFile,ScreenshotPath
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static void createTestcaseHeader(String HtmlTestcaseFile,String ScreenshotPath)
		{
			CRAFT_HTMLResults.createTestCaseHeader(HtmlTestcaseFile,ScreenshotPath);
//			CRAFT_ExcelResults.createTestCaseHeader(ExcelTestCaseFile);
		}

		 //#############################################################################
		//Function Name    	: closeTestcaseReportandUpdateSummary
		//Description     	: Function to  close the testcase report and update the summary
		//Input Parameters 	: None
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static void closeTestcaseReportandUpdateSummary(String filePath)
		{
			CRAFT_HTMLResults.closeTestCase(filePath);
//			CRAFT_ExcelResults.closeTestCase();
			updateSummary();
		}

		 //#############################################################################
		//Function Name    	: closeTestcaseReport
		//Description     	: Function to close the testcase report
		//Input Parameters 	: None
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static void closeTestcaseReport(String filePath)
		{
			CRAFT_HTMLResults.closeTestCase(filePath);
//			CRAFT_ExcelResults.closeTestCase();
			
		}

		 //#############################################################################
		//Function Name    	: updateSummary
		//Description     	: Function to update the summary
		//Input Parameters 	: None
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		
		private static void updateSummary()
		{
			CRAFT_HTMLResults.addRowtoSummary();
//			CRAFT_ExcelResults.addRowtoSummary();
		}

		 //#############################################################################
		//Function Name    	: closeSummary
		//Description     	: Function to close summary
		//Input Parameters 	: None
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static void closeSummary(String filePath)
		{
			CRAFT_HTMLResults.closeSummary(filePath);
//			CRAFT_ExcelResults.closeSummary();
		}

		 //#############################################################################
		//Function Name    	: LogInfo, strDescription, strStatus
		//Description     	: Function to LogInfo into the reports
		//Input Parameters 	:  strStepName
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		
		public static void LogInfo(String strStepName,String strDescription,Status strStatus)
		{
			boolean st = true;
			try
			{
//				CRAFT_ExcelResults.addRowtoTestCase(strStepName, strDescription, strStatus);
				CRAFT_HTMLResults.addRowtoTestCase(strStepName,strDescription,strStatus);
				if(strStatus.equals(Status.FAIL)||strStatus.equals(Status.Failed_to_fetch_data))
				{
					st= false;
				}
				logTestResult(strStepName, st, strDescription);
			}
			catch(Exception e)
			{
				
			}
		}
		
		 //#############################################################################
		//Function Name    	: LogSummary, strDescription, strStatus
		//Description     	: Function to LogInfo into the reports
		//Input Parameters 	:  strStepName
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		
		public static void LogSummary(String tsId,String scrDescription,String status,String execTime)
		{
//			boolean st = true;
			try
			{
//				CRAFT_ExcelResults.addRowtoTestCase(strStepName, strDescription, strStatus);
				CRAFT_HTMLResults.addRowtoSummary(tsId,scrDescription,status,execTime);
//				if(strStatus.equals(Status.FAIL)||strStatus.equals(Status.Failed_to_fetch_data))
//				{
//					st= false;
//				}
//				logTestResult(strStepName, st, strDescription);
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}

		 //#############################################################################
		//Function Name    	: insertIteration
		//Description     	: Function to insert an Iteration
		//Input Parameters 	: iteration
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static void insertIteration(int iteration)
		{
			CRAFT_HTMLResults.insertIteration(((Integer)iteration).toString());
		}
		
		//#############################################################################
		//Function Name    	: insertScenario
		//Description     	: Function to insert an Scenario
		//Input Parameters 	: Scenario Name
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		public static void insertScenario(String scenarioName)
		{
			CRAFT_HTMLResults.insertScenario(scenarioName);
		}

		 //#############################################################################
		//Function Name    	: LogError
		//Description     	: Function to Log the Error
		//Input Parameters 	: Errordesc
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		
		public static void LogError(String Errordesc)
		{
			error = true;
			LogInfo("Error",Errordesc,Status.FAIL);
		}

		 //#############################################################################
		//Function Name    	: startRep
		//Description     	: Function to start the report .
		//Input Parameters 	: startRep
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		
		public static void startRep(String testCaseName,String businesscomp,int iterationNo,int subiterationNo,String ScenarioName )
		{
			String path = Util.homePath;
//			String testdatasheet =Util.GetValue("TestDataSheet", "TestData"); 
//			String paradatasheet =Util.GetValue("CheckPointSheet", "ParameterizedCheckpoints"); 
//			
//			String dbpath = path+"\\Datatables\\"+ScenarioName+".xls";
			
//			String as= testCaseName.replaceFirst("BusinessComponents.", "");
//			CRAFT_DB.initialize(as,iterationNo,subiterationNo,testdatasheet,paradatasheet,dbpath);
			
//			String timestamp = "Run_"+Util.getCurrentDatenTime("dd-MM-yy")+"_"+Util.getCurrentDatenTime("H-mm-ss a");
			String resultPath = path+"\\Results\\"+Util.timestamp;
			String ExcelResPath = resultPath+"\\Excel Results";
//			String HtmlResPath = resultPath+"\\HTML Results";
//			String ScreenshotsPath = resultPath+"\\Screenshots";
			Util.HtmlScenarioResPath = Util.HtmlScenarioResPath+"\\"+businesscomp;
			
			RFTResPath = resultPath+"\\RFT Results";
			try           
			{        
				new File(ExcelResPath).mkdirs();
				new File(Util.HtmlScenarioResPath).mkdirs();
				new File(RFTResPath).mkdirs();
			}
			catch(Exception ex )
			{
				
			}
//			createTestcaseHeader(Util.HtmlScenarioResPath+"\\"+businesscomp+".html",ExcelResPath+"\\"+businesscomp+".xls",ScreenshotsPath);
//			insertIteration(iterationNo);
			LogInfo("Start Component", "Invoking BusinessComponent:"+businesscomp,Status.DONE);  
		}


		//#############################################################################
		//Function Name    	: closeRep
		//Description     	: Function to close the rep
		//Input Parameters 	: businesscomp
		//Return Value    	: None
		//Author		: 
		//Date Created	: 
		//#############################################################################
		
		public static void closeRep(String businesscomp,String filePath)
		{
			LogInfo("End Component", "Exiting BusinessComponent:"+businesscomp,Status.DONE);
			closeTestcaseReport(filePath);
			String path = Util.homePath;
			String src =path+"_logs\\"+businesscomp;
			String dest = RFTResPath;
			Util.copyDirectory(src, dest);
		}
		
}

