
import java.io.File;
import java.net.InetAddress;

import resources.Fusebox_BMUI_TxnListAddNote_028Helper;
import Driver.DriverScript;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class Fusebox_BMUI_TxnListAddNote_028 extends Fusebox_BMUI_TxnListAddNote_028Helper
{
	/**
	 * Script Name   : <b>Fusebox_BMUI_TxnListTxnListAddNote_028</b>
	 * Generated     : <b>Jan 3, 2012 8:33:56 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/01/03
	 * @author axbane1
	 */
	
	
	
	
	public static int iteration =0;
	public static int subiteration = 1;
	public static String testcase=""; 
	public static String desc = null;
	public static boolean error = false;
	String businessComponent="";
	long iterationCount = 0;
	boolean skipKeyword = false;
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
//		String[] bc = new String[1];
		
		//To run a TestCase directly, give Scenario, test case, description, iteration start, and iteration end.
//		String Scenario = "Scenario3";
		testcase = this.getClass().getName();
		desc ="desc";
//		int start = 1;
//		int end =1;
		
		String path = Util.homePath;
//		String dbpath =path+"\\Datatables\\"+Scenario+".xls";
//		Util.timestamp = "Run_"+Util.getCurrentDatenTime("dd-MM-yy")+"_"+Util.getCurrentDatenTime("H-mm-ss a");
		String resultPath = path+"\\Results\\"+Util.timestamp;
//		String ExcelResPath = resultPath+"\\Excel Results";
		Util.HtmlScenarioResPath = resultPath+"\\HTML Results\\"+testcase;
//		String RFTResPath = resultPath+"\\RFT Results";
//		String ScreenshotsPath = resultPath+"\\Screenshots";
		
		error = false;
//		String onError = Util.GetValue("OnError", "NextTestCase");
//		setCurrentLogFilter(DISABLE_LOGGING);
//		System.out.println(RFTResPath);
		
		//This section is created for RQM initiated execution only
		try{
			if(Util.isRQMExecution){
				Util.isRQMRunmanager = true;
				DriverScript.isRQMExecDriver = true;
				logInfo("Testing through RQM");				
//				logInfo(""+args.length+args[0].toString()+"");				
	      		if(args.length>0){
	      			Util.setDatatable(testcase,args[0].toString());
	      		}
	      		else{
	      			Util.setDatatable(testcase,"");
	      		}
	      		callScript("Driver.DriverScript");
	      		return;
	      	}
		}
		catch(Exception e){
			logInfo(e.getMessage());
		}		
		//End of section is created for RQM initiated execution only
		
		try 
		{        
//			new File(ExcelResPath).mkdirs();
//			new File(Util.HtmslScenarioResPath).mkdirs();
//			new File(RFTResPath).mkdirs();
//			new File(ScreenshotsPath).mkdirs();
			new File(Util.screenshotPath).mkdirs();
//			CRAFT_Report.createTestcaseHeader(Util.indvResPath+"\\"+testcase+".html", Util.screenshotPath);
		}
		catch(Exception ex){}	
		
		try{
			//Checking for the existence of RQM window and minimizing it if required
			if(browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).exists()){
				browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).minimize();
			}//End of Checking for the existence of RQM window and minimizing it if required
			
			//Iterating through the data pool
			CRAFT_Report.insertScenario(testcase);
			CRAFT_Report.LogInfo("Start Scenario","Invoking Scenario: "+testcase,Status.DONE);
			while(!dpDone()){
				Util.skipKeyword = false;
				skipKeyword = false;
				iterationCount++;
//				CRAFT_Report.createTestcaseHeader(Util.HtmlScenarioResPath+"\\"+testcase+".html", ExcelResPath+"\\"+testcase+".xls",ScreenshotsPath);
				CRAFT_Report.insertIteration((int)iterationCount);				
				
				//Calling business component user log on
				businessComponent = "Business_Components.UserLogon";
				String[] userId = new String[2];
				userId[0] = dpString("User ID");
				userId[1] = dpString("Password");
				callScript(businessComponent,userId);
				//---------End of business component---------
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
				
				if(!skipKeyword){
					//Calling business component Gateway GBM Hierarchy Choice
					businessComponent = "Business_Components.GatewayBMUIHierarchyChoice";	
					String[] gateHeir = new String[2];
					gateHeir[0] = dpString("Hierarchy Name");
					gateHeir[1] = dpString("View");
					callScript(businessComponent,gateHeir);
					//---------End of business component---------
				}
				
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
					
				if(!skipKeyword){
					//Calling business component Txn search
					businessComponent = "Business_Components.TxnSearch";	
					String[] txnSearch = new String[14];
					txnSearch[0] = dpString("Account No");
					txnSearch[1] = dpString("Reference No");
					txnSearch[2] = dpString("Client Ref No");
					txnSearch[3] = dpString("Token Id");
					txnSearch[4] = dpString("System Batch No");
					txnSearch[5] = dpString("Site Id");
					txnSearch[6] = dpString("Start Date");
					txnSearch[7] = dpString("End Date");
					txnSearch[8] = dpString("Batch Status");
					txnSearch[9] = dpString("View Txn By");
					txnSearch[10] = dpString("Txn Type");
					txnSearch[11] = dpString("Txn Id");
					if(txnSearch[12]==null
							|| txnSearch[12].isEmpty()){
						txnSearch[12] = dpString("Status List");
					}
					txnSearch[13] = dpString("Enter Date");
					
					callScript(businessComponent,txnSearch);
					//---------End of business component---------
				}
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
				
				if(!skipKeyword){
					//Calling business component TxnAddNote
					businessComponent = "Business_Components.TxnAddNote";	
					String[] noteTxn = new String[3];
					noteTxn[0] = dpString("Batch Status");				
					noteTxn[1] = dpString("Notes");
					noteTxn[2] = dpString("Multi Record Notes Req YesNo");
					callScript(businessComponent,noteTxn);				
					//---------End of business component---------
				}
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}
				
				if(!skipKeyword){
					//Calling business component user log off
					businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
				}
				
				//Scenario end report
				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
				
				//Check for single or multiple iteration
				if(!Util.allIterationReq){
					break;
				}//End of if for single or multiple iterations
				else{
					dpNext();
				}//End of else for single or multiple iterations				
				
			}//End data pool iteration	
			
//			//Scenario end report
//			if(!error && !CRAFT_Report.error
//					  && Util.scenarioStatus)
//			{
//				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
//			}
//			else
//			{
////				reportError(onError);
//				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
//			}
			
			
		}//End of try for scenario execution
		catch(Exception ex){
			ex.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing scenario: "+testcase,ex.toString(),Status.BC_FAILED);
			//Calling business component user log off
			String businessComponent = "Business_Components.UserLogoff";			
			callScript(businessComponent);
			//---------End of business component---------
		
		}//End of catch for scenario execution		
		finally{
			//Reseting the run manager to false in case it is initiated by RQM
			if(Util.isRQMRunmanager){
				Util.resetDatatable(testcase);
				Util.isRQMExecution = true;
				Util.isRQMRunmanager = false;
			}
		}		  
//		return bc;
	}
}