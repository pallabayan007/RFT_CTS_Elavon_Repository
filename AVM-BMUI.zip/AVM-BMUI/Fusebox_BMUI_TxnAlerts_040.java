
import java.io.File;
import java.net.InetAddress;

import resources.Fusebox_BMUI_TxnAlerts_040Helper;
import Driver.DriverScript;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class Fusebox_BMUI_TxnAlerts_040 extends Fusebox_BMUI_TxnAlerts_040Helper
{
	/**
	 * Script Name   : <b>Fusebox_BMUI_TxnAlerts_040</b>
	 * Generated     : <b>Feb 1, 2012 3:58:15 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/02/01
	 * @author sxghos1
	 */
	
	public static int iteration =0;
	public static int subiteration = 1;
	public static String testcase=""; 
	public static String desc = null;
	public static boolean error = false;
	String businessComponent="";
	long iterationCount = 0;
	boolean skipKeyword = false;
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
//		String[] bc = new String[1];
		
		//To run a TestCase directly, give Scenario, test case, description, iteration start, and iteration end.
//		String Scenario = "Scenario3";
		testcase = this.getClass().getName();
		desc ="desc";
//		int start = 1;
//		int end =1;
		
		String path = Util.homePath;
//		String dbpath =path+"\\Datatables\\"+Scenario+".xls";
//		Util.timestamp = "Run_"+Util.getCurrentDatenTime("dd-MM-yy")+"_"+Util.getCurrentDatenTime("H-mm-ss a");
		String resultPath = path+"\\Results\\"+Util.timestamp;
//		String ExcelResPath = resultPath+"\\Excel Results";
		Util.HtmlScenarioResPath = resultPath+"\\HTML Results\\"+testcase;
//		String RFTResPath = resultPath+"\\RFT Results";
//		String ScreenshotsPath = resultPath+"\\Screenshots";
		
		error = false;
//		String onError = Util.GetValue("OnError", "NextTestCase");
		
		//This section is created for RQM initiated execution only
		try{
			if(Util.isRQMExecution){
				Util.isRQMRunmanager = true;
				DriverScript.isRQMExecDriver = true;
				logInfo("Testing through RQM");				
//				logInfo(""+args.length+args[0].toString()+"");	
//				logInfo("Iterations: ="+args[0].toString()+"=="+args.length);
	      		if(args.length>0){
	      			Util.setDatatable(testcase,args[0].toString());
	      		}
	      		else{
	      			Util.setDatatable(testcase,"");
	      		}
	      		callScript("Driver.DriverScript");
	      		return;
	      	}
		}
		catch(Exception e){
			logInfo(e.getMessage());
		}		
		//End of section is created for RQM initiated execution only
		
		
//		System.out.println(RFTResPath);
		try 
		{        
//			new File(ExcelResPath).mkdirs();
//			new File(Util.HtmslScenarioResPath).mkdirs();
//			new File(RFTResPath).mkdirs();
//			new File(ScreenshotsPath).mkdirs();
			new File(Util.screenshotPath).mkdirs();
//			CRAFT_Report.createTestcaseHeader(Util.indvResPath+"\\"+testcase+".html", Util.screenshotPath);
		}
		catch(Exception ex){}	
		
		try{
			//Iterating through the data pool
			CRAFT_Report.insertScenario(testcase);
			CRAFT_Report.LogInfo("Start Scenario","Invoking Scenario: "+testcase,Status.DONE);
			while(!dpDone()){
				Util.skipKeyword = false;
				skipKeyword = false;
				iterationCount++;
//				CRAFT_Report.createTestcaseHeader(Util.HtmlScenarioResPath+"\\"+testcase+".html", ExcelResPath+"\\"+testcase+".xls",ScreenshotsPath);
				CRAFT_Report.insertIteration((int)iterationCount);				
				
				//Calling business component user log on
				businessComponent = "Business_Components.UserLogon";
				String[] userId = new String[2];
				userId[0] = dpString("User ID");
				userId[1] = dpString("Password");
				callScript(businessComponent,userId);
				//---------End of business component---------
				System.out.println("Util.skipKeyword:"+Util.skipKeyword);
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{	
					skipKeyword = true;
				}	

				System.out.println("skipKeyword:"+skipKeyword);
				if(!skipKeyword){
					//Calling business component TMAlert
					businessComponent = "Business_Components.TMAlert";				
					callScript(businessComponent);
					//---------End of business component---------
					
				}
				
				//Scenario end report
				if(error || CRAFT_Report.error
						  || Util.skipKeyword)
				{
					skipKeyword = true;
				}

				
				if(!skipKeyword){
					//Calling business component user log off
					businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
				}
			
				//Scenario end report
				CRAFT_Report.LogInfo("End Scenario","Exiting Scenario: "+testcase,Status.DONE);
				
				System.out.println("Scenario Util.allIterationReq: "+Util.allIterationReq);
				//Check for single or multiple iteration
				if(!Util.allIterationReq){
					break;
				}//End of if for single or multiple iterations
				else{
					dpNext();
				}//End of else for single or multiple iterations				
				
			}//End data pool iteration			
			
		}//End of try for scenario execution
		catch(Exception ex){
			ex.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing scenario: "+testcase,ex.toString(),Status.BC_FAILED);
			//Calling business component user log off
			String businessComponent = "Business_Components.UserLogoff";			
			callScript(businessComponent);
			//---------End of business component---------
		
		}//End of catch for scenario execution		
		finally{
			//Reseting the run manager to false in case it is initiated by RQM
			if(Util.isRQMRunmanager){
				Util.resetDatatable(testcase);
				Util.isRQMExecution = true;
				Util.isRQMRunmanager = false;
			}
		}	  
//		return bc;
		
		
	}//End of test Main
	
}//End of class
