package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.ReverseFileHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxghos1
 */
public class ReverseFile extends ReverseFileHelper
{
	/**
	 * Script Name   : <b>ReverseFile</b>
	 * Generated     : <b>Dec 11, 2011 2:43:25 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/12/11
	 * @author sxghos1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "ReverseTPPFile";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 1)
			{
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 0 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 0 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					
				}						       		
			}
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from TPP File List page,Settlement Control Batch Search -> Settlement Control File List
			 * ---Ending on Home page, i.e. , Home tab
			 */
						
//			String BatchFileStatus = "";			
			int loopUBound = 0;	
			String multiRecordTPPReq = (String) args[0];
			
			
			//Verifying whether the Reverse TPP File button is enabled or disabled			
			GuiTestObject button_ReverseTPP = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Reverse TPP File");
			if(button_ReverseTPP!= null){
				button_ReverseTPP.waitForExistence(20, 2);
				if(button_ReverseTPP.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Reverse TPP File button is enabled in TPP File List Page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Reverse TPP File button is enabled in TPP File List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_ReverseTPP.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Reverse TPP File button is disabled rightly in TPP File List Page while no records are selected");
				}
				
			}
			else{
				System.out.println("Reverse TPP File button is absent in TPP File List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Reverse TPP File button is absent in File List page", Status.BC_FAILED);
				return;
			}//End of Verifying whether the Reverse TPP File button is enabled or disabled
			
	
			
			//Selecting the TPP File for Reverse TPP File
			RegularExpression regExTPPSearch = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
			String view = "Expanded View";
			//Selecting the records to Change Status a TPP in transaction search list page				
			ArrayList<GuiTestObject> list_SelectTPPSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTPPSearch,"Html.TABLE", ".text", view);
			StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
			System.out.println("list_SelectTPPSearchResultList size: "+list_SelectTPPSearchResultList.size());
			if(list_SelectTPPSearchResultList.size()!=0){
//				loopUBound = 1;
				if(multiRecordTPPReq.equalsIgnoreCase("False")){
					loopUBound = 1;
				}
				else if(list_SelectTPPSearchResultList.size()>4){
					loopUBound = 4;
				}
				else if(list_SelectTPPSearchResultList.size()<4){
					loopUBound = list_SelectTPPSearchResultList.size();
				}
				
				//Looping through the matching records
				for(int loop=0;loop<loopUBound;loop++){
					System.out.println("checkbox_SearchRecord : "+list_SelectTPPSearchResultList.get(loop).getProperty(".text").toString());
					checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectTPPSearchResultList.get(loop);
//					System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
					if(checkbox_SearchRecord!=null){
//						System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//						System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//						checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//															Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
						checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
															atColumn(atIndex(0))));
						sleep(1);
//						break;
					}
					else{
						System.out.println("Record not matching ");
						continue;
					}
				}
			}
			else{
				System.out.println("No matching record found in TPP List Page with Expanded View");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No matching record found in TPP List Page with Expanded View", Status.BC_FAILED);
				return;
			}//End of Selecting the TPP Files for Reverse TPP File
			
			//Selecting the Reverse TPP File button to Reverse TPP File the selected records			
			GuiTestObject button_ReverseTPPFile = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Reverse TPP File");
			if(button_ReverseTPPFile!= null){
				button_ReverseTPPFile.waitForExistence(20, 2);
				//Checking whether the Reverse TPP File button is enabled or disabled
				if(button_ReverseTPPFile.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Reverse TPP File button is disabled in TPP File List Page even after selecting records");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Reverse TPP File button is disabled in TPP File List Page even after selecting records", Status.BC_FAILED);
					return;
				}
				else if(button_ReverseTPPFile.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					button_ReverseTPPFile.click();
					sleep(3);
					//Checking for the existence of the Reverse TPP File confirm existence 
					GuiTestObject popup_ReverseTPPFile = Util.getMappedObject("Html.DIV", ".text", "Reverse TPP File");
					if(popup_ReverseTPPFile!=null){
						//Selecting Cancel button to cancel the Reverse TPP File pop up 			
						GuiTestObject button_CancelReverseTPPFile = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
						if(button_CancelReverseTPPFile!= null){
							button_CancelReverseTPPFile.waitForExistence(10, 2);
							button_CancelReverseTPPFile.click();
							sleep(2);
							button_ReverseTPPFile.waitForExistence(10,2);
						}
						else{
							System.out.println("Reverse TPP File button is absent on Reverse TPP File pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Reverse TPP File button is absent on Reverse TPP File pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for Cancel button existence check
						
						//Selecting the Reverse TPP File button again to make the Reverse TPP File pop up re-appear
						button_ReverseTPPFile.click();
						sleep(5);
						
						//Selecting Print button to print the Reverse TPP File pop up 			
						GuiTestObject button_PrintReverseTPP = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Print");
						if(button_PrintReverseTPP!= null){
							System.out.println("Inside print button");
							button_PrintReverseTPP.waitForExistence(10, 2);
							button_PrintReverseTPP.click();
							sleep(2);
							//Searching for the print in landscape confirmation pop-up 			
							GuiTestObject popup_PrintLandscape = (GuiTestObject)Util.getMappedObject("Html.DialogStatic", ".text", "Please print in landscape mode for best results");
							if(popup_PrintLandscape!= null){
								System.out.println("Inside print Landscape");
								popup_PrintLandscape.waitForExistence(10, 2);
								sleep(2);
								//Selecting ok button on the landscape printing warning pop up  			
								GuiTestObject button_OkPrintPopUp = (GuiTestObject)Util.getMappedObject("Html.DialogButton", ".text", "OK");
								if(button_OkPrintPopUp!= null){
									System.out.println("Inside print OK Button");
									button_OkPrintPopUp.waitForExistence(10, 2);
									button_OkPrintPopUp.click();
									sleep(2);
									//Checking the pop up in case of no printer is configured in the machine
									if(printwindowNoPrinterConfig().exists()
											&& printwindowNoPrinterConfig().ensureObjectIsVisible()){

										if(!printwindowNoPrinterConfig().isEnabled()){
											printwindowNoPrinterConfig().activate();
										}
										System.out.println("Inside No Configuration Print Selection Window");
										printwindowNoPrinterConfig().click();
										if(nobutton().exists()
												&& nobutton().ensureObjectIsVisible()){
											nobutton().click();
											sleep(2);
										}
									}
									//End of Checking the pop up in case of no printer is configured in the machine
									//checking for the existence of the printer select option box
									if(printwindow().exists()
											&& printwindow().ensureObjectIsVisible()){
										System.out.println("printwindow().exists(): "+printwindow().exists()+" printwindow().ensureObjectIsVisible(): "+printwindow().ensureObjectIsVisible());
										System.out.println("Inside print Selection Window");
										//Checking for the existence of cancel button on printer selection window
										System.out.println("cancelbutton().exists(): "+cancelbutton().exists()+" cancelbutton().ensureObjectIsVisible(): "+cancelbutton().ensureObjectIsVisible());
										if(cancelbutton().exists()
												&& cancelbutton().ensureObjectIsVisible()){											
											System.out.println("Inside print selection window cancel");
											cancelbutton().click();
											sleep(2);
										}
										else{
											System.out.println("Cancel button is absent on Printer selection window while selecting to print");
											error = true;
											Util.scenarioStatus = false;
											CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on Printer selection window while selecting to print", Status.BC_FAILED);
											return;
										}//End of Checking for the existence of cancel button on printer selection window										
									}
									else{									
										System.out.println("Printer selection window is not visible while selecting to print");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Printer selection window is not visible while selecting to print", Status.BC_FAILED);
										return;
									}//End of checking for the existence of the printer select option box
								}
								else{
									System.out.println("Ok button not available on the print landscape pop up warning window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Ok button not available on the print landscape pop up warning window", Status.BC_FAILED);
									return;
								}//End of else for ok button existence check on print landscape warning pop up
							}
							else{
								System.out.println("Landscape mode printing warning window is absent while clicked on the print button on Reverse TPP File pop-up confirmation window");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Landscape mode printing warning window is absent while clicked on the print button on Reverse TPP File pop-up confirmation window", Status.BC_FAILED);
								return;
							}//End of else for searching for the print confirmation pop-up
						}
						else{
							System.out.println("Print button is absent on Reverse TPP File pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Print button is absent on Reverse TPP File pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for print button existence check	
						
					}//End of Checking for the existence of the Reverse TPP File confirm existence
					
				}//End of Checking whether the Reverse TPP File button is enabled or disabled
				
			}//End of Selecting the Reverse TPP File button to Reverse TPP File the selected records			
			
					
			//Selecting Submit button to submit the Reverse TPP File pop up 			
//			GuiTestObject button_SubmitReverseTPPFile = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
			RegularExpression regExSubmiteReverseButton = new RegularExpression("x-auto-[0-9].*",false);
			ArrayList<GuiTestObject> button_SubmitReverseTPPFileList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".id",regExSubmiteReverseButton,"Html.BUTTON", ".value", "Submit");
			System.out.println("button_SubmitReverseTPPFileList size: "+button_SubmitReverseTPPFileList.size());
			GuiTestObject button_SubmitReverseTPPFile = null;
			button_SubmitReverseTPPFile = button_SubmitReverseTPPFileList.get(button_SubmitReverseTPPFileList.size()-1);
			if(button_SubmitReverseTPPFile!= null){
				button_SubmitReverseTPPFile.waitForExistence(10, 2);
				button_SubmitReverseTPPFile.click();
				sleep(5);
				
			}
			else{
				System.out.println("Reverse TPP File Submit button is absent on Reverse TPP File pop-up confirmation window");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Reverse TPP File Submit button is absent on Reverse TPP File pop-up confirmation window", Status.BC_FAILED);
				return;
				
			}//End of else for Submit button existence check
			
			//Checking for the existence of the submit confirmation pop up		
			GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.DIV", ".text", "Reverse TPP File Confirmation");
			if(popup_SubmitConfirm==null){			
				System.out.println("Submit confirmation pop up not present");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Submit confirmation pop up not present", Status.BC_FAILED);
				return;			
			}
			else{
				System.out.println("Submit confirmation pop up is present");	
				popup_SubmitConfirm.waitForExistence(30, 2);
				
				//Selecting the Cancel button on the confirmation pop up 		
				ArrayList<GuiTestObject> button_ConfirmCancelList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
				GuiTestObject button_ConfirmCancel = null;
				button_ConfirmCancel = button_ConfirmCancelList.get(button_ConfirmCancelList.size()-1);
				if(button_ConfirmCancel!=null){
					button_ConfirmCancel.click();	
					sleep(2);
				}
				else{
					System.out.println("Cancel button not present on submit confirmation pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
					return;
				}//End of Cancel button on the confirmation pop up
				
				//Clicking Submit button again
				button_SubmitReverseTPPFile.click();
				popup_SubmitConfirm.waitForExistence(10, 2);
				
				//Selecting the Confirm button on the confirmation pop up 		
				RegularExpression regExConfirmButton = new RegularExpression("x-auto-[0-9].*",false);
				ArrayList<GuiTestObject> button_ConfirmList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".id",regExConfirmButton,"Html.BUTTON", ".value", "Yes, reverse file");
				System.out.println("button_ConfirmList size: "+button_ConfirmList.size());
				GuiTestObject button_Confirm = null;
				button_Confirm = button_ConfirmList.get(button_ConfirmList.size()-1);
				if(button_Confirm!=null){
					button_Confirm.click();	
					sleep(12);
				}
				else{
					System.out.println("Confirm button not present on submit confirmation pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
					return;
					
				}//End of Confirm button on the confirmation pop up
				
			}//End of existence of the submit confirmation pop up check
		
		
			//Waiting for the Successful message to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);

			//Checking successful submission message
			String statusChangeSuccessMsg = "TPP file(s) successfully reversed !";
			String statusChangeSuccessMsgDetails = "";
			ArrayList<GuiTestObject> msg_StatusChangeSuccessList = Util.getGWTMappedObjects("Html.DIV",".className","body-text x-component");
			GuiTestObject msg_StatusChangeSuccess = null;
			if(msg_StatusChangeSuccessList.size()<1){
				System.out.println("File reversed Successfully message not found");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "File reversed Successfully message not found", Status.BC_FAILED);
				return;
			}
			System.out.println("msg_StatusChangeSuccessList.size():"+msg_StatusChangeSuccessList.size());
			
			
			for(int loop=0;loop<msg_StatusChangeSuccessList.size();loop++){			
				System.out.println("Property:"+msg_StatusChangeSuccessList.get(loop).getProperty(".text").toString());
				if(msg_StatusChangeSuccessList.get(loop).getProperty(".text").toString().contains(statusChangeSuccessMsg)){
					statusChangeSuccessMsgDetails = msg_StatusChangeSuccessList.get(loop).getProperty(".text").toString();
					msg_StatusChangeSuccess = msg_StatusChangeSuccessList.get(loop);
					System.out.println("loop: "+loop);
					break;
				}
			}
			
			String statusChangeSuccessMsgExpected  = loopUBound+" of "+loopUBound+" TPP file(s) successfully reversed !";
			System.out.println("statusChangeSuccessMsgExpected: "+statusChangeSuccessMsgExpected);
			if(msg_StatusChangeSuccess!= null){
				msg_StatusChangeSuccess.waitForExistence(15, 2);
				if(statusChangeSuccessMsgDetails.equalsIgnoreCase(statusChangeSuccessMsgExpected)){
					System.out.println(statusChangeSuccessMsgDetails);
				}
				else{
					System.out.println(statusChangeSuccessMsgDetails);
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Got message \""+statusChangeSuccessMsgDetails+"\" While expecting message \""+statusChangeSuccessMsgExpected, Status.BC_FAILED);
					return;
				}			
			}
			else{				
				System.out.println("No File reverse successful message found");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No File reverse successful message found", Status.BC_FAILED);
				return;
			}//End of Checking successful submission message			
			
			
			//Selecting the Cancel button on the Reverse TPP File pop up 		
			GuiTestObject button_ConfirmCancel = Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
			if(button_ConfirmCancel!=null){
				button_ConfirmCancel.click();	
				sleep(5);
			}
			else{
				System.out.println("Cancel button not present on Reverse TPP File confirmation pop up");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on Reverse TPP File confirmation pop up", Status.BC_FAILED);
				return;
			}//End of Cancel button on the Reverse TPP File pop up
			
			//Waiting for the TPP File List page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			sleep(2);
			
			//Returning to the home tab as an exit point
			if(link_home().exists()
					|| link_home().ensureObjectIsVisible()){
				link_home().waitForExistence(20, 2);
				link_home().click();
				//Checking the existence of refresh button at the welcome area on home page				
				GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
				if(button_RefreshAtHome!= null){
					button_RefreshAtHome.waitForExistence(20, 2);
					button_RefreshAtHome.ensureObjectIsVisible();
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Home tab is absent in TPP File List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Home tab is absent in TPP File List Page", Status.BC_FAILED);
				return;
			}//End of returning to the home tab as an exit point
			
			//Component success message
			String cmpSuccessMsg = statusChangeSuccessMsgDetails;
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);

		}
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}

	}//End of Execute Component
	
}//End of class

