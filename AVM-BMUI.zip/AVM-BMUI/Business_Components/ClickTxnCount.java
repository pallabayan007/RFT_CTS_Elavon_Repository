package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.ClickTxnCountHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class ClickTxnCount extends ClickTxnCountHelper
{
	/**
	 * Script Name   : <b>ClickTxnCount</b>
	 * Generated     : <b>Jan 16, 2012 5:40:13 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/01/16
	 * @author axbane1
	 */
	
	boolean error = false;
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "ClickTxnCount";
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 2)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 2 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 2 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()

	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Batch List page, Batch List Transaction Count Link -> Transaction List
			 * ---Ending on Transaction List
			 */

			String batchStatus = (String) args[0];	
//			batchStatus = batchStatus.toUpperCase();
			String view = "";
			String tsComponentName = "ClickTxnCount";	
			int searchStringTxnCount = 0;
			String noOfTxnSearchPg = "";
			int totalTxnNoSearchPg = 0;	
			String searchStringSystemBatchNo = "";
			int searchSystemBatchNo = 0;
			String sysBatchRowNo = (String) args[1];
			int sysbatchRowNumber = 0;
			if(!sysBatchRowNo.isEmpty()){
				sysbatchRowNumber = Integer.parseInt(sysBatchRowNo)-1;
			}
			else{
				sysbatchRowNumber = -1;
			}			 
			System.out.println("sysbatchRowNumber: "+sysbatchRowNumber);
			

			RegularExpression regExBatchSearch = new RegularExpression("batchListGrid_x-auto-[0-9].*",false);
			if(batchStatus.isEmpty()){
				view = "View";
				//Selecting the records in transaction list page				
				ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", view);
				StatelessGuiSubitemTestObject link_TxnCountSearchRecord = null;
				String searchedTxnString = "";
				System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
				//Checking for user defined batch row number
				if(sysbatchRowNumber>=0){
					link_TxnCountSearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(sysbatchRowNumber);
					System.out.println("link_TxnCountSearchRecord Text: "+link_TxnCountSearchRecord.getProperty(".text").toString());
					searchedTxnString = list_SelectBatchSearchResultList.get(sysbatchRowNumber).getProperty(".text").toString();
					searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf("View")+4, searchedTxnString.length()).trim();
					searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
					System.out.println("searchedTxnString: "+searchedTxnString);
					searchStringTxnCount = Integer.parseInt(searchedTxnString);
					System.out.println("searchStringTxnCount: "+searchStringTxnCount);	
				}
				else{
					//Looping through the batch list for batches having transaction count>0
					for(int loop=0;loop<list_SelectBatchSearchResultList.size();loop++){
						System.out.println("link_TxnCountSearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
						link_TxnCountSearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
						if(link_TxnCountSearchRecord!=null){
							searchedTxnString = list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString();
							searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf("View")+4, searchedTxnString.length()).trim();
							searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
							System.out.println("searchedTxnString: "+searchedTxnString);
							searchStringTxnCount = Integer.parseInt(searchedTxnString);
							System.out.println("searchStringTxnCount: "+searchStringTxnCount);						
							
							//Checking for headless or stratus batches
							if(searchStringTxnCount>0){
								System.out.println("Got batch with some Txns in loop: "+loop);
								break;
							}						
							else{
								System.out.println("Got batch with 0 Txn in loop: "+loop);
								continue;
							}
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
					}//End of Looping through the batch list for batches having transaction count>0
					
				}//End of Checking for user defined batch row number				
				
				
				//Extracting system batch number
				searchStringSystemBatchNo = link_TxnCountSearchRecord.getProperty(".text").toString();
				System.out.println("searchStringSystemBatchNo in first: "+searchStringSystemBatchNo);
				searchStringSystemBatchNo = searchStringSystemBatchNo.substring(searchStringSystemBatchNo.indexOf(":")+5, searchStringSystemBatchNo.length()).trim();
				searchStringSystemBatchNo = searchStringSystemBatchNo.substring(0, searchStringSystemBatchNo.indexOf(" ")).trim();
				System.out.println("searchStringSystemBatchNo: "+searchStringSystemBatchNo);
				searchSystemBatchNo = Integer.parseInt(searchStringSystemBatchNo);
				System.out.println("searchSystemBatchNo: "+searchSystemBatchNo);
				
				//Selecting the intended transaction count link for headless and stratus batch
				if(searchSystemBatchNo<10000){
					link_TxnCountSearchRecord.click(atCell(atRow(atIndex(0)), 
							atColumn(atIndex(11))));
					sleep(10);
				}
				else if(searchSystemBatchNo>=10000){
					
					//Selecting the user batch details view link for going deeper for Headless batch
					link_TxnCountSearchRecord.click(atCell(atRow(atIndex(0)), 
							atColumn(atIndex(10))));
					
					//Waiting for the batch list to populate on the batch list page and loading message to disappear
					for(int loop=0;loop<20;loop++){
						ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
						System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
						if(progressBar_LoadingList.size()>=1){
							for(int i=0;i<progressBar_LoadingList.size();i++){
								System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
								System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
							}
							GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
							System.out.println("Progressbar checking loopcount: "+loop);
							if(progressBar_Loading!=null){
								System.out.println("The Txn list is still NOT populated");
								sleep(2);
								continue;					
							}
							else{
								System.out.println("The Txn list is populated");
								break;
							}
						}//End of if for progress bar loading
						else{
							System.out.println("The Txn list is populated");
							break;
						}//End of else for progress bar loading
						
					}//End of for statement to check the progress bar loading 
			
					sleep(5);
					
					//Selecting the records in transaction search list page
					view = "Expanded View";
					RegularExpression regExBatchSearchHeadless = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
					ArrayList<GuiTestObject>list_SelectBatchSearchResultHeadlessList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearchHeadless,"Html.TABLE", ".text", view);
					StatelessGuiSubitemTestObject link_TxnCountSearchRecordHeadless = null;
					searchedTxnString = "";
					System.out.println("list_SelectBatchSearchResultHeadlessList size: "+list_SelectBatchSearchResultHeadlessList.size());
					//Looping through the batch list for batches having transaction count>0
					for(int loop=0;loop<list_SelectBatchSearchResultHeadlessList.size();loop++){
						System.out.println("link_TxnCountSearchRecordHeadless : "+list_SelectBatchSearchResultHeadlessList.get(loop).getProperty(".text").toString());
						link_TxnCountSearchRecordHeadless = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultHeadlessList.get(loop);
						if(link_TxnCountSearchRecordHeadless!=null){
							searchedTxnString = list_SelectBatchSearchResultHeadlessList.get(loop).getProperty(".text").toString();
							System.out.println("searchedTxnStringHeadless: "+searchedTxnString);
							searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf("Expanded View")+13, searchedTxnString.length()).trim();
							searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
							System.out.println("searchedTxnStringHeadless: "+searchedTxnString);
							searchStringTxnCount = Integer.parseInt(searchedTxnString);
							System.out.println("searchStringTxnCountHeadless: "+searchStringTxnCount);							
							
							//Checking for headless or stratus batches
							if(searchStringTxnCount>0){
								System.out.println("Got batch with some Txns in loop: "+loop);
								break;
							}						
							else{
								System.out.println("Got batch with 0 Txn in loop: "+loop);
								continue;
							}
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
						
					}//End of for Looping through the batch list for batches having transaction count>0
					
					//Selecting the transaction count link for the headless Txn count
					link_TxnCountSearchRecordHeadless.click(atCell(atRow(atIndex(0)), 
							atColumn(atIndex(11))));
					
				}//End of else if for headless batch
				else{
					System.out.println("No System Batch Number found for the selected batch");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No System Batch Number found for the selected batch", Status.BC_FAILED);
					return;
				}//End of else for no system batch number found
				
				
			}//End of if for empty batch status check			
			else if(!batchStatus.isEmpty()){
				//Selecting the records in transaction search list page	
				batchStatus = batchStatus.toUpperCase();
				ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", batchStatus);
				StatelessGuiSubitemTestObject link_TxnCountSearchRecord = null;
				String searchedTxnString = "";
				System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
				//Checking for user defined batch row number
				if(sysbatchRowNumber>=0){
					link_TxnCountSearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(sysbatchRowNumber);
					System.out.println("link_TxnCountSearchRecord Text: "+link_TxnCountSearchRecord.getProperty(".text").toString());
					searchedTxnString = list_SelectBatchSearchResultList.get(sysbatchRowNumber).getProperty(".text").toString();
					searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf("View")+4, searchedTxnString.length()).trim();
					searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
					System.out.println("searchedTxnString: "+searchedTxnString);
					searchStringTxnCount = Integer.parseInt(searchedTxnString);
					System.out.println("searchStringTxnCount: "+searchStringTxnCount);	
				}
				else{//Looping through the batch list for batches having transaction count>0
					for(int loop=0;loop<list_SelectBatchSearchResultList.size();loop++){
						System.out.println("link_TxnCountSearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
						link_TxnCountSearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
						if(link_TxnCountSearchRecord!=null){
							searchedTxnString = list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString();
							searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf("View")+4, searchedTxnString.length()).trim();
							searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
							System.out.println("searchedTxnString: "+searchedTxnString);
							searchStringTxnCount = Integer.parseInt(searchedTxnString);
							System.out.println("searchStringTxnCount: "+searchStringTxnCount);				
							
							
							//Checking for headless or stratus batches
							if(searchStringTxnCount>0){
								System.out.println("Got batch with some Txns in loop: "+loop);
								break;
							}						
							else{
								System.out.println("Got batch with 0 Txn in loop: "+loop);
								continue;
							}
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
					}//End of Looping through the batch list for batches having transaction count>0
					
				}//End of Checking for user defined batch row number
				
				//Extracting system batch number
				searchStringSystemBatchNo = link_TxnCountSearchRecord.getProperty(".text").toString();
				System.out.println("searchStringSystemBatchNo in first: "+searchStringSystemBatchNo);
				searchStringSystemBatchNo = searchStringSystemBatchNo.substring(searchStringSystemBatchNo.indexOf(":")+5, searchStringSystemBatchNo.length()).trim();
				searchStringSystemBatchNo = searchStringSystemBatchNo.substring(0, searchStringSystemBatchNo.indexOf(" ")).trim();
				System.out.println("searchStringSystemBatchNo: "+searchStringSystemBatchNo);
				searchSystemBatchNo = Integer.parseInt(searchStringSystemBatchNo);
				System.out.println("searchSystemBatchNo: "+searchSystemBatchNo);
				
				//Selecting the intended transaction count link for headless and stratus batch
				if(searchSystemBatchNo<10000){
					link_TxnCountSearchRecord.click(atCell(atRow(atIndex(0)), 
							atColumn(atIndex(11))));
				}
				else if(searchSystemBatchNo>=10000){
					
					//Selecting the user batch details view link for going deeper for Headless batch
					link_TxnCountSearchRecord.click(atCell(atRow(atIndex(0)), 
							atColumn(atIndex(10))));
					
					//Waiting for the batch list to populate on the batch list page and loading message to disappear
					for(int loop=0;loop<20;loop++){
						ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
						System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
						if(progressBar_LoadingList.size()>=1){
							for(int i=0;i<progressBar_LoadingList.size();i++){
								System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
								System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
							}
							GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
							System.out.println("Progressbar checking loopcount: "+loop);
							if(progressBar_Loading!=null){
								System.out.println("The Txn list is still NOT populated");
								sleep(2);
								continue;					
							}
							else{
								System.out.println("The Txn list is populated");
								break;
							}
						}//End of if for progress bar loading
						else{
							System.out.println("The Txn list is populated");
							break;
						}//End of else for progress bar loading
						
					}//End of for statement to check the progress bar loading 
			
					sleep(5);
					
					//Selecting the records to Settle a batch in transaction search list page
					view = "Expanded View";
					RegularExpression regExBatchSearchHeadless = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
					ArrayList<GuiTestObject>list_SelectBatchSearchResultHeadlessList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearchHeadless,"Html.TABLE", ".text", view);
					StatelessGuiSubitemTestObject link_TxnCountSearchRecordHeadless = null;
					searchedTxnString = "";
					System.out.println("list_SelectBatchSearchResultHeadlessList size: "+list_SelectBatchSearchResultHeadlessList.size());
					//Looping through the batch list for batches having transaction count>0
					for(int loop=0;loop<list_SelectBatchSearchResultHeadlessList.size();loop++){
						System.out.println("link_TxnCountSearchRecordHeadless : "+list_SelectBatchSearchResultHeadlessList.get(loop).getProperty(".text").toString());
						link_TxnCountSearchRecordHeadless = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultHeadlessList.get(loop);
						if(link_TxnCountSearchRecordHeadless!=null){
							searchedTxnString = list_SelectBatchSearchResultHeadlessList.get(loop).getProperty(".text").toString();
							System.out.println("searchedTxnStringHeadless: "+searchedTxnString);
							searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf("Expanded View")+13, searchedTxnString.length()).trim();
							searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
							System.out.println("searchedTxnStringHeadless: "+searchedTxnString);
							searchStringTxnCount = Integer.parseInt(searchedTxnString);
							System.out.println("searchStringTxnCountHeadless: "+searchStringTxnCount);							
							
							//Checking for headless or stratus batches
							if(searchStringTxnCount>0){
								System.out.println("Got batch with some Txns in loop: "+loop);
								break;
							}						
							else{
								System.out.println("Got batch with 0 Txn in loop: "+loop);
								continue;
							}
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
						
					}//End of for Looping through the batch list for batches having transaction count>0
					
					//Selecting the transaction count link for the headless Txn count
					link_TxnCountSearchRecordHeadless.click(atCell(atRow(atIndex(0)), 
							atColumn(atIndex(11))));
					
				}//End of else if for headless batch
				else{
					System.out.println("No System Batch Number found for the selected batch");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No System Batch Number found for the selected batch", Status.BC_FAILED);
					return;
				}//End of else for no system batch number found							
				
			}//End of else if for non-empty batch status check
			else{
				System.out.println("Null Batch Status encountered");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Null Batch Status encountered", Status.BC_FAILED);
				return;
			}//End of else for null batch status check
				
			//Waiting for the batch list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Txn list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Txn list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Txn list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
	
			sleep(5);
	
			//Checking whether the search result has data or not
			GuiTestObject msg_NoSearchResult = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "No records found for Transaction List.");
			if(msg_NoSearchResult!= null){
				msg_NoSearchResult.waitForExistence(30, 2);
				System.out.println("No data in Transaction Search List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No data in Transaction Search List Page", Status.BC_FAILED);
				return;
			}
			else if(msg_NoSearchResult== null){
				//Fetching total number of records fetched on the Txn list page
				ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
				System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
				GuiTestObject text_totalNoOfTxnRecords = null;
				if(text_PageToolbarList.size()==0
						|| !text_PageToolbarList.get(text_PageToolbarList.size()-1).ensureObjectIsVisible()){
					System.out.println("Transaction search fetched NO DATA on the transaction list page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction search fetched NO DATA on the transaction list page", Status.BC_FAILED);
					return;
				}
				for(int loop=0;loop<text_PageToolbarList.size();loop++){
					text_totalNoOfTxnRecords = text_PageToolbarList.get(loop);
					System.out.println(text_totalNoOfTxnRecords.getProperty(".text").toString());
					System.out.println("DISABLED: "+text_totalNoOfTxnRecords.getProperty("disabled").toString());
					System.out.println("ARIA-HIDDEN: "+text_totalNoOfTxnRecords.getProperty("aria-hidden").toString());
					System.out.println("ARIA-DISABLED: "+text_totalNoOfTxnRecords.getProperty("aria-disabled").toString());
					System.out.println("ARIA-SECRET: "+text_totalNoOfTxnRecords.getProperty("aria-secret").toString());
					System.out.println("EXISTS:"+text_totalNoOfTxnRecords.exists());
					System.out.println("ENSURE OBJ:"+text_totalNoOfTxnRecords.ensureObjectIsVisible());
				}
				text_totalNoOfTxnRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
				if(text_totalNoOfTxnRecords!= null){
					text_totalNoOfTxnRecords.waitForExistence(10, 2);
					String text_TotalRecordsFetched = text_totalNoOfTxnRecords.getProperty(".text").toString();
					noOfTxnSearchPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(":")+1,text_TotalRecordsFetched.length()).trim();
					System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfTxnSearchPg :"+noOfTxnSearchPg);
					sleep(1);
					//Checking for the number of Txn received record on the Txn list page
					if(noOfTxnSearchPg.isEmpty()
							|| noOfTxnSearchPg==null){
						System.out.println("Transaction Number is absent on Transaction List page bottom toolbar");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Transaction Number is absent on Transaction List page bottom toolbar", Status.BC_FAILED);
						return;	
					}			
					else{
						totalTxnNoSearchPg = Integer.parseInt(noOfTxnSearchPg);
						if(totalTxnNoSearchPg == 0){
							System.out.println("No records fetched and displayed on the transaction list page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "No records fetched and displayed on the transaction list page", Status.BC_FAILED);
							return;
						}
						else{
							System.out.println("Transaction records fetched and displayed on the Transaction List-summary view Page is: "+totalTxnNoSearchPg);
						}
						
					}//End of Txn number check
					
					//Checking whether the txn counts on the batch list and txn list page matches or not
					if(totalTxnNoSearchPg!=searchStringTxnCount){
						System.out.println("Txn count number in batch list page("+searchStringTxnCount+") is not matching with Txn count number in Txn list page("+totalTxnNoSearchPg+")");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Txn count number in batch list page("+searchStringTxnCount+") is not matching with Txn count number in Txn list page("+totalTxnNoSearchPg+")", Status.BC_FAILED);
						return;
					}
					else{
						System.out.println("Txn count number in batch list page("+searchStringTxnCount+") is matching with Txn count number in Txn list page("+totalTxnNoSearchPg+")");
					}//End of Checking whether the txn counts on the batch list and txn list page matches or not
					
				}//End of Txn number fetching
				else{
					System.out.println("Transaction records number is absent on Transaction List-summary view Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction records number is absent on Transaction List-summary view Page", Status.BC_FAILED);
					return;
				}
		        
			}//End of else if for no record message search	
			
			//Component success message
			String cmpSuccessMsg = "Transaction count link with "+searchStringTxnCount+" transaction(s) is found on batch list page for batch with id "+searchSystemBatchNo+" and selected successfully.";
			System.out.println(cmpSuccessMsg);
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
			

		}
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}

	}//End of Execute component
	
}//End of class

