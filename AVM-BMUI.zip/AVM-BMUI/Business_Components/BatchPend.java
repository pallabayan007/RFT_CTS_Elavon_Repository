package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.BatchPendHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class BatchPend extends BatchPendHelper
{
	/**
	 * Script Name   : <b>BatchPend</b>
	 * Generated     : <b>Nov 16, 2011 4:39:30 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/16
	 * @author axbane1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "BatchPend";
	
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 2)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 2 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 2 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{

		//Place your Code here
		try{
			String batchStatus = (String) args[0];
			batchStatus = batchStatus.toUpperCase();
			String view = "";
			String multiRecordPending = (String) args[1];
			String notes = "Automation Test Notes";
//			String batchSettleGridPropText = "";
//			String noOfBatchSettleGrid = "";
			
//			//Searching the existence of the batch settlement recap table	
//			String settleGridTable = "Batch Settlement Recap";
//			GuiTestObject table_BatchSettleGrid = (GuiTestObject)Util.getMappedObject("Html.SPAN", ".text", settleGridTable);
//			if(table_BatchSettleGrid!= null){
//				table_BatchSettleGrid.waitForExistence(90, 2);
//				table_BatchSettleGrid.ensureObjectIsVisible();
//				//Searching the existence of the batch received link
//				RegularExpression regExBatchSettleGrid = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
//				ArrayList<GuiTestObject> link_SelectBatchSettleGridList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSettleGrid,"Html.TABLE", ".text", batchStatus);
//				System.out.println("link_SelectBatchSettleGridList size: "+link_SelectBatchSettleGridList.size());
//				StatelessGuiSubitemTestObject link_SelectBatchSettleGrid = (StatelessGuiSubitemTestObject) link_SelectBatchSettleGridList.get(0);			
//				if(link_SelectBatchSettleGrid!=null){
//					link_SelectBatchSettleGrid.waitForExistence(20, 2);
//					batchSettleGridPropText = link_SelectBatchSettleGrid.getProperty(".text").toString();
//					if(batchSettleGridPropText.isEmpty()){
//						System.out.println(""+batchStatus+"  Number text is absent on Batch Settlement Recap Grid table");
//						error = true;
//						Util.scenarioStatus = false;
//						CRAFT_Report.LogInfo(tsComponentName, ""+batchStatus+"  Number text is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
//						return;	
//					}
//					noOfBatchSettleGrid = batchSettleGridPropText.substring(batchSettleGridPropText.indexOf(batchStatus)+batchStatus.length(), batchSettleGridPropText.lastIndexOf(" ")).trim();
//					System.out.println("batchSettleGridPropText:"+batchSettleGridPropText+" : noOfBatchSettleGrid :"+noOfBatchSettleGrid);
//					
//					//Verifying whether the batch list has any batch to work on
//					if(Integer.parseInt(noOfBatchSettleGrid)==0){
//						System.out.println(""+batchStatus+" has no batch record on the batch list");
//						error = true;
//						Util.scenarioStatus = false;
//						CRAFT_Report.LogInfo(tsComponentName, ""+batchStatus+" has no batch record on the batch list", Status.BC_FAILED);
//						return;
//					}
//					
//					//Selecting the link with the no of batch with supplied status
//					ArrayList<GuiTestObject> link_SelectBatchConfNoList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".text",batchSettleGridPropText,"Html.A", ".text", noOfBatchSettleGrid);
//					System.out.println("link_SelectBatchConfNoList size: "+link_SelectBatchConfNoList.size());
//					GuiTestObject link_SelectBatchConfNo = (GuiTestObject) link_SelectBatchConfNoList.get(0);
//					if(link_SelectBatchConfNo!=null){
//						link_SelectBatchConfNo.waitForExistence(20, 2);
//						link_SelectBatchConfNo.click();
////						sleep(20);
//					}
//					else{
//						System.out.println(""+batchStatus+"  Number link is absent on Batch Settlement Recap Grid table");
//						error = true;
//						Util.scenarioStatus = false;
//						CRAFT_Report.LogInfo(tsComponentName, ""+batchStatus+"  Number link is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
//						return;
//					}
//				}
//				else{
//					System.out.println(""+batchStatus+"  entry is absent on Batch Settlement Recap Grid table");
//					error = true;
//					Util.scenarioStatus = false;
//					CRAFT_Report.LogInfo(tsComponentName, ""+batchStatus+"  entry is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
//					return;
//				}
//				
//			}
//			else{
//				System.out.println("Batch Settlement Recap Grid table is absent in Page");
//				error = true;
//				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Batch Settlement Recap Grid table is absent in Page", Status.BC_FAILED);
//				return;
//			}	
			
			//Waiting for the batch list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The batch list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The batch list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The batch list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 			
			sleep(5);
			
			//Verifying whether the Pending button is enabled or disabled			
			GuiTestObject button_PendBatch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Pending");
			if(button_PendBatch!= null){
				button_PendBatch.waitForExistence(20, 2);
				if(button_PendBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Pending button is enabled in Batch List Page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Pending button is enabled in Batch List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_PendBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Pending button is disabled rightly in Batch List Page while no records are selected");
				}
				
			}
			else{
				System.out.println("Pending button is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Pending button is absent in Batch List page", Status.BC_FAILED);
				return;
			}
			
			RegularExpression regExBatchSearch = new RegularExpression("batchListGrid_x-auto-[0-9].*",false);
			if(batchStatus.isEmpty()){
				view = "Expanded View";
				//Selecting the records to pend a batch in transaction search list page				
				ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", view);
				StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
				System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
				if(list_SelectBatchSearchResultList.size()!=0){
					int loopUBound = 0;
					if(multiRecordPending.equalsIgnoreCase("false")){
						loopUBound = 1;
					}
					else if(list_SelectBatchSearchResultList.size()>4){
						loopUBound = 4;
					}
					else if(list_SelectBatchSearchResultList.size()<4){
						loopUBound = list_SelectBatchSearchResultList.size();
					}
					
					//Looping through the matching records
					for(int loop=0;loop<loopUBound;loop++){
						System.out.println("checkbox_SearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
						checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
//						System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
						if(checkbox_SearchRecord!=null){
//							System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//							System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//							checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//																Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
							checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
																atColumn(atIndex(0))));
							sleep(1);
//							break;
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
					}
				}
				else{
					System.out.println("No matching record found in Batch List Page with Expanded View");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Batch List Page with Expanded View", Status.BC_FAILED);
					return;
				}
			}
			else if(!batchStatus.isEmpty()){
				//Selecting the records to pend a batch in transaction search list page
//				RegularExpression regExBatchSearch1 = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
				ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", batchStatus);
				StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
				System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
				if(list_SelectBatchSearchResultList.size()!=0){
					int loopUBound = 0;
					if(multiRecordPending.equalsIgnoreCase("false")){
						loopUBound = 1;
					}
					else if(list_SelectBatchSearchResultList.size()>4){
						loopUBound = 4;
					}
					else if(list_SelectBatchSearchResultList.size()<4){
						loopUBound = list_SelectBatchSearchResultList.size();
					}
					
					//Looping through the matching records
					for(int loop=0;loop<loopUBound;loop++){
						System.out.println("checkbox_SearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
						checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
//						System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
						if(checkbox_SearchRecord!=null){
//							System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//							System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//							checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//																Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
							checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
																atColumn(atIndex(0))));
							sleep(1);
//							break;
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
					}
				}
				else{
					System.out.println("No matching record found in Batch List Page for batch status: "+batchStatus);
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Batch List Page for batch status: "+batchStatus, Status.BC_FAILED);
					return;
				}
			}
			
			
			//Selecting the Pending button to pend the selected records			
			GuiTestObject button_PendingBatch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Pending");
			if(button_PendingBatch!= null){
				button_PendingBatch.waitForExistence(20, 2);
				//Checking whether the Pending button is enabled or disabled
				if(button_PendingBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Pending button is disabled in Batch List Page even after selecting records");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Pending button is disabled in Batch List Page even after selecting records", Status.BC_FAILED);
					return;
				}
				else if(button_PendingBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					button_PendingBatch.click();
					sleep(10);
					//Checking for the existence of the Pending batch confirm existence 
					GuiTestObject popup_PendBatchConfirm = Util.getMappedObject("Html.SPAN", ".text", "Pend Batch");
					if(popup_PendBatchConfirm!=null){
						//Selecting Cancel button to cancel the pend batch pop up 			
						GuiTestObject button_CancelBatchPend = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
						if(button_CancelBatchPend!= null){
							button_CancelBatchPend.waitForExistence(10, 2);
							button_CancelBatchPend.click();
							sleep(2);
							button_PendingBatch.waitForExistence(10,2);
						}
						else{
							System.out.println("Cancel Batch Pend button is absent on batch pend pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Cancel Batch Pend button is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for pend button existence check
						
						//Selecting the pending button again to make the pend batch pop up re-appear
						button_PendingBatch.click();
						sleep(10);
						
						//Selecting Print button to print the pend batch pop up 			
						GuiTestObject button_PrintBatchPend = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Print");
						if(button_PrintBatchPend!= null){
							System.out.println("Inside print button");
							button_PrintBatchPend.waitForExistence(10, 2);
							button_PrintBatchPend.click();
							sleep(2);
							//Searching for the print in landscape confirmation pop-up 			
							GuiTestObject popup_PrintLandscape = (GuiTestObject)Util.getMappedObject("Html.DialogStatic", ".text", "Please print in landscape mode for best results");
							if(popup_PrintLandscape!= null){
								System.out.println("Inside print Landscape");
								popup_PrintLandscape.waitForExistence(10, 2);
								sleep(2);
								//Selecting ok button on the landscape printing warning pop up  			
								GuiTestObject button_OkPrintPopUp = (GuiTestObject)Util.getMappedObject("Html.DialogButton", ".text", "OK");
								if(button_OkPrintPopUp!= null){
									System.out.println("Inside print OK Button");
									button_OkPrintPopUp.waitForExistence(10, 2);
									button_OkPrintPopUp.click();
									sleep(2);
									
									//Checking the pop up in case of no printer is configured in the machine
									if(printwindowNoPrinterConfig().exists()
											&& printwindowNoPrinterConfig().ensureObjectIsVisible()){

										if(!printwindowNoPrinterConfig().isEnabled()){
											printwindowNoPrinterConfig().activate();
										}
										System.out.println("Inside No Configuration Print Selection Window");
										printwindowNoPrinterConfig().click();
										if(nobutton().exists()
												&& nobutton().ensureObjectIsVisible()){
											nobutton().click();
											sleep(2);
										}
									}
									//End of Checking the pop up in case of no printer is configured in the machine
									
									//checking for the existence of the printer select option box
									if(printwindow().exists()
											&& printwindow().ensureObjectIsVisible()){
										System.out.println("printwindow().exists(): "+printwindow().exists()+" printwindow().ensureObjectIsVisible(): "+printwindow().ensureObjectIsVisible());
										System.out.println("Inside print Selection Window");
										//Checking for the existence of cancel button on printer selection window
										System.out.println("cancelbutton().exists(): "+cancelbutton().exists()+" cancelbutton().ensureObjectIsVisible(): "+cancelbutton().ensureObjectIsVisible());
										if(cancelbutton().exists()
												&& cancelbutton().ensureObjectIsVisible()){											
											System.out.println("Inside print selection window cancel");
											cancelbutton().click();
											sleep(2);
										}
										else{
											System.out.println("Cancel button is absent on Printer selection window while selecting to print");
											error = true;
											Util.scenarioStatus = false;
											CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on Printer selection window while selecting to print", Status.BC_FAILED);
											return;
										}//End of Checking for the existence of cancel button on printer selection window										
									}
									else{									
										System.out.println("Printer selection window is not visible while selecting to print");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Printer selection window is not visible while selecting to print", Status.BC_FAILED);
										return;
									}//End of checking for the existence of the printer select option box
								}
								else{
									System.out.println("Ok button not available on the print landscape pop up warning window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Ok button not available on the print landscape pop up warning window", Status.BC_FAILED);
									return;
								}//End of else for ok button existence check on print landscape warning pop up
							}
							else{
								System.out.println("Landscape mode printing warning window is absent while clicked on the print button on batch pend pop-up confirmation window");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Landscape mode printing warning window is absent while clicked on the print button on batch pend pop-up confirmation window", Status.BC_FAILED);
								return;
							}//End of else for searching for the print confirmation pop-up
						}
						else{
							System.out.println("Print Batch Pend button is absent on batch pend pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Print Batch Pend button is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for print button existence check			
					
						
						
						//Searching for the batch can't be pended text
						String text_BatchCantPend = "Batch(s) which cannot be Pended:"; 
						int screenTop_BatchCantPend = 0;
						GuiTestObject table_BatchCantPend = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", text_BatchCantPend);
						if(table_BatchCantPend!= null){
							table_BatchCantPend.waitForExistence(10, 2);	
							screenTop_BatchCantPend = (Integer) table_BatchCantPend.getProperty(".screenTop");
							System.out.println(screenTop_BatchCantPend);
						}
						else{
							System.out.println("Batch can't be pended table is absent on batch pend pop-up confirmation window");
//							error = true;
//							Util.scenarioStatus = false;
//							CRAFT_Report.LogInfo(tsComponentName, "Batch can't be pended table is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
//							return;
						}//End of else for batch can't be pended text
						
						//Searching for the batch to be pended text
						String text_BatchToBePended = "Batch(s) able to be pended:"; 
						int screenTop_BatchToBePended = 0;
						GuiTestObject table_BatchToBePended = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", text_BatchToBePended);
						if(table_BatchToBePended!= null){
							table_BatchToBePended.waitForExistence(10, 2);	
							screenTop_BatchToBePended=(Integer) table_BatchToBePended.getProperty(".screenTop");
							System.out.println(screenTop_BatchToBePended);
						}
						else{
							System.out.println("Batch to be pended table is absent on batch pend pop-up confirmation window");
//							error = true;
//							Util.scenarioStatus = false;
//							CRAFT_Report.LogInfo(tsComponentName, "Batch to be pended table is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
//							return;
						}//End of else for batch to be pended text
						
						StatelessGuiSubitemTestObject table_BatchCantPendRow = null;
						StatelessGuiSubitemTestObject table_BatchToBePendedRow = null;
						//Validating Submit button			
						GuiTestObject button_SubmitBatchPend = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
						if(button_SubmitBatchPend!= null){
							button_SubmitBatchPend.waitForExistence(10, 2);
							System.out.println("button_SubmitBatchPend.getProperty(aria-disabled).toString(): "+button_SubmitBatchPend.getProperty("aria-disabled").toString());
							//Validating whether the submit button is enabled/disabled
							if(button_SubmitBatchPend.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
								System.out.println("Submit Batch Pend button is disabled on batch pend pop-up confirmation window");
								//Selecting table for batch can't be pend		
//								RegularExpression regExBatchCantPend = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);								
								String tableBatchCantPendSearchString = ":";								
//								ArrayList<GuiTestObject> table_BatchCantPendObjList = Util.getGWTMappedObjects("Html.DIV", ".id", regExBatchCantPend, "Html.TABLE", ".text", tableBatchCantPendSearchString);
								ArrayList<GuiTestObject> table_BatchCantPendObjList = Util.getGWTMappedObjects("Html.TABLE", ".text", tableBatchCantPendSearchString);
//								table_BatchCantPendRow = (StatelessGuiSubitemTestObject) Util.getGWTSelectChildMappedObject("Html.DIV", ".id", regExAddress, "Html.TABLE", ".text", tableAddressSearchString);
								System.out.println("table_BatchCantPendObjList length: "+table_BatchCantPendObjList.size());
								for(int i=0;i<table_BatchCantPendObjList.size();i++){
									System.out.println("Obj Prop: "+table_BatchCantPendObjList.get(i).getProperty(".text").toString());
								}
								//Filling the Address Type field on the address table
								table_BatchCantPendRow = (StatelessGuiSubitemTestObject) table_BatchCantPendObjList.get(table_BatchCantPendObjList.size()-1);
								if(table_BatchCantPendRow!= null){
									sleep(1);									
									table_BatchCantPendRow.doubleClick(atCell( atRow(atIndex(0)), 
                                            									atColumn(atIndex(4))));
									browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys(notes);
									table_BatchCantPendRow.click(atCell( atRow(atIndex(0)), 
                                            							atColumn(atIndex(5))));
									
									sleep(2);
//									table_BatchCantPendRow.doubleClick(atCell( atRow(atIndex(0)), 
//						                    atColumn(atIndex(2))));
//									browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ENTER}");			
//									browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}{ENTER}{ENTER}{TAB}{ENTER}{ENTER}{TAB}{ENTER}{ENTER}{TAB}{ENTER}");
								}
								else{
									System.out.println("Batch can't be pended table is absent on batch pend pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Batch can't be pended table is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
									return;
								}//End of else for Batch can't be pended table on batch pend pop-up confirmation window							
								
								//Selecting Cancel button			
								GuiTestObject button_CancelBatchPended = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
								if(button_CancelBatchPended!= null){
									button_CancelBatchPended.waitForExistence(10, 2);
									button_CancelBatchPended.click();
									sleep(2);
									button_PendingBatch.waitForExistence(10,2);
								}
								else{
									System.out.println("Cancel Batch pend button is absent on batch pend pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Cancel Batch Pend button is absent on batch pends pop-up confirmation window", Status.BC_FAILED);
									return;
								}//End of else for cancel button existence check
								
							}//End of if for submit button disabled validation							
							else if(button_SubmitBatchPend.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
								System.out.println("Submit Batch Pend button is enabled on batch pend pop-up confirmation window");
								//Selecting table for batch to be pended		
//								RegularExpression regExBatchToBePend = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);								
//								String tableBatchToBePendSearchString = ":";								
								String tableBatchToBePendSearchString = ".";
//								ArrayList<GuiTestObject> table_BatchToBePendObjList = Util.getGWTMappedObjects("Html.DIV", ".id", regExBatchToBePend, "Html.TABLE", ".text", tableBatchToBePendSearchString);
								ArrayList<GuiTestObject> table_BatchToBePendObjList = Util.getGWTMappedObjects("Html.TABLE", ".text", tableBatchToBePendSearchString);
//								table_BatchCantPendRow = (StatelessGuiSubitemTestObject) Util.getGWTSelectChildMappedObject("Html.DIV", ".id", regExAddress, "Html.TABLE", ".text", tableAddressSearchString);
								System.out.println("table_BatchToBePendObjList length: "+table_BatchToBePendObjList.size());
								for(int i=0;i<table_BatchToBePendObjList.size();i++){
									System.out.println("Obj Prop: "+table_BatchToBePendObjList.get(i).getProperty(".text").toString());
								}
								
								//Assigning the batch can't pend and batch to be pended tables
								if(table_BatchToBePendObjList.size()>=1){									
									table_BatchToBePendedRow = (StatelessGuiSubitemTestObject) table_BatchToBePendObjList.get(table_BatchToBePendObjList.size()-1);
																	
									//Filling the batch to be pend row								
									if(table_BatchToBePendedRow!= null){
										sleep(1);
										table_BatchToBePendedRow.doubleClick(atCell( atRow(atIndex(0)), 
                                                									atColumn(atIndex(4))));
										browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys(notes);
										table_BatchToBePendedRow.click(atCell( atRow(atIndex(0)), 
                                                							atColumn(atIndex(5))));		
										sleep(2);
//										table_BatchCantPendRow.doubleClick(atCell( atRow(atIndex(0)), 
//							                    atColumn(atIndex(2))));
//										browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ENTER}");			
//										browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}{ENTER}{ENTER}{TAB}{ENTER}{ENTER}{TAB}{ENTER}{ENTER}{TAB}{ENTER}");
									}
									else{
										System.out.println("Batch to be pended table is absent on batch pend pop-up confirmation window");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Batch to be pended table is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
										return;
									}//End of else for Batch to be pended table on batch pend pop-up confirmation window
									
								}								
								else if(table_BatchToBePendObjList.size()<1){
									System.out.println("Number of tables found are not as expected on the batch pend confirm pop-up window");
									
								}//End of Assigning the batch can't be pended and batch to be pended tables	
								
								button_SubmitBatchPend.click();
								
								//Checking for the existence of the submit confirmation pop up		
								GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.SPAN", ".text", "Confirm Action");
								if(popup_SubmitConfirm==null){			
									System.out.println("Submit confirmation pop up not present");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Submit confirmation pop up not present", Status.BC_FAILED);
									return;			
								}
								else{
									System.out.println("Submit confirmation pop up is present");	
									popup_SubmitConfirm.waitForExistence(30, 2);
									
									//Selecting the Cancel button on the confirmation pop up 		
									ArrayList<GuiTestObject> button_ConfirmCancelList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
									GuiTestObject button_ConfirmCancel = null;
									
									if(button_ConfirmCancelList.size()<1){
										System.out.println("Cancel button not found on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not found on submit confirmation pop up", Status.BC_FAILED);
										return;
									}
									else{
										button_ConfirmCancel = button_ConfirmCancelList.get(button_ConfirmCancelList.size()-1);
									}
									
									if(button_ConfirmCancel!=null){
										button_ConfirmCancel.click();
										System.out.println("Selecting the Cancel button on submit confirmation action pop up");
										sleep(5);
									}
									else{
										System.out.println("Cancel button not present on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
										return;
									}//End of Cancel button on the confirmation pop up
									
									button_SubmitBatchPend.click();
									popup_SubmitConfirm.waitForExistence(30, 2);
									
									//Selecting the Confirm button on the confirmation pop up 		
									GuiTestObject button_Confirm = Util.getMappedObject("Html.BUTTON", ".value", "Confirm");
									if(button_Confirm!=null){
										button_Confirm.click();	
										sleep(20);
									}
									else{
										System.out.println("Confirm button not present on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
										return;
									}//End of Confirm button on the confirmation pop up
									
								}//End of existence of the submit confirmation pop up check
								
								//Searching for the successful pending message 
								String msg_PendString = "All selected batches have been successfully pended";
								GuiTestObject msg_BatchPendSuccess = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_PendString);
								if(msg_BatchPendSuccess!=null){
									msg_BatchPendSuccess.waitForExistence(30, 2);
									System.out.println("Batch pended successfully");			
												
								}
								else{
									System.out.println("Batch pending is unsuccessful");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName,"Batch pending is unsuccessful" , Status.BC_FAILED);
									return;
								}//End of searching for the successful pending message
								
								//Selecting the Done button on the pend batch pop-up		
								GuiTestObject button_Done = Util.getMappedObject("Html.BUTTON", ".value", "Done");
								if(button_Done!=null){
									button_Done.click();
									System.out.println("Clicking Done button on pend batch pop up");
									sleep(15);
								}
								else{
									System.out.println("Done button not present on pend batch pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Done button not present on pend batch pop up", Status.BC_FAILED);
									return;
								}//End of Done button on the delete batch pop-up
								
							}//End of else if for submit button enabled validation
							
						}//End of if for submit batch pend button on batch pend pop-up confirmation window
						else{
							System.out.println("Submit Batch Pend button is absent on batch pend pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Submit Batch Pend button is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for submit button on pend batch pop-up check					
						
					}//End of if for the pend batch confirm action pop up
					else{
						System.out.println("Pend batch confirm action popup is absent after clicking pending button");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Pend batch confirm action pop-up is absent after clicking pending button", Status.BC_FAILED);
						return;
					}//End of else for the pend batch confirm action pop up
				}//End of else if for pending button enable/disable check
				
			}//End of if for pend button existence check
			else{
				System.out.println("Pend button is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Pend button is absent in Batch List page", Status.BC_FAILED);
				return;
			}
			
			//Returning to the home tab as an exit point
			if(link_home().exists()
					|| link_home().ensureObjectIsVisible()){
				link_home().waitForExistence(20, 2);
				link_home().click();
				//Checking the existence of refresh button at the welcome area on home page				
				GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
				if(button_RefreshAtHome!= null){
					button_RefreshAtHome.waitForExistence(20, 2);
					button_RefreshAtHome.ensureObjectIsVisible();
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Home tab is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Home tab is absent in Batch List Page", Status.BC_FAILED);
				return;
			}//End of returning to the home tab as an exit point
		
			
			//Component success message
			String cmpSuccessMsg = "Selected Batch(s) have been pended successfully";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
		}
		catch(Exception e){
			
//			StackTraceElement[] sArr = e.getStackTrace();
//			System.out.println(sArr[sArr.length-1]);
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}

	}//End of Execute Component
	
}//End of class

