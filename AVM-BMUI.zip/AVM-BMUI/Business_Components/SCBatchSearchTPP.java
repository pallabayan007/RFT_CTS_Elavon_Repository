package Business_Components;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import resources.Business_Components.SCBatchSearchTPPHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class SCBatchSearchTPP extends SCBatchSearchTPPHelper
{
	/**
	 * Script Name   : <b>SCBatchSearchTPP</b>
	 * Generated     : <b>Nov 25, 2011 6:36:54 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/25
	 * @author axbane1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "SCBatchSearchTPP";
	
	
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 12)
			{
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 12 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 12 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					
				}						       		
			}
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
	
		//Place your Code here
		try{
			/*
			 * ---Starting from Home page,Home Tab -> Settlement Control Tab
			 * ---Ending on TPP File Search list page
			 */
			
			String batchView = (String) args[0];
			if(batchView.isEmpty()
					|| batchView==null){
				batchView = "TPP File";
			}
			System.out.println("batchView: "+batchView);
			String merBatchNo = (String) args[1];
			String sysBatchNo = (String) args[2];
			String siteId = (String) args[3];		
			String fileStatus = (String) args[4];
			fileStatus = fileStatus.toUpperCase();
			int listPosition = 0;
			String fileNumber = (String) args[5];
			String settlementId = (String) args[6];
			String tppName = (String) args[7];			
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			String yesterdayDt = new SimpleDateFormat("MM/dd/yyyy").format(cal.getTime());
			String startDate = (String) args[8];
			cal.add(Calendar.DATE, 2);
			String endDt = (String) args[9];
			String statusList = (String) args[10];
			String enterDate = (String) args[11];
			String noOfTPPFileSearchPg = "";
			int totalTPPFileNoSearchPg = 0;
			
			System.out.println(""+yesterdayDt);
			System.out.println(""+endDt);
			
			
			//Selecting the settlement control tab
			link_settlementControl().waitForExistence(20, 2);
			link_settlementControl().click();
			sleep(20);

			//Waiting for the Batch Search sub menu to appear & then selecting it					
			GuiTestObject button_BatchSearch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Batch Search");
			if(button_BatchSearch!= null){
				button_BatchSearch.waitForExistence(20, 2);
				button_BatchSearch.click();
				sleep(10);
			}
			else{
				System.out.println("Batch Search sub-menu is absent under Settlement Control Tab");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Batch Search sub-menu is absent under Settlement Control Tab", Status.BC_FAILED);
				return;
			}
			
			//Selecting the change hierarchy link
			text_changeHierarchy().waitForExistence(20, 2);
			text_changeHierarchy().click();
			sleep(5);
			

			//Checking the disabled hierarchy choice window
			String msg_HierDisable = "The current screen/navigation does not support Change Hierarchy.";
			GuiTestObject msg_HierDisableSelect = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_HierDisable);
			if(msg_HierDisableSelect!= null){
				msg_HierDisableSelect.waitForExistence(20, 2);
				System.out.println("Hierarchy choice is disabled properly while in Settlement Control Batch Search Page");
//				msg_HierDisableSelect.click();
				sleep(2);
			}
			else{
				System.out.println("Hierarchy choice is not disabled while in Settlement Control Batch Search Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Hierarchy choice is not disabled while in Settlement Control Batch Search Page", Status.BC_FAILED);
				return;
			}//End of Checking the disabled hierarchy choice window
			

			//Selecting the cancel button on the hierarchy choice window					
			GuiTestObject button_Cancel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
			if(button_Cancel!= null){
				button_Cancel.waitForExistence(20, 2);
				button_Cancel.click();
				sleep(10);
			}
			else{
				System.out.println("Cancel button is absent on Hierarchy choice window while in Settlement Control Batch Search Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on Hierarchy choice window while in Settlement Control Batch Search Page", Status.BC_FAILED);
				return;
			}//End of Selecting the cancel button on the hierarchy choice window
			
			if(batchView.equalsIgnoreCase("TPP File")){
				//Adding Batch View
				TextGuiTestObject text_BatchView = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", "TPP File");
				if(text_BatchView!=null){
					text_BatchView.waitForExistence(20, 2);
					text_BatchView.click();			
					text_BatchView.setText(batchView);
					sleep(2);
					//Selecting the Batch View from the drop down
//					RegularExpression regExBatchViewDropDwn = new RegularExpression("x-auto-[0-9].*",false);
					if(batchView.isEmpty()){
						System.out.println("The Batch View search string is empty");
					}
					else{
//						ArrayList<GuiTestObject> list_BatchViewList = Util.getGWTMappedObjects("Html.DIV",".id",regExBatchViewDropDwn, "Html.DIV",".text", batchView);
						ArrayList<GuiTestObject> list_BatchViewList = Util.getGWTMappedObjects("Html.DIV",".text", batchView);
						GuiTestObject list_BatchView = null;
						if(list_BatchViewList.size()==0){
							System.out.println("Batch View list dropdown not found on Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Batch View list dropdown not found on Settlement Control batch search page", Status.BC_FAILED);
							return;
						}					
						for(int i=0;i<list_BatchViewList.size();i++){
							System.out.println("list_BatchViewList: "+list_BatchViewList.get(i).getProperty(".text").toString());
						}
						list_BatchView = list_BatchViewList.get(list_BatchViewList.size()-1);
						if(list_BatchView!=null){
							System.out.println("Inside the Batch View dropdown list");	
							list_BatchView.click();
						}
						else{
							System.out.println("Batch View list dropdown doesn't contain value \""+batchView+"\" on Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Batch View list dropdown doesn't contain value \""+batchView+"\" on Settlement Control batch search page", Status.BC_FAILED);
							return;
						}
					}
					//End of selection of Batch View from drop down
					System.out.println(""+text_BatchView.getScreenPoint());
					
				}
				else{
					System.out.println("Batch View list dropdown not found on Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch View list dropdown not found on Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Batch View
				
				//Selecting Merchant Batch number			
				TextGuiTestObject text_MerBatchNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "posBatchId");
				if(text_MerBatchNo!= null){
					text_MerBatchNo.waitForExistence(10, 2);
					text_MerBatchNo.click();
					text_MerBatchNo.setText(merBatchNo);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("Merchant Batch No. is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Merchant Batch No. is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Merchant Batch number
				
				//Selecting System Batch No			
				TextGuiTestObject text_SysBatchNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "batchId");
				if(text_SysBatchNo!= null){
					text_SysBatchNo.waitForExistence(10, 2);
					text_SysBatchNo.click();
					text_SysBatchNo.setText(sysBatchNo);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("System Batch number is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "System Batch number is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of System Batch No
				
				//Selecting site id			
				TextGuiTestObject text_SiteId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "siteIdStr");
				if(text_SiteId!= null){
					text_SiteId.waitForExistence(10, 2);
					text_SiteId.click();
					text_SiteId.setText(siteId);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("Site Id is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Site Id is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of site id
				
				/*==========================
				 * Selecting the File Status
				 *///=======================				
				
				//Searching for the status position in the status list
				int statusCount = (int) Util.commaSeparatedWordCount(statusList);
				String[] statusListDet = new String[statusCount];
				statusListDet = (String[]) Util.commaSeparatedWordDetails(statusList, Util.commaSeparatedWordCount(statusList)); 
				for(int loopCount=0;loopCount<statusListDet.length;loopCount++){
					if(statusListDet[loopCount].toUpperCase().equalsIgnoreCase(fileStatus)){
						listPosition = loopCount;
						break;
					}
					else{
						continue;
					}
				}//End of Searching for the status position in the status list
				
				if(!fileStatus.isEmpty()
						&& listPosition >= 0){			
					//Selecting Status	
					ArrayList<GuiTestObject> select_FileStatusList = Util.getGWTMappedObjects("Html.DIV", ".text", fileStatus);
					System.out.println(select_FileStatusList.size());
					GuiTestObject select_FileStatus = null;
					//Checking whether the list box exists or not
					if(select_FileStatusList.size()!=0){
						//For statement w.r.t. status list box mapping
						for(int i=0;i<select_FileStatusList.size();i++){
							System.out.println("I: "+i);
							System.out.println("Id: "+select_FileStatusList.get(i).getProperty(".id").toString());
							System.out.println("Text: "+select_FileStatusList.get(i).getProperty(".text").toString());
							System.out.println("ROLE: "+select_FileStatusList.get(i).getProperty("role").toString());
							//Checking and mapping the status list box
							if(select_FileStatusList.get(i).getProperty("role").toString().equalsIgnoreCase("listbox")){
								select_FileStatus = select_FileStatusList.get(i);
								break;
							}
							else{
								continue;
							}//End of else for Checking and mapping the status list box
							
						}//End of for statement w.r.t. status list box mapping
						
						//Selecting the status
						if(select_FileStatus!=null){
							select_FileStatus.click();
							browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtUp}");		
							browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtUp}");
							//Browsing to the status by using down Arrow key
							for(int loop=0;loop<listPosition;loop++){
								browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtDown}");
								sleep(1);
							}//End of Browsing to the status by using down Arrow key
						}
						else{
							System.out.println("File  Status listbox not found in settlement control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "File  Status listbox not found in settlement control batch search page", Status.BC_FAILED);
							return;
						}//End of Selecting the status
						
					}//End of if for Checking whether the list box exists or not
					else{
						System.out.println("File  Status listbox is absent in settlement control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "File  Status listbox is absent in settlement control batch search page", Status.BC_FAILED);
						return;
					}//Checking whether the list box exists or not	
				}//End of if for file status & list position validation

				/*+++++++++++++++++++++++++++++++++
				 * End of Selecting the File Status
				 *///++++++++++++++++++++++++++++++
				
				
				//Selecting file number			
				TextGuiTestObject text_FileNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "fileNumber");
				if(text_FileNo!= null){
					text_FileNo.waitForExistence(10, 2);
					text_FileNo.click();
					text_FileNo.setText(fileNumber);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("File Number is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "File Number is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of file number
				
				//Selecting Settlement Id			
				TextGuiTestObject text_SettlementId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "settlementID");
				if(text_SettlementId!= null){
					text_SettlementId.waitForExistence(10, 2);
					text_SettlementId.click();
					text_SettlementId.setText(settlementId);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("Settlement Id is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Settlement Id is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Settlement Id
				
				
				//Adding TPP Name
				if(tppName.isEmpty()){
					System.out.println("The tpp name search string is empty");
				}
				else{
					TextGuiTestObject text_TppName = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "tppId");
					if(text_TppName!=null){			
						text_TppName.click();			
						text_TppName.setText(tppName);
						sleep(2);
						//Selecting the TPP Name from the drop down
//						RegularExpression regExTppNameDropDwn = new RegularExpression("x-auto-[0-9].*",false);
						if(tppName.isEmpty()){
							System.out.println("The tpp name search string is empty");
						}
						else{
//							ArrayList<GuiTestObject> list_TppNameList = Util.getGWTMappedObjects("Html.DIV",".id",regExTppNameDropDwn, "Html.DIV",".text", tppName);
							ArrayList<GuiTestObject> list_TppNameList = Util.getGWTMappedObjects("Html.DIV",".text", tppName);
							GuiTestObject list_TppName = null;
							if(list_TppNameList.size()==0){
								System.out.println("TPP Name list dropdown is absent on Settlement Control batch search page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "TPP Name list dropdown is absent on Settlement Control batch search page", Status.BC_FAILED);
								return;
							}
							for(int i=0;i<list_TppNameList.size();i++){
								System.out.println("list_TppNameList: "+list_TppNameList.get(i).getProperty(".text").toString());
							}
							
							list_TppName = list_TppNameList.get(list_TppNameList.size()-1);						
							if(list_TppName!=null){
								System.out.println("Inside the Tpp Name dropdown list");	
								list_TppName.click();
							}
							else{
								System.out.println("TPP Name list dropdown not found on Settlement Control batch search page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "TPP Name list dropdown not found on Settlement Control batch search page", Status.BC_FAILED);
								return;
							}
						}
						//End of selection of View Batch By from drop down
						System.out.println(""+text_TppName.getScreenPoint());
						//Setting the focus out of the view Batch by field 
//						if(text_ViewTranBy.hasFocus()){
//							text_ViewTranBy.setProperty(".hasFocus", false);
//						}
					}
					else{
						System.out.println("TPP Name list dropdown not found on Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "TPP Name list dropdown not found on Settlement Control batch search page", Status.BC_FAILED);
						return;
					}
				
				}//End of TPP Name
				
				//Searching and selecting Enter Date check-box			
				GuiTestObject checkbox_EnterDt = Util.getMappedObject("Html.DIV", ".text", "Enter Date");
				if(checkbox_EnterDt!= null 
							&& checkbox_EnterDt.ensureObjectIsVisible()){
					checkbox_EnterDt.waitForExistence(10, 2);
					if(enterDate.equalsIgnoreCase("Yes")
							&& !sysBatchNo.isEmpty()){
						checkbox_EnterDt.click();
						//Selecting Start Date			
						TextGuiTestObject text_StartDt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", yesterdayDt);
						if(text_StartDt!= null){
							text_StartDt.waitForExistence(10, 2);
							text_StartDt.click();
							text_StartDt.setText(startDate);
							sleep(2);
//							browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
						}
						else{
							System.out.println("Mandatory field(s) Start Date is absent in Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Start Date is absent in Settlement Control batch search page", Status.BC_FAILED);
							return;
						}//End of Start Date
						
						//Selecting End Date	
						ArrayList<GuiTestObject> text_EndDtList = Util.getGWTMappedObjects("Html.INPUT.text", ".value", Util.getCurrentDatenTime("MM/dd/yyyy"));
						if(text_EndDtList.size()!=0){
							TextGuiTestObject text_EndDt = (TextGuiTestObject) text_EndDtList.get(text_EndDtList.size()-1);
							if(text_EndDt!= null){
								text_EndDt.waitForExistence(10, 2);
								text_EndDt.click();
								text_EndDt.setText(endDt);
								sleep(2);
//								browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
							}
							else{
								System.out.println("Mandatory field(s) End Date is absent in Settlement Control batch search page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in Settlement Control batch search page", Status.BC_FAILED);
								return;
							}
						}
						else{
							System.out.println("Mandatory field(s) End Date not found in Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date not found in Settlement Control batch search page", Status.BC_FAILED);
							return;
						}//End of End Date
					}
					else{
						System.out.println("Enter date is not needed");
					}										
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					//Selecting Start Date			
					TextGuiTestObject text_StartDt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", yesterdayDt);
					if(text_StartDt!= null){
						text_StartDt.waitForExistence(10, 2);
						text_StartDt.click();
						text_StartDt.setText(startDate);
						sleep(2);
//						browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
					}
					else{
						System.out.println("Mandatory field(s) Start Date is absent in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Start Date is absent in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}//End of Start Date
					
					//Selecting End Date	
					ArrayList<GuiTestObject> text_EndDtList = Util.getGWTMappedObjects("Html.INPUT.text", ".value", Util.getCurrentDatenTime("MM/dd/yyyy"));
					if(text_EndDtList.size()!=0){
						TextGuiTestObject text_EndDt = (TextGuiTestObject) text_EndDtList.get(text_EndDtList.size()-1);
						if(text_EndDt!= null){
							text_EndDt.waitForExistence(10, 2);
							text_EndDt.click();
							text_EndDt.setText(endDt);
							sleep(2);
//							browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
						}
						else{
							System.out.println("Mandatory field(s) End Date is absent in Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in Settlement Control batch search page", Status.BC_FAILED);
							return;
						}
					}
					else{
						System.out.println("Mandatory field(s) End Date not found in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date not found in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}//End of End Date
					
				}//End of Enter date			

			}//End of if for TPP File selection as Batch View
			else if(batchView.equalsIgnoreCase("TPP Sub-Batch")){
				
				//Checking whether the mandatory field strings are empty or not
				if(sysBatchNo.isEmpty()){
					System.out.println("Mandatory field(s) System Batch No is blank in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) System Batch No is blank in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}
				else if(siteId.isEmpty()){
					System.out.println("Mandatory field(s) Site Id is blank in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Site Id is blank in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}
				else if(tppName.isEmpty()){
					System.out.println("Mandatory field(s) TPP Name is blank in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) TPP Name is blank in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Checking whether the mandatory field strings are empty or not
				
				
				//Adding Batch View
				TextGuiTestObject text_BatchView = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", "TPP File");
				if(text_BatchView!=null){
					text_BatchView.waitForExistence(20, 2);
					text_BatchView.click();			
					text_BatchView.setText(batchView);
					sleep(2);
					//Selecting the Batch View from the drop down
//					RegularExpression regExBatchViewDropDwn = new RegularExpression("x-auto-[0-9].*",false);
					if(batchView.isEmpty()){
						System.out.println("The Batch View search string is empty");
					}
					else{
//						ArrayList<GuiTestObject> list_BatchViewList = Util.getGWTMappedObjects("Html.DIV",".id",regExBatchViewDropDwn, "Html.DIV",".text", batchView);
						ArrayList<GuiTestObject> list_BatchViewList = Util.getGWTMappedObjects("Html.DIV",".text", batchView);
						GuiTestObject list_BatchView = null;
						if(list_BatchViewList.size()==0){
							System.out.println("Batch View list dropdown not found on Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Batch View list dropdown not found on Settlement Control batch search page", Status.BC_FAILED);
							return;
						}					
						for(int i=0;i<list_BatchViewList.size();i++){
							System.out.println("list_BatchViewList: "+list_BatchViewList.get(i).getProperty(".text").toString());
						}
						list_BatchView = list_BatchViewList.get(list_BatchViewList.size()-1);
						if(list_BatchView!=null){
							System.out.println("Inside the Batch View dropdown list");	
							list_BatchView.click();
						}
						else{
							System.out.println("Batch View list dropdown doesn't contain value \""+batchView+"\" on Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Batch View list dropdown doesn't contain value \""+batchView+"\" on Settlement Control batch search page", Status.BC_FAILED);
							return;
						}
					}
					//End of selection of Batch View from drop down
					System.out.println(""+text_BatchView.getScreenPoint());
					
				}
				else{
					System.out.println("Batch View list dropdown not found on Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch View list dropdown not found on Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Batch View
				
				//Selecting Merchant Batch number			
				TextGuiTestObject text_MerBatchNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "posBatchId");
				if(text_MerBatchNo!= null){
					text_MerBatchNo.waitForExistence(10, 2);
					text_MerBatchNo.click();
					text_MerBatchNo.setText(merBatchNo);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("Merchant Batch No. is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Merchant Batch No. is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Merchant Batch number
				
				//Selecting System Batch No			
				TextGuiTestObject text_SysBatchNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "batchId");
				if(text_SysBatchNo!= null){
					text_SysBatchNo.waitForExistence(10, 2);
					text_SysBatchNo.click();
					text_SysBatchNo.setText(sysBatchNo);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("System Batch number is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "System Batch number is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of System Batch No
				
				//Selecting site id			
				TextGuiTestObject text_SiteId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "siteIdStr");
				if(text_SiteId!= null){
					text_SiteId.waitForExistence(10, 2);
					text_SiteId.click();
					text_SiteId.setText(siteId);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("Site Id is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Site Id is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of site id
				
				//Selecting file number			
				TextGuiTestObject text_FileNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "fileNumber");
				if(text_FileNo!= null){
					text_FileNo.waitForExistence(10, 2);
					text_FileNo.click();
					text_FileNo.setText(siteId);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("File Number is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "File Number is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of file number
				
				//Selecting Settlement Id			
				TextGuiTestObject text_SettlementId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "settlementID");
				if(text_SettlementId!= null){
					text_SettlementId.waitForExistence(10, 2);
					text_SettlementId.click();
					text_SettlementId.setText(siteId);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("Settlement Id is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Settlement Id is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Settlement Id
				
				
				//Adding TPP Name
				TextGuiTestObject text_TppName = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "tppId");
				if(text_TppName!=null){			
					text_TppName.click();			
					text_TppName.setText(tppName);
					sleep(2);
					//Selecting the TPP Name from the drop down
//					RegularExpression regExTppNameDropDwn = new RegularExpression("x-auto-[0-9].*",false);
					if(tppName.isEmpty()){
						System.out.println("The tpp name search string is empty");
					}
					else{
//						ArrayList<GuiTestObject> list_TppNameList = Util.getGWTMappedObjects("Html.DIV",".id",regExTppNameDropDwn, "Html.DIV",".text", tppName);
						ArrayList<GuiTestObject> list_TppNameList = Util.getGWTMappedObjects("Html.DIV",".text", tppName);
						GuiTestObject list_TppName = null;
						if(list_TppNameList.size()==0){
							System.out.println("TPP Name list dropdown is absent on Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "TPP Name list dropdown is absent on Settlement Control batch search page", Status.BC_FAILED);
							return;
						}
						for(int i=0;i<list_TppNameList.size();i++){
							System.out.println("list_TppNameList: "+list_TppNameList.get(i).getProperty(".text").toString());
						}
						
						list_TppName = list_TppNameList.get(list_TppNameList.size()-1);						
						if(list_TppName!=null){
							System.out.println("Inside the Tpp Name dropdown list");	
							list_TppName.click();
						}
						else{
							System.out.println("TPP Name list dropdown not found on Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "TPP Name list dropdown not found on Settlement Control batch search page", Status.BC_FAILED);
							return;
						}
					}
					//End of selection of View Batch By from drop down
					System.out.println(""+text_TppName.getScreenPoint());
					//Setting the focus out of the view Batch by field 
//					if(text_ViewTranBy.hasFocus()){
//						text_ViewTranBy.setProperty(".hasFocus", false);
//					}
				}
				else{
					System.out.println("TPP Name list dropdown not found on Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "TPP Name list dropdown not found on Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of TPP Name
				
				//Searching and selecting Enter Date check-box			
				GuiTestObject checkbox_EnterDt = Util.getMappedObject("Html.DIV", ".text", "Enter Date");
				if(checkbox_EnterDt!= null 
						&& checkbox_EnterDt.ensureObjectIsVisible()){
					checkbox_EnterDt.waitForExistence(10, 2);
					if(enterDate.equalsIgnoreCase("Yes")
							&& !sysBatchNo.isEmpty()){
						checkbox_EnterDt.click();
						//Selecting Start Date			
						TextGuiTestObject text_StartDt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", yesterdayDt);
						if(text_StartDt!= null){
							text_StartDt.waitForExistence(10, 2);
							text_StartDt.click();
							text_StartDt.setText(startDate);
							sleep(2);
//							browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
						}
						else{
							System.out.println("Mandatory field(s) Start Date is absent in Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Start Date is absent in Settlement Control batch search page", Status.BC_FAILED);
							return;
						}//End of Start Date
						
						//Selecting End Date	
						ArrayList<GuiTestObject> text_EndDtList = Util.getGWTMappedObjects("Html.INPUT.text", ".value", Util.getCurrentDatenTime("MM/dd/yyyy"));
						if(text_EndDtList.size()!=0){
							TextGuiTestObject text_EndDt = (TextGuiTestObject) text_EndDtList.get(text_EndDtList.size()-1);
							if(text_EndDt!= null){
								text_EndDt.waitForExistence(10, 2);
								text_EndDt.click();
								text_EndDt.setText(endDt);
								sleep(2);
//								browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
							}
							else{
								System.out.println("Mandatory field(s) End Date is absent in Settlement Control batch search page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in Settlement Control batch search page", Status.BC_FAILED);
								return;
							}
						}
						else{
							System.out.println("Mandatory field(s) End Date not found in Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date not found in Settlement Control batch search page", Status.BC_FAILED);
							return;
						}//End of End Date
					}
					else{
						System.out.println("Enter date is not needed");
					}										
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					//Selecting Start Date			
					TextGuiTestObject text_StartDt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", yesterdayDt);
					if(text_StartDt!= null){
						text_StartDt.waitForExistence(10, 2);
						text_StartDt.click();
						text_StartDt.setText(startDate);
						sleep(2);
//						browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
					}
					else{
						System.out.println("Mandatory field(s) Start Date is absent in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Start Date is absent in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}//End of Start Date
					
					//Selecting End Date	
					ArrayList<GuiTestObject> text_EndDtList = Util.getGWTMappedObjects("Html.INPUT.text", ".value", Util.getCurrentDatenTime("MM/dd/yyyy"));
					if(text_EndDtList.size()!=0){
						TextGuiTestObject text_EndDt = (TextGuiTestObject) text_EndDtList.get(text_EndDtList.size()-1);
						if(text_EndDt!= null){
							text_EndDt.waitForExistence(10, 2);
							text_EndDt.click();
							text_EndDt.setText(endDt);
							sleep(2);
//							browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
						}
						else{
							System.out.println("Mandatory field(s) End Date is absent in Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in Settlement Control batch search page", Status.BC_FAILED);
							return;
						}
					}
					else{
						System.out.println("Mandatory field(s) End Date not found in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date not found in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}//End of End Date
					
				}//End of Enter date
				
			}//End of else if for TPP Sub-Batch selection as Batch View
			
			
			
			//Selecting Search button			
			GuiTestObject button_Search = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Search");
			if(button_Search!= null){
				button_Search.waitForExistence(10, 2);
				button_Search.click();
				sleep(10);
			}
			else{
				System.out.println("Search button is absent in Settlement Control batch search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Search button is absent in Settlement Control batch search page", Status.BC_FAILED);
				return;
			}
			
			//Waiting for the TPP list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The TPP list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The TPP list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The TPP list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 			
			sleep(5);
			//Checking whether the search result has data or not
			GuiTestObject msg_NoSearchResult = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "No records found for Batch List.");
			if(msg_NoSearchResult!= null){
				msg_NoSearchResult.waitForExistence(30, 2);
				System.out.println("Search result has no data in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Search result has no data in Batch Search List Page", Status.BC_FAILED);
				return;
			}
			else if(msg_NoSearchResult== null){
				//Fetching total number of records fetched on the Settlement Control Batch list page
				ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
				System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
				GuiTestObject text_totalNoOfTPPFileRecords = null;
				if(text_PageToolbarList.size()==0
						|| !text_PageToolbarList.get(text_PageToolbarList.size()-1).ensureObjectIsVisible()){
					System.out.println("Settlement Control Batch search fetched NO DATA on the Settlement Control Batch list page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Settlement Control Batch search fetched NO DATA on the Settlement Control Batch list page", Status.BC_FAILED);
					return;
				}
				for(int loop=0;loop<text_PageToolbarList.size();loop++){
					text_totalNoOfTPPFileRecords = text_PageToolbarList.get(loop);
					System.out.println(text_totalNoOfTPPFileRecords.getProperty(".text").toString());
					System.out.println("DISABLED: "+text_totalNoOfTPPFileRecords.getProperty("disabled").toString());
					System.out.println("ARIA-HIDDEN: "+text_totalNoOfTPPFileRecords.getProperty("aria-hidden").toString());
					System.out.println("ARIA-DISABLED: "+text_totalNoOfTPPFileRecords.getProperty("aria-disabled").toString());
					System.out.println("ARIA-SECRET: "+text_totalNoOfTPPFileRecords.getProperty("aria-secret").toString());
					System.out.println("EXISTS:"+text_totalNoOfTPPFileRecords.exists());
					System.out.println("ENSURE OBJ:"+text_totalNoOfTPPFileRecords.ensureObjectIsVisible());
				}
				text_totalNoOfTPPFileRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
				if(text_totalNoOfTPPFileRecords!= null){
					text_totalNoOfTPPFileRecords.waitForExistence(10, 2);
					String text_TotalRecordsFetched = text_totalNoOfTPPFileRecords.getProperty(".text").toString();
					noOfTPPFileSearchPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(":")+1,text_TotalRecordsFetched.length()).trim();
					System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfTPPFileSearchPg :"+noOfTPPFileSearchPg);
					sleep(1);
					//Checking for the number of TPP File record on the Settlement Control Batch list page
					if(noOfTPPFileSearchPg.isEmpty()){
						System.out.println("TPP File Number is absent on Batch List page bottom toolbar");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "TPP File Number is absent on Batch List page bottom toolbar", Status.BC_FAILED);
						return;	
					}			
					else{
						totalTPPFileNoSearchPg = Integer.parseInt(noOfTPPFileSearchPg);
						if(totalTPPFileNoSearchPg == 0){
							System.out.println("No records fetched and displayed on the Settlement Control Batch list page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "No records fetched and displayed on the Settlement Control Batch list page", Status.BC_FAILED);
							return;
						}
						else{
							System.out.println("Total TPP File records fetched and displayed on the Settlement Control Batch List-summary view Page is: "+totalTPPFileNoSearchPg);
						}
						
					}//End of TPP File number check
					
				}//End of TPP File number fetching
				else{
					System.out.println("TPP File records number is absent on Settlement Control Batch List-summary view Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "TPP File records number is absent on Settlement Control Batch List-summary view Page", Status.BC_FAILED);
					return;
				}
		        
			}//End of else if for no record message search
			
			//Component success message
			String cmpSuccessMsg = "Total TPP File(Status: "+fileStatus+") records fetched and displayed on the Settlement Control Batch List-summary view Page is: "+totalTPPFileNoSearchPg;
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);

		}//End of try block
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}//End of catch block

	}//End of Execute Component
	
}//End of class