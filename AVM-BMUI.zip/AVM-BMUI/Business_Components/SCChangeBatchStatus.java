package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.SCChangeBatchStatusHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class SCChangeBatchStatus extends SCChangeBatchStatusHelper
{
	/**
	 * Script Name   : <b>SCChangeBatchStatus</b>
	 * Generated     : <b>Dec 8, 2011 10:13:03 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/12/08
	 * @author axbane1
	 */
	
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "ChangePOSSystemBatchStatus";
	
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 4)
			{
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 4 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 4 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					
				}						       		
			}
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Batch List page,Settlement Control Batch Search -> Settlement Control Batch List
			 * ---Ending on Home page, i.e. , Home tab
			 */
			
			String multiRecordBatchReq = (String) args[0];
//			String BatchFileStatus = "";
			String currentStatus = (String) args[1];
			currentStatus = currentStatus.toUpperCase();
			String newStatus = (String) args[2];
			newStatus = newStatus.toUpperCase();
			int loopUBound = 0;			
			String enterNotes = (String) args[3];
			
			//Verifying whether the Change Status button is enabled or disabled			
			GuiTestObject button_BatchChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Change Status");
			if(button_BatchChangeStatus!= null){
				button_BatchChangeStatus.waitForExistence(20, 2);
				if(button_BatchChangeStatus.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Change Status button is enabled in Batch List Page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Change Status button is enabled in Batch List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_BatchChangeStatus.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Change Status button is disabled rightly in Batch List Page while no records are selected");
				}
				
			}
			else{
				System.out.println("Change Status button is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Change Status button is absent in Batch List page", Status.BC_FAILED);
				return;
			}//End of Verifying whether the Change Status button is enabled or disabled
			
			
			//Selecting the Batch for changing status
			RegularExpression regExBatchSearch = new RegularExpression("batchListGrid_x-auto-[0-9].*",false);
//			String view = "Expanded View";
			String view = "View";
			
			//Selecting the records to Change Status a Batch in transaction search list page				
			ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", view);
//			ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", view);
			
			StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
			System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
			if(list_SelectBatchSearchResultList.size()!=0){
//				loopUBound = 0;
				if(multiRecordBatchReq.equalsIgnoreCase("false")){
					loopUBound = 1;
				}
				else if(list_SelectBatchSearchResultList.size()>4){
					loopUBound = 4;
				}
				else if(list_SelectBatchSearchResultList.size()<4){
					loopUBound = list_SelectBatchSearchResultList.size();
				}
				
				//Looping through the matching records
				for(int loop=0;loop<loopUBound;loop++){
					System.out.println("checkbox_SearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
					checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
//					System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
					if(checkbox_SearchRecord!=null){
//						System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//						System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//						checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//															Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
						checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
															atColumn(atIndex(0))));
						sleep(5);
//						break;
					}
					else{
						System.out.println("Record not matching ");
						continue;
					}
				}
			}
			else{
				System.out.println("No matching record found in Batch List Page with Expanded View");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Batch List Page with Expanded View", Status.BC_FAILED);
				return;
			}//End of Selecting the Batches for changing status
			
			//Selecting the Change Status button to Change Status the selected records			
			GuiTestObject button_ChangeStatusBatch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Change Status");
			if(button_ChangeStatusBatch!= null){
				button_ChangeStatusBatch.waitForExistence(20, 2);
				//Checking whether the Change Status button is enabled or disabled
				if(button_ChangeStatusBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Change Status button is disabled in Batch List Page even after selecting records");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Change Status button is disabled in Batch List Page even after selecting records", Status.BC_FAILED);
					return;
				}
				else if(button_ChangeStatusBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					button_ChangeStatusBatch.click();
					sleep(10);
					//Checking for the existence of the Change Status Batch confirm existence 
					GuiTestObject popup_ChangeStatusBatchConfirm = Util.getMappedObject("Html.SPAN", ".text", "Change System Batch Status");
					if(popup_ChangeStatusBatchConfirm!=null){
						//Selecting Cancel button to cancel the Change Status Batch pop up 			
						GuiTestObject button_CancelBatchChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
						if(button_CancelBatchChangeStatus!= null){
							button_CancelBatchChangeStatus.waitForExistence(10, 2);
							button_CancelBatchChangeStatus.click();
							sleep(2);
							button_ChangeStatusBatch.waitForExistence(10,2);
						}
						else{
							System.out.println("Cancel Batch Change Status button is absent on Batch Change Status pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Cancel Batch Change Status button is absent on Batch Change Status pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for Cancel button existence check
						
						//Selecting the change status button again to make the Change Status pop up re-appear
						button_ChangeStatusBatch.click();
						sleep(10);
						
						//Selecting Print button to print the change status batch pop up 			
						GuiTestObject button_PrintBatchChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Print");
						if(button_PrintBatchChangeStatus!= null){
							System.out.println("Inside print button");
							button_PrintBatchChangeStatus.waitForExistence(10, 2);
							button_PrintBatchChangeStatus.click();
							sleep(2);
							//Checking the pop up in case of no printer is configured in the machine
							if(printwindowNoPrinterConfig().exists()
									&& printwindowNoPrinterConfig().ensureObjectIsVisible()){

								if(!printwindowNoPrinterConfig().isEnabled()){
									printwindowNoPrinterConfig().activate();
								}
								System.out.println("Inside No Configuration Print Selection Window");
								printwindowNoPrinterConfig().click();
								if(nobutton().exists()
										&& nobutton().ensureObjectIsVisible()){
									nobutton().click();
									sleep(2);
								}
							}
							//End of Checking the pop up in case of no printer is configured in the machine
									//checking for the existence of the printer select option box
									if(printwindow().exists()
											&& printwindow().ensureObjectIsVisible()){
										System.out.println("printwindow().exists(): "+printwindow().exists()+" printwindow().ensureObjectIsVisible(): "+printwindow().ensureObjectIsVisible());
										System.out.println("Inside print Selection Window");
										//Checking for the existence of cancel button on printer selection window
										System.out.println("cancelbutton().exists(): "+cancelbutton().exists()+" cancelbutton().ensureObjectIsVisible(): "+cancelbutton().ensureObjectIsVisible());
										if(cancelbutton().exists()
												&& cancelbutton().ensureObjectIsVisible()){											
											System.out.println("Inside print selection window cancel");
											cancelbutton().click();
											sleep(2);
										}
										else{
											System.out.println("Cancel button is absent on Printer selection window while selecting to print");
											error = true;
											Util.scenarioStatus = false;
											CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on Printer selection window while selecting to print", Status.BC_FAILED);
											return;
										}//End of Checking for the existence of cancel button on printer selection window										
									}
									else{									
										System.out.println("Printer selection window is not visible while selecting to print");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Printer selection window is not visible while selecting to print", Status.BC_FAILED);
										return;
									}//End of checking for the existence of the printer select option box
								}//End of if for print button existence check				
						else{
							System.out.println("Print Batch Change Status button is absent on batch pend pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Print Batch Change Status button is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for print button existence check			
											
						
						//Selecting the current status fields
						ArrayList<GuiTestObject> text_StatusList = Util.getGWTMappedObjects("Html.INPUT.text", ".className", "x-form-field x-form-text");
						System.out.println("text_currentStatusList Size: "+text_StatusList.size());
						TextGuiTestObject text_currentStatus = null;
						TextGuiTestObject text_newStatus = null;
						for(int i=0;i<text_StatusList.size();i++){
							System.out.println("Id: "+text_StatusList.get(i).getProperty(".id").toString());
						}
						//Checking the existence of the status fields
						if(text_StatusList.size()<=0){
							System.out.println("Current Status field is absent on Batch change status pop up");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Current Status field is absent on Batch change status pop up", Status.BC_FAILED);
							return;
						}
						else{
							text_currentStatus = (TextGuiTestObject) text_StatusList.get(text_StatusList.size()-2);
							text_newStatus = (TextGuiTestObject) text_StatusList.get(text_StatusList.size()-1);
						}
						
						//Checking the existence of the current status fields
						if(text_currentStatus!=null){			
							text_currentStatus.click();			
							text_currentStatus.setText(currentStatus);
							sleep(2);
							//Selecting the Current Status from the drop down
							//RegularExpression regExcurrentStatusDropDwn = new RegularExpression("x-auto-[0-9].*",false);
							if(currentStatus.isEmpty()){
								System.out.println("The Current Status string is empty");
							}
							else{
//								ArrayList<GuiTestObject> list_currentStatusList = Util.getGWTMappedObjects("Html.DIV",".id",regExcurrentStatusDropDwn, "Html.DIV",".text", tppName);
								ArrayList<GuiTestObject> list_currentStatusList = Util.getGWTMappedObjects("Html.DIV",".text", currentStatus);
								GuiTestObject list_currentStatus = null;
								if(list_currentStatusList.size()==0){
									System.out.println("Current Status list dropdown is absent on Batch change status pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Current Status list dropdown is absent on Batch change status pop up", Status.BC_FAILED);
									return;
								}
								for(int i=0;i<list_currentStatusList.size();i++){
									System.out.println("list_currentStatusList: "+list_currentStatusList.get(i).getProperty(".text").toString());
								}
								
								list_currentStatus = list_currentStatusList.get(list_currentStatusList.size()-1);						
								if(list_currentStatus!=null){
									System.out.println("Inside the Current Status dropdown list");	
									list_currentStatus.click();
								}
								else{
									System.out.println("Current Status list dropdown not found on Batch change status pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Current Status list dropdown not found on Batch change status pop up", Status.BC_FAILED);
									return;
								}								
							}//End of Selecting the Current Status from the drop down
						}
						else{
							System.out.println("Current Status not found on Batch change status pop up");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Current Status not found on Batch change status pop up", Status.BC_FAILED);
							return;
						}//End of selection of Current Status By from drop down
							
						//Selection of new Status 
						if(text_newStatus!=null){			
							text_newStatus.click();			
							text_newStatus.setText(newStatus);
							sleep(2);
							//Selecting the New Status from the drop down
							//RegularExpression regExnewStatusDropDwn = new RegularExpression("x-auto-[0-9].*",false);
							if(newStatus.isEmpty()){
								System.out.println("The New Status string is empty");
							}
							else{
								//ArrayList<GuiTestObject> list_newStatusList = Util.getGWTMappedObjects("Html.DIV",".id",regExnewStatusDropDwn, "Html.DIV",".text", tppName);
								ArrayList<GuiTestObject> list_newStatusList = Util.getGWTMappedObjects("Html.DIV",".text", newStatus);
								GuiTestObject list_newStatus = null;
								if(list_newStatusList.size()==0){
									System.out.println("New Status list dropdown is absent on Batch change status pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "New Status list dropdown is absent on Batch change status pop up", Status.BC_FAILED);
									return;
								}
								for(int i=0;i<list_newStatusList.size();i++){
									System.out.println("list_newStatusList: "+list_newStatusList.get(i).getProperty(".text").toString());
								}

								list_newStatus = list_newStatusList.get(list_newStatusList.size()-1);						
								if(list_newStatus!=null){
									System.out.println("Inside the New Status dropdown list");	
									list_newStatus.click();
								}
								else{
									System.out.println("New Status list dropdown not found on Batch change status pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "New Status list dropdown not found on Batch change status pop up", Status.BC_FAILED);
									return;
								}

							}//End of Selecting the New Status from the drop down
						}
						else{
							System.out.println("New Status not found on Batch change status pop up");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "New Status not found on Batch change status pop up", Status.BC_FAILED);
							return;
						}//End of Selecting the new status field
						
						//Selecting Enter Notes in the change batch status pop up			
						TextGuiTestObject text_ChangeBatchStatusNotes = (TextGuiTestObject)Util.getMappedObject("Html.TEXTAREA", ".name", "enterNotes");
						if(text_ChangeBatchStatusNotes!= null){
							text_ChangeBatchStatusNotes.waitForExistence(10, 2);
							text_ChangeBatchStatusNotes.click();
							text_ChangeBatchStatusNotes.setText(enterNotes);
							sleep(1);
						}
						else{
							System.out.println("Enter note area is absent in Change Batch Status Pop Up");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Enter note area is absent in Change Batch Status Pop Up", Status.BC_FAILED);
							return;
						}//End of Selecting Enter Notes in the change batch status pop up
						
						//Selecting Visible to external user check box in the change batch status pop up			
						ArrayList<GuiTestObject> checkbox_VisibleExtUserList = Util.getGWTMappedObjects("Html.DIV", ".text", "Visible to External Users");
						GuiTestObject checkbox_VisibleExtUser = null;
						if(checkbox_VisibleExtUserList.size()!=0){
							checkbox_VisibleExtUser = checkbox_VisibleExtUserList.get(checkbox_VisibleExtUserList.size()-1);
							if(checkbox_VisibleExtUser!= null){				
								checkbox_VisibleExtUser.waitForExistence(10, 2);
								checkbox_VisibleExtUser.click();			
								sleep(1);
							}
							else{
								System.out.println("Visible to external user checkbox is absent in Change Batch Status pop up");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Visible to external user check box is absent in Change Batch Status pop up", Status.BC_FAILED);
								return;
							}
						}
						
						else{
							System.out.println("Visible to external user checkbox not found in Change Batch Status pop up");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Visible to external user check box not found in Change Batch Status pop up", Status.BC_FAILED);
							return;
						}// End of Selecting Visible to external user check box in the change batch status pop up
						
					}//End of Checking for the existence of the Change Status Batch confirm existence
					
				}//End of Checking whether the ChangeStatus button is enabled or disabled
				
			}//End of Selecting the ChangeStatus button to Change Status the selected records			
			
					
			//Selecting Submit button to submit the Change Status Batch pop up 			
			GuiTestObject button_SubmitBatchChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
			if(button_SubmitBatchChangeStatus!= null){
				button_SubmitBatchChangeStatus.waitForExistence(10, 2);
				button_SubmitBatchChangeStatus.click();
				sleep(5);
				
			}
			else{
				System.out.println("Submit Batch Change Status Submit button is absent on Batch Change Status pop-up confirmation window");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Submit Batch Change Status Submit button is absent on Batch Change Status pop-up confirmation window", Status.BC_FAILED);
				return;
			}//End of else for Submit button existence check
			
			//Checking for the existence of the submit confirmation pop up		
			GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.SPAN", ".text", "Confirm Action");
			if(popup_SubmitConfirm==null){			
				System.out.println("Submit confirmation pop up not present");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Submit confirmation pop up not present", Status.BC_FAILED);
				return;			
			}
			else{
				System.out.println("Submit confirmation pop up is present");	
				popup_SubmitConfirm.waitForExistence(30, 2);
				
				//Selecting the Cancel button on the confirmation pop up 		
				GuiTestObject button_ConfirmCancel = Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
				if(button_ConfirmCancel!=null){
					button_ConfirmCancel.click();	
					sleep(5);
				}
				else{
					System.out.println("Cancel button not present on submit confirmation pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
					return;
				}//End of Cancel button on the confirmation pop up
				
				button_SubmitBatchChangeStatus.click();
				popup_SubmitConfirm.waitForExistence(30, 2);
				
				//Selecting the Confirm button on the confirmation pop up 		
				GuiTestObject button_Confirm = Util.getMappedObject("Html.BUTTON", ".value", "Confirm");
				if(button_Confirm!=null){
					button_Confirm.click();	
					sleep(20);
				}
				else{
					System.out.println("Confirm button not present on submit confirmation pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
					return;
				}//End of Confirm button on the confirmation pop up
				
			}//End of existence of the submit confirmation pop up check
		
		
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);

			//Checking successful submission message
			String statusChangeSuccessMsg = "Status changed for "+loopUBound+" batch(s)";
			GuiTestObject msg_StatusChangeSuccess = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", statusChangeSuccessMsg);
			if(msg_StatusChangeSuccess!= null){
				msg_StatusChangeSuccess.waitForExistence(30, 2);				
				System.out.println(statusChangeSuccessMsg);
			}
			else{				
				System.out.println("No Batch status are changed.");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No Batch status are changed.", Status.BC_FAILED);
				return;
			}//End of Checking successful submission message
			
			//Selecting the Cancel button on the change batch status pop up 		
			GuiTestObject button_ConfirmCancel = Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
			if(button_ConfirmCancel!=null){
				button_ConfirmCancel.click();	
				sleep(5);
			}
			else{
				System.out.println("Cancel button not present on change batch status confirmation pop up");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on change batch status confirmation pop up", Status.BC_FAILED);
				return;
			}//End of Cancel button on the change batch status pop up
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			sleep(10);
			
			//Returning to the home tab as an exit point
			if(link_home().exists()
					|| link_home().ensureObjectIsVisible()){
				link_home().waitForExistence(20, 2);
				link_home().click();
				//Checking the existence of refresh button at the welcome area on home page				
				GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
				if(button_RefreshAtHome!= null){
					button_RefreshAtHome.waitForExistence(20, 2);
					button_RefreshAtHome.ensureObjectIsVisible();
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Home tab is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Home tab is absent in Batch List Page", Status.BC_FAILED);
				return;
			}//End of returning to the home tab as an exit point
			
			//Component success message
			String cmpSuccessMsg = "Status changed for "+loopUBound+" batch(s)";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
			
		}//End of try block
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}//End of catch block

	}//End of execute component
	
}//End of class

