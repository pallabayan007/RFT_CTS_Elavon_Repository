package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.TxnListThru24HrSnapshotTxnCountLinkHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxghos1
 */
public class TxnListThru24HrSnapshotTxnCountLink extends TxnListThru24HrSnapshotTxnCountLinkHelper
{
	/**
	 * Script Name   : <b>TxnListThru24HrSnapshotTxnCountLink</b>
	 * Generated     : <b>Nov 22, 2011 6:18:58 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/22
	 * @author sxghos1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "TxnListThru24HrSnapshotTxnCountLink";
	
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 0)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 0 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 0 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{			
			String tranApproved = "";
			String noOfTranApproved = "";
			String noOfTranApprovedSearchPg = "";
//			int totalTranNoSearchPg = 0;
			//Searching the existence of the transaction management 24 hr snapshot table	
			String snapShotTable = "Transaction Management 24 Hour Snapshot";
			GuiTestObject table_Tran24hrSnap = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", snapShotTable);
			if(table_Tran24hrSnap!= null){
				table_Tran24hrSnap.waitForExistence(20, 2);
				//Searching the existence of the approved link
				RegularExpression regExTranApprovedRow = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
				ArrayList<GuiTestObject> link_SelectTranApprovedList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTranApprovedRow,"Html.TABLE", ".text", "APPROVED");
				System.out.println("link_SelectTranApprovedList size: "+link_SelectTranApprovedList.size());
				StatelessGuiSubitemTestObject link_SelectTranApproved = (StatelessGuiSubitemTestObject) link_SelectTranApprovedList.get(0);			
				if(link_SelectTranApproved!=null){
					link_SelectTranApproved.waitForExistence(20, 2);
					tranApproved = link_SelectTranApproved.getProperty(".text").toString();
					if(tranApproved.isEmpty()){
						System.out.println("Approved Number text is absent on Transaction Management 24 Hour Snapshot table");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Approved Number text is absent on Transaction Management 24 Hour Snapshot table", Status.BC_FAILED);
						return;	
					}
					noOfTranApproved = tranApproved.substring(tranApproved.lastIndexOf(" "), tranApproved.length()).trim();
					System.out.println("tranApproved:"+tranApproved+" : noOfTranApproved :"+noOfTranApproved);
					//Selecting the link with the no of Approved
					ArrayList<GuiTestObject> link_SelectTranApprovedNoList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".text",tranApproved,"Html.A", ".text", noOfTranApproved);
					System.out.println("link_SelectTranApprovedNoList size: "+link_SelectTranApprovedNoList.size());
					GuiTestObject link_SelectTranApprovedNo = (GuiTestObject) link_SelectTranApprovedNoList.get(0);
					if(link_SelectTranApprovedNo!=null){
						link_SelectTranApprovedNo.waitForExistence(20, 2);
						link_SelectTranApprovedNo.click();
						sleep(20);
					}
					else{
						System.out.println("Approved Number link is absent on Transaction Management 24 Hour Snapshot table");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Approved Number link is absent on Transaction Management 24 Hour Snapshot table", Status.BC_FAILED);
						return;
					}
				}
				else{
					System.out.println("Approved entry is absent on Transaction Management 24 Hour Snapshot table");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Approved entry is absent on Transaction Management 24 Hour Snapshot table", Status.BC_FAILED);
					return;
				}
				
			}
			else{
				System.out.println("Transaction Management 24 Hour Snapshot table is absent in Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Management 24 Hour Snapshot table is absent in Page", Status.BC_FAILED);
				return;
			}	

			//Waiting for the transaction list to populate on the transaction list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Transaction list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Transaction list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The transaction list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			//Fetching total number of records fetched on the Transaction list page
			ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
			System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
			GuiTestObject text_totalNoOfTranApprovedRecords = null;
			if(text_PageToolbarList.size()==0
					|| !text_PageToolbarList.get(text_PageToolbarList.size()-1).ensureObjectIsVisible()){
				System.out.println("Transaction search fetched NO DATA on the transaction list page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction search fetched NO DATA on the transaction list page", Status.BC_FAILED);
				return;
			}
			for(int loop=0;loop<text_PageToolbarList.size();loop++){
				text_totalNoOfTranApprovedRecords = text_PageToolbarList.get(loop);
				System.out.println(text_totalNoOfTranApprovedRecords.getProperty(".text").toString());
			}
			text_totalNoOfTranApprovedRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
			if(text_totalNoOfTranApprovedRecords!= null){
				text_totalNoOfTranApprovedRecords.waitForExistence(10, 2);
				String text_TotalRecordsFetched = text_totalNoOfTranApprovedRecords.getProperty(".text").toString();
				noOfTranApprovedSearchPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(":")+1,text_TotalRecordsFetched.length()).trim();
//				totalTranNoSearchPg = Integer.parseInt(noOfTranApprovedSearchPg);
				System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfTranApprovedSearchPg :"+noOfTranApprovedSearchPg);
				sleep(1);
				//Checking for the number of Approved record on the transaction list page
				if(noOfTranApprovedSearchPg.isEmpty()){
					System.out.println("Approved Number is absent on Transaction List page bottom toolbar");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Approved Number is absent on Transaction List page bottom toolbar", Status.BC_FAILED);
					return;	
				}
				else if(noOfTranApprovedSearchPg.equalsIgnoreCase(noOfTranApproved)){
					System.out.println("Approved records number on Transaction List-summary view Page is matching with Approved records number on Transaction management 24hr snapshot");
				}
				else{
					System.out.println("Approved records number("+noOfTranApproved+") on Transaction List-summary view Page is NOT matching with Approved records number("+noOfTranApprovedSearchPg+") on Transaction management 24hr snapshot");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Approved records number("+noOfTranApproved+") on Transaction List-summary view Page is NOT matching with Approved records number("+noOfTranApprovedSearchPg+") on Transaction management 24hr snapshot", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Approved records number is absent on Transaction List-summary view Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Approved records number is absent on Transaction List-summary view Page", Status.BC_FAILED);
				return;
			}

			//Selecting Return to Home button			
			GuiTestObject button_RetToHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Return to Home");
			if(button_RetToHome!= null){
				button_RetToHome.waitForExistence(10, 2);
//				//Checking whether the return to home button is disabled or not
				if(!button_RetToHome.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					button_RetToHome.click();
					sleep(5);
				}
				else{
					System.out.println("Return to Home button is disabled in Transaction List Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Return to Home button is disabled in Transaction List page", Status.BC_FAILED);
					return;
				}				
			}
			else{
				System.out.println("Return to Home button is absent in Transaction List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Return to Home button is absent in Transaction List page", Status.BC_FAILED);
				return;
			}
			
			//Checking the existence of refresh button at the welcome area on home page				
			GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
			if(button_RefreshAtHome!= null){
				button_RefreshAtHome.waitForExistence(20, 2);
				button_RefreshAtHome.ensureObjectIsVisible();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
				return;
			}
			
			//Component success message
			String cmpSuccessMsg = "#Approved number in 24hr snapshot: "+noOfTranApproved+
									" #Approved number in Transaction list page: "+noOfTranApprovedSearchPg+
									" #The numbers are matching";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
		}
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}
		
	}//End of execute component
		
}

