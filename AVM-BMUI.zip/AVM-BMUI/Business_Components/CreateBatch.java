package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.CreateBatchHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class CreateBatch extends CreateBatchHelper
{
	/**
	 * Script Name   : <b>CreateBatch</b>
	 * Generated     : <b>Oct 20, 2011 4:25:38 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/10/20
	 * @author axbane1
	 */
	
	boolean error = false;
	protected String batchId = "";
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	
	
	
	
	public String testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 1)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 1 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 1 input, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return "";
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error||batchId.isEmpty()){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return "";
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return "";
		}
		
		return batchId;
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			String tranStatus = (String) args[0];			
			String enterNotes = "Test";
			
			
			//Selecting the records to create a batch in transaction search list page
			RegularExpression regExTxnSearch = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
			ArrayList<GuiTestObject> list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearch,"Html.TABLE", ".text", tranStatus);
			StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
			System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
			if(list_SelectTxnSearchResultList.size()!=0){
				int loopUBound = 0;
				if(list_SelectTxnSearchResultList.size()>4){
					loopUBound = 4;
				}
				else if(list_SelectTxnSearchResultList.size()<4){
					loopUBound = list_SelectTxnSearchResultList.size();
				}
				//Looping through the matching records
				for(int loop=0;loop<loopUBound;loop++){
					System.out.println("checkbox_SearchRecord : "+list_SelectTxnSearchResultList.get(loop).getProperty(".text").toString());
					checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectTxnSearchResultList.get(loop);
//					System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
					if(checkbox_SearchRecord!=null){
//						System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//						System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//						checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//															Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
						checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
															atColumn(atIndex(0))));
						sleep(1);
//						break;
					}
					else{
						System.out.println("Record not matching ");
						continue;
					}
				}
			}
			else{
				System.out.println("No matching record found in Transaction Search List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Batch", "No matching record found in Transaction Search List Page", Status.BC_FAILED);
				return;
			}
			
			
			// HTML Browser
			// Document: ElavonPortal: https://gatewaytest.novainfo.net/ui/portal.html?ticket=ST-198-Ofs21aoOZ2l9gzCfkDQ9-cas
//			table_htmlTable_0().click(atCell(atRow(atIndex(0)), 
//	                                   atColumn(atIndex(0))));
			
			//Selecting Create Batch button			
			GuiTestObject button_CreateBatch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Create Batch");
			if(button_CreateBatch!= null){
				button_CreateBatch.waitForExistence(10, 2);
				button_CreateBatch.click();
				sleep(5);
			}
			else{
				System.out.println("Create Batch button is absent in Transaction Search List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Batch", "Create Batch button is absent in Transaction Search List page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Enter Notes in the create batch page			
			TextGuiTestObject text_CreateBatchNotesNotes = (TextGuiTestObject)Util.getMappedObject("Html.TEXTAREA", ".name", "enterNotes");
			if(text_CreateBatchNotesNotes!= null){
				text_CreateBatchNotesNotes.waitForExistence(10, 2);
				text_CreateBatchNotesNotes.click();
				text_CreateBatchNotesNotes.setText(enterNotes);
				sleep(1);
			}
			else{
				System.out.println("Enter note area is absent in Create Batch Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Batch", "Enter note area is absent in Create Batch Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Visible to external user check box in the create batch page			
			ArrayList<GuiTestObject> checkbox_VisibleExtUserList = Util.getGWTMappedObjects("Html.DIV", ".text", "Visible to External Users");
			GuiTestObject checkbox_VisibleExtUser = null;
			if(checkbox_VisibleExtUserList.size()!=0){
				checkbox_VisibleExtUser = checkbox_VisibleExtUserList.get(checkbox_VisibleExtUserList.size()-1);
				if(checkbox_VisibleExtUser!= null){				
					checkbox_VisibleExtUser.waitForExistence(10, 2);
					checkbox_VisibleExtUser.click();			
					sleep(1);
				}
				else{
					System.out.println("Visible to external user checkbox is absent in Create Batch Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Create Batch", "Visible to external user check box is absent in Create Batch Page", Status.BC_FAILED);
					return;
				}
			}
			
			else{
				System.out.println("Visible to external user checkbox not found in Create Batch Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Batch", "Visible to external user check box not found in Create Batch Page", Status.BC_FAILED);
				return;
			}
			
			
			//Selecting Submit button			
			GuiTestObject button_Submit = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Submit");
			if(button_Submit!= null){
				button_Submit.waitForExistence(10, 2);
				button_Submit.click();
				sleep(5);
			}
			else{
				System.out.println("Submit button is absent in Create Batch Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Batch", "Submit button is absent in Create Batch Page", Status.BC_FAILED);
				return;
			}
			
			//Searching for the confirm action pop up			
			GuiTestObject popup_ConfirmAction = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "Confirm Action");
			if(popup_ConfirmAction!= null){
				popup_ConfirmAction.waitForExistence(10, 2);			
				//Selecting confirm button on the pop up page			
				GuiTestObject button_Confirm = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Confirm");
				if(button_Confirm!= null){
					button_Confirm.waitForExistence(10, 2);
					button_Confirm.click();
					sleep(15);
				}
				else{
					System.out.println("Confirm button is absent in Confirm action pop up Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Create Batch", "Confirm button is absent in Confirm action pop up Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Confirm action pop up is absent in Create Batch Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Batch", "Confirm action pop up is absent in Create Batch Page", Status.BC_FAILED);
				return;
			}
			
			//Checking whether the batch is create successfully or not
			GuiTestObject msg_BatchSuccessCreate = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "New Batch has been successfully created");
			if(msg_BatchSuccessCreate!= null){
				msg_BatchSuccessCreate.waitForExistence(30, 2);
				System.out.println("Batch created successfully message is displayed on the create batch page");
				//Selecting the newly created batch id			
				TextGuiTestObject text_BatchId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "batchId");
				if(text_BatchId!= null){
					text_BatchId.waitForExistence(10, 2);
					batchId = text_BatchId.getProperty(".value").toString();
					sleep(1);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");	
					System.out.println("Batch created successfully with id: "+batchId);
				}
				else{
					System.out.println("Batch not created successfully");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Create Batch", "Batch not created successfully", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Successful batch creation message is not displayed on the batch creation page");	
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Batch", "Successful batch creation message is not displayed on the batch creation page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Cancel button			
			GuiTestObject button_Cancel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Cancel");
			if(button_Cancel!= null){
				button_Cancel.waitForExistence(10, 2);
				button_Cancel.click();
				sleep(15);
			}
			else{
				System.out.println("Cancel button is absent in Create Batch Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Batch", "Cancel button is absent in Create Batch Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting the home link to end in the home page
			link_home().waitForExistence(10, 2);
			link_home().click();
			sleep(15);
			
			//Component success message
			if(!batchId.isEmpty()){
				CRAFT_Report.LogInfo(BusinessComponentName, "Batch created successfully with Batch Id: "+batchId, Status.BC_PASSED);
			}
			else if(batchId.isEmpty()){
				CRAFT_Report.LogInfo(BusinessComponentName, "Batch Not created successfully", Status.BC_FAILED);
			}
						
			
		}
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}


	}//End of ExecuteComponenet
	
}

