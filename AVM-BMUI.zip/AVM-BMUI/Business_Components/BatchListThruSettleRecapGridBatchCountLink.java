package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.BatchListThruSettleRecapGridBatchCountLinkHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class BatchListThruSettleRecapGridBatchCountLink extends BatchListThruSettleRecapGridBatchCountLinkHelper
{
	/**
	 * Script Name   : <b>BatchListThruSettleRecapGridBatchCountLink</b>
	 * Generated     : <b>Nov 8, 2011 1:45:38 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/08
	 * @author axbane1
	 */
	
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "BatchListThruSettleRecapGridBatchCountLink";
	
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 1)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 1 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 1 input, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{			
			String batchSettleStatus = (String) args[0];
			batchSettleStatus = batchSettleStatus.toUpperCase();
			String batchSettleGridPropText = "";
			String noOfBatchSettleGrid = "";
			String noOfBatchSettleGridSearchPg = "";
			
			//Searching the existence of the batch settlement recap table	
			String settleGridTable = "Batch Settlement Recap";
			GuiTestObject table_BatchSettleGrid = (GuiTestObject)Util.getMappedObject("Html.SPAN", ".text", settleGridTable);
			if(table_BatchSettleGrid!= null){
				table_BatchSettleGrid.waitForExistence(90, 2);
				table_BatchSettleGrid.ensureObjectIsVisible();
				//Searching the existence of the batch received link
				RegularExpression regExBatchSettleGrid = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
				ArrayList<GuiTestObject> link_SelectBatchSettleGridList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSettleGrid,"Html.TABLE", ".text", batchSettleStatus);
				System.out.println("link_SelectBatchSettleGridList size: "+link_SelectBatchSettleGridList.size());
				StatelessGuiSubitemTestObject link_SelectBatchSettleGrid = (StatelessGuiSubitemTestObject) link_SelectBatchSettleGridList.get(0);			
				if(link_SelectBatchSettleGrid!=null){
					link_SelectBatchSettleGrid.waitForExistence(20, 2);
					batchSettleGridPropText = link_SelectBatchSettleGrid.getProperty(".text").toString();
					if(batchSettleGridPropText.isEmpty()){
						System.out.println(""+batchSettleStatus+"  Number text is absent on Batch Settlement Recap Grid table");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, ""+batchSettleStatus+"  Number text is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
						return;	
					}
					noOfBatchSettleGrid = batchSettleGridPropText.substring(batchSettleGridPropText.indexOf(batchSettleStatus)+batchSettleStatus.length(), batchSettleGridPropText.lastIndexOf(" ")).trim();
					System.out.println("batchSettleGridPropText:"+batchSettleGridPropText+" : noOfBatchSettleGrid :"+noOfBatchSettleGrid);
					//Selecting the link with the no of batch with supplied status
					ArrayList<GuiTestObject> link_SelectBatchConfNoList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".text",batchSettleGridPropText,"Html.A", ".text", noOfBatchSettleGrid);
					System.out.println("link_SelectBatchConfNoList size: "+link_SelectBatchConfNoList.size());
					GuiTestObject link_SelectBatchConfNo = (GuiTestObject) link_SelectBatchConfNoList.get(0);
					if(link_SelectBatchConfNo!=null){
						link_SelectBatchConfNo.waitForExistence(20, 2);
						link_SelectBatchConfNo.click();
//						sleep(20);
					}
					else{
						System.out.println(""+batchSettleStatus+"  Number link is absent on Batch Settlement Recap Grid table");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, ""+batchSettleStatus+"  Number link is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
						return;
					}
				}
				else{
					System.out.println(""+batchSettleStatus+"  entry is absent on Batch Settlement Recap Grid table");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, ""+batchSettleStatus+"  entry is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
					return;
				}
				
			}
			else{
				System.out.println("Batch Settlement Recap Grid table is absent in Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Batch Settlement Recap Grid table is absent in Page", Status.BC_FAILED);
				return;
			}	
			
			//Waiting for the batch list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The batch list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The batch list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The batch list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			//Fetching total number of records fetched on the batch list page
			ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
			System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
			GuiTestObject text_totalNoOfBatchRecords = null;
			for(int loop=0;loop<text_PageToolbarList.size();loop++){
				text_totalNoOfBatchRecords = text_PageToolbarList.get(loop);
				System.out.println(text_totalNoOfBatchRecords.getProperty(".text").toString());
			}
			text_totalNoOfBatchRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
			if(text_totalNoOfBatchRecords!= null){
				text_totalNoOfBatchRecords.waitForExistence(10, 2);
				String text_TotalRecordsFetched = text_totalNoOfBatchRecords.getProperty(".text").toString();
				noOfBatchSettleGridSearchPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(":")+1,text_TotalRecordsFetched.length()).trim();
				System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfBatchSettleGridSearchPg :"+noOfBatchSettleGridSearchPg);
				sleep(1);
				//Checking for the number of batch received record on the batch list page
				if(noOfBatchSettleGridSearchPg.isEmpty()){
					System.out.println(""+batchSettleStatus+"  Number is absent on Batch List page bottom toolbar");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, ""+batchSettleStatus+"  Number is absent on Batch List page bottom toolbar", Status.BC_FAILED);
					return;	
				}
				else if(noOfBatchSettleGridSearchPg.equalsIgnoreCase(noOfBatchSettleGrid)){
					System.out.println(""+batchSettleStatus+"  records number on batch List-summary view Page is matching with "+batchSettleStatus+" records number on batch settlement recap grid");
				}
				else{
					System.out.println(""+batchSettleStatus+"  records number("+noOfBatchSettleGrid+") on batch List-summary view Page is NOT matching with "+batchSettleStatus+" records number("+noOfBatchSettleGridSearchPg+") on batch settlement recap grid");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, ""+batchSettleStatus+"  records number("+noOfBatchSettleGrid+") on batch List-summary view Page is NOT matching with "+batchSettleStatus+" records number("+noOfBatchSettleGridSearchPg+") on batch settlement recap grid", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println(""+batchSettleStatus+"  records number is absent on batch List-summary view Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, ""+batchSettleStatus+"  records number is absent on batch List-summary view Page", Status.BC_FAILED);
				return;
			}

			//Selecting Return to Home button			
			GuiTestObject button_RetToHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Return to Home");
			if(button_RetToHome!= null){
				button_RetToHome.waitForExistence(10, 2);
				//Checking whether the return to home button is disabled or not
				if(!button_RetToHome.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Return to Home button is enabled in Batch List Page");
//					button_RetToHome.click();
//					sleep(5);
				}
				else{
					System.out.println("Return to Home button is disabled in Batch List Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Return to Home button is disabled in Batch List page", Status.BC_FAILED);
					return;
				}				
			}
			else{
				System.out.println("Return to Home button is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Return to Home button is absent in Batch List page", Status.BC_FAILED);
				return;
			}
			
//			//Checking the existence of refresh button at the welcome area on home page				
//			GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
//			if(button_RefreshAtHome!= null){
//				button_RefreshAtHome.waitForExistence(20, 2);
//				button_RefreshAtHome.ensureObjectIsVisible();
//			}
//			else{
//				error = true;
//				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
//				return;
//			}
			
			//Component success message
			String cmpSuccessMsg = "#"+batchSettleStatus+" number in Settlement Recap Grid: "+noOfBatchSettleGrid+
									" #"+batchSettleStatus+" number in Batch list page: "+noOfBatchSettleGridSearchPg+
									" #The numbers are matching";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
		}
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}
		
		
	}//End of execute component
}

