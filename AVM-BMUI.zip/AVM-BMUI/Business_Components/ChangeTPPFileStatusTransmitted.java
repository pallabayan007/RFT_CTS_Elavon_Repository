package Business_Components;
import java.util.ArrayList;
import java.util.Random;

import resources.Business_Components.ChangeTPPFileStatusTransmittedHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class ChangeTPPFileStatusTransmitted extends ChangeTPPFileStatusTransmittedHelper
{
	/**
	 * Script Name   : <b>ChangeFileStatus</b>
	 * Generated     : <b>Dec 7, 2011 7:50:10 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/12/07
	 * @author axbane1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "ChangeTPPFileStatusTransmitted";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 4)
			{
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 4 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 4 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					
				}						       		
			}
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from TPP File List page,Settlement Control Batch Search -> Settlement Control Batch List
			 * ---Ending on Home page, i.e. , Home tab
			 */

			String userId = (String) args[0];
			String multiRecordTPPReq = (String) args[1];
//			String TPPFileStatus = "";
			String currentStatus = (String) args[2];
			String newStatus = (String) args[3];
			int loopUBound = 0;
			Random rand = new Random();
			String confNo = "";
			String confAmt = "";
			Double totalTxnAmt = 0.00;
			String txnAmt = "";
			
			
			//Verifying whether the Change Status button is enabled or disabled			
			GuiTestObject button_TPPChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Change Status");
			if(button_TPPChangeStatus!= null){
				button_TPPChangeStatus.waitForExistence(20, 2);
				if(button_TPPChangeStatus.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Change Status button is enabled in TPP List Page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Change Status button is enabled in TPP List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_TPPChangeStatus.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Change Status button is disabled rightly in TPP List Page while no records are selected");
				}
				
			}
			else{
				System.out.println("Change Status button is absent in TPP List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Change Status button is absent in TPP List page", Status.BC_FAILED);
				return;
			}//End of Verifying whether the Change Status button is enabled or disabled
			
			//Selecting the TPP File for changing status
			RegularExpression regExTPPSearch = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
			String view = "Expanded View";
			//Selecting the records to Change Status a TPP in transaction search list page				
			ArrayList<GuiTestObject> list_SelectTPPSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTPPSearch,"Html.TABLE", ".text", view);
			StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
			System.out.println("list_SelectTPPSearchResultList size: "+list_SelectTPPSearchResultList.size());
			if(list_SelectTPPSearchResultList.size()!=0){
				loopUBound = 0;
				if(multiRecordTPPReq.equalsIgnoreCase("False")){
					loopUBound = 1;
				}
				else if(list_SelectTPPSearchResultList.size()>4){
					loopUBound = 4;
				}
				else if(list_SelectTPPSearchResultList.size()<4){
					loopUBound = list_SelectTPPSearchResultList.size();
				}
				
				//Looping through the matching records
				for(int loop=0;loop<loopUBound;loop++){
					System.out.println("checkbox_SearchRecord : "+list_SelectTPPSearchResultList.get(loop).getProperty(".text").toString());
					checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectTPPSearchResultList.get(loop);					
//					System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
					if(checkbox_SearchRecord!=null){
						//Extracting the total Txn Amount 
						txnAmt = checkbox_SearchRecord.getProperty(".text").toString();
						System.out.println("Total txnAmt String : "+txnAmt);
						txnAmt = txnAmt.substring(txnAmt.indexOf("View Notes")+10, txnAmt.length()).trim();
						txnAmt = txnAmt.substring(txnAmt.indexOf(" "), txnAmt.length()).trim();
						txnAmt = txnAmt.substring(0, txnAmt.indexOf(" ")).trim();
						txnAmt = txnAmt.replaceAll(",", "");
						System.out.println("Individual txnAmt: "+txnAmt);
						totalTxnAmt = totalTxnAmt+Double.parseDouble(txnAmt);						
						
						
//						System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//						System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//						checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//															Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
						checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
															atColumn(atIndex(0))));
						sleep(1);
//						break;
					}
					else{
						System.out.println("Record not matching ");
						continue;
					}
				}//End of for loop for check-box selection
			}
			else{
				System.out.println("No matching record found in TPP List Page with Expanded View");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No matching record found in TPP List Page with Expanded View", Status.BC_FAILED);
				return;
			}//End of Selecting the TPP Files for changing status
			
			//Selecting the Change Status button to Change Status the selected records			
			GuiTestObject button_ChangeStatusTPP = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Change Status");
			if(button_ChangeStatusTPP!= null){
				button_ChangeStatusTPP.waitForExistence(20, 2);
				//Checking whether the Change Status button is enabled or disabled
				if(button_ChangeStatusTPP.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Change Status button is disabled in TPP List Page even after selecting records");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Change Status button is disabled in TPP List Page even after selecting records", Status.BC_FAILED);
					return;
				}
				else if(button_ChangeStatusTPP.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
//				else{
					button_ChangeStatusTPP.click();
					sleep(10);
					//Checking for the existence of the Change Status TPP confirm existence 
					GuiTestObject popup_ChangeStatusTPPConfirm = Util.getMappedObject("Html.SPAN", ".text", "Change TPP File Status");
					if(popup_ChangeStatusTPPConfirm!=null){
						//Selecting Cancel button to cancel the Change Status TPP pop up 			
						GuiTestObject button_CancelTPPChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
						if(button_CancelTPPChangeStatus!= null){
							button_CancelTPPChangeStatus.waitForExistence(10, 2);
							button_CancelTPPChangeStatus.click();
							sleep(2);
							button_ChangeStatusTPP.waitForExistence(10,2);
						}
						else{
							System.out.println("Cancel TPP Change Status button is absent on TPP Change Status pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Cancel TPP Change Status button is absent on TPP Change Status pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for Cancel button existence check
						
						//Selecting the change status button again to make the Change Status pop up re-appear
						button_ChangeStatusTPP.click();
						sleep(10);
						
						//Selecting the current status fields
						ArrayList<GuiTestObject> text_StatusList = Util.getGWTMappedObjects("Html.INPUT.text", ".className", "x-form-field x-form-text");
						System.out.println("text_currentStatusList Size: "+text_StatusList.size());
						TextGuiTestObject text_currentStatus = null;
						TextGuiTestObject text_newStatus = null;
						for(int i=0;i<text_StatusList.size();i++){
							System.out.println("Id: "+text_StatusList.get(i).getProperty(".id").toString());
						}
						//Checking the existence of the status fields
						if(text_StatusList.size()<=0){
							System.out.println("Current Status field is absent on TPP File change status pop up");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Current Status field is absent on TPP File change status pop up", Status.BC_FAILED);
							return;
						}
						else{
							text_currentStatus = (TextGuiTestObject) text_StatusList.get(text_StatusList.size()-2);
							text_newStatus = (TextGuiTestObject) text_StatusList.get(text_StatusList.size()-1);
						}
						
						//Checking the existence of the current status fields
						if(text_currentStatus!=null){			
							text_currentStatus.click();			
							text_currentStatus.setText(currentStatus);
							sleep(2);
							//Selecting the Current Status from the drop down
							//RegularExpression regExcurrentStatusDropDwn = new RegularExpression("x-auto-[0-9].*",false);
							if(currentStatus.isEmpty()){
								System.out.println("The Current Status string is empty");
							}
							else{
//								ArrayList<GuiTestObject> list_currentStatusList = Util.getGWTMappedObjects("Html.DIV",".id",regExcurrentStatusDropDwn, "Html.DIV",".text", tppName);
								ArrayList<GuiTestObject> list_currentStatusList = Util.getGWTMappedObjects("Html.DIV",".text", currentStatus);
								GuiTestObject list_currentStatus = null;
								if(list_currentStatusList.size()==0){
									System.out.println("Current Status list dropdown is absent on TPP File change status pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Current Status list dropdown is absent on TPP File change status pop up", Status.BC_FAILED);
									return;
								}
								for(int i=0;i<list_currentStatusList.size();i++){
									System.out.println("list_currentStatusList: "+list_currentStatusList.get(i).getProperty(".text").toString());
								}
								
								list_currentStatus = list_currentStatusList.get(list_currentStatusList.size()-1);						
								if(list_currentStatus!=null){
									System.out.println("Inside the Current Status dropdown list");	
									list_currentStatus.click();
								}
								else{
									System.out.println("Current Status list dropdown not found on TPP File change status pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Current Status list dropdown not found on TPP File change status pop up", Status.BC_FAILED);
									return;
								}								
							}//End of Selecting the Current Status from the drop down
						}
						else{
							System.out.println("Current Status not found on TPP File change status pop up");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Current Status not found on TPP File change status pop up", Status.BC_FAILED);
							return;
						}//End of selection of Current Status By from drop down
							
						//Selection of new Status 
						if(text_newStatus!=null){			
							text_newStatus.click();			
							text_newStatus.setText(newStatus);
							sleep(2);
							//Selecting the New Status from the drop down
							//RegularExpression regExnewStatusDropDwn = new RegularExpression("x-auto-[0-9].*",false);
							if(newStatus.isEmpty()){
								System.out.println("The New Status string is empty");
							}
							else{
								//ArrayList<GuiTestObject> list_newStatusList = Util.getGWTMappedObjects("Html.DIV",".id",regExnewStatusDropDwn, "Html.DIV",".text", tppName);
								ArrayList<GuiTestObject> list_newStatusList = Util.getGWTMappedObjects("Html.DIV",".text", newStatus);
								GuiTestObject list_newStatus = null;
								if(list_newStatusList.size()==0){
									System.out.println("New Status list dropdown is absent on TPP File change status pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "New Status list dropdown is absent on TPP File change status pop up", Status.BC_FAILED);
									return;
								}
								for(int i=0;i<list_newStatusList.size();i++){
									System.out.println("list_newStatusList: "+list_newStatusList.get(i).getProperty(".text").toString());
								}

								list_newStatus = list_newStatusList.get(list_newStatusList.size()-1);						
								if(list_newStatus!=null){
									System.out.println("Inside the New Status dropdown list");	
									list_newStatus.click();
								}
								else{
									System.out.println("New Status list dropdown not found on TPP File change status pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "New Status list dropdown not found on TPP File change status pop up", Status.BC_FAILED);
									return;
								}

							}//End of Selecting the New Status from the drop down
						}
						else{
							System.out.println("New Status not found on TPP File change status pop up");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "New Status not found on TPP File change status pop up", Status.BC_FAILED);
							return;
						}//End of Selecting the new status field
						
					}//End of Checking for the existence of the Change Status TPP confirm existence
					
				}//End of Checking whether the ChangeStatus button is enabled or disabled
				
			}//End of Selecting the ChangeStatus button to Change Status the selected records
			
			//Checking whether the no change status is present
			GuiTestObject msg_NoStatusChange = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "No TPP File status will be changed for the file(s).");
			if(msg_NoStatusChange!= null){
				msg_NoStatusChange.waitForExistence(30, 2);
				System.out.println("No TPP File status will be changed for the file(s).");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No TPP File status will be changed for the file(s).", Status.BC_FAILED);
				return;
			}
			else{
				System.out.println("'No TPP File status will be changed for the file(s).'-Message is not seen");
			}//End of Checking whether the no change status is present
			
			//Checking whether the change status is possible or not
			String msg_StatusChangeString = "TPP File Status will be changed for "+loopUBound+" file(s).";
			GuiTestObject msg_StatusChange = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_StatusChangeString);
			if(msg_StatusChange!= null){
				msg_StatusChange.waitForExistence(30, 2);
			}
			else{
				System.out.println(msg_StatusChangeString);
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, msg_StatusChangeString, Status.BC_FAILED);
				return;
			}//End of Checking whether the change status is possible or not
			
			//Selecting Submit button to submit the Change Status TPP pop up 			
			GuiTestObject button_SubmitTPPChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
			if(button_SubmitTPPChangeStatus!= null){
				button_SubmitTPPChangeStatus.waitForExistence(10, 2);
				button_SubmitTPPChangeStatus.click();
				sleep(5);
				//Searching for Confirm TPP File Status pop up 			
				GuiTestObject poup_SubmitTPPChangeStatus = (GuiTestObject)Util.getMappedObject("Html.SPAN", ".text", "Confirm TPP File Status");
				if(poup_SubmitTPPChangeStatus!= null){
					poup_SubmitTPPChangeStatus.waitForExistence(10, 2);					
					sleep(2);	
					//Selecting Cancel button to cancel the Confirm TPP File Status pop up 			
//					GuiTestObject button_CancelTPPChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
					ArrayList<GuiTestObject> button_CancelTPPChangeStatusList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
					GuiTestObject button_CancelTPPChangeStatus = null;
					if(button_CancelTPPChangeStatusList.size()<=0){
						System.out.println("Cancel TPP Change Status button is absent on Confirm TPP File status pop up");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Cancel TPP Change Status button is absent on Confirm TPP File status pop up", Status.BC_FAILED);
						return;
					}
					else{
						button_CancelTPPChangeStatus = button_CancelTPPChangeStatusList.get(button_CancelTPPChangeStatusList.size()-1);
					}
					if(button_CancelTPPChangeStatus!= null){
						button_CancelTPPChangeStatus.waitForExistence(10, 2);
						button_CancelTPPChangeStatus.click();
						sleep(2);
						button_SubmitTPPChangeStatus.waitForExistence(10,2);
					}
					else{
						System.out.println("Cancel TPP Change Status button is not found on TPP Change Status pop-up confirmation window");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Cancel TPP Change Status button is not found on TPP Change Status pop-up confirmation window", Status.BC_FAILED);
						return;
					}//End of else for Cancel button existence check
					
					//Selecting the submit button to reappear the confirm status pop up
					button_SubmitTPPChangeStatus.click();
					sleep(5);					
				}
				else{
					System.out.println("Confirm TPP File Status pop up is absent on submiting file status change");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Confirm TPP File Status pop up is absent on submiting file status change", Status.BC_FAILED);
					return;
				}//End of else for Searching for Confirm TPP File Status pop up
			}
			else{
				System.out.println("Submit TPP Change Status Submit button is absent on TPP Change Status pop-up confirmation window");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Submit TPP Change Status Submit button is absent on TPP Change Status pop-up confirmation window", Status.BC_FAILED);
				return;
			}//End of else for Submit button existence check
			
			//Filling mandatory field confirmation number on confirm TPP File status pop up
//			ArrayList<GuiTestObject> text_ConfirmationNoList = Util.getGWTMappedObjects("Html.DIV",".className","x-grid3-cell-inner x-grid3-col-confirmationNumber x-component");
			ArrayList<GuiTestObject> text_ConfirmationNoList = Util.getGWTMappedObjects("Html.TABLE",".text",userId);
			System.out.println("text_ConfirmationNoList size: "+text_ConfirmationNoList.size());
			StatelessGuiSubitemTestObject cell_ConfNo = null;
			
			if(text_ConfirmationNoList.size()==0){
				System.out.println("Mandatory field confirmation number could not be found on confirm TPP File status pop up");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field confirmation number could not be found on confirm TPP File status pop up", Status.BC_FAILED);
				return;
			}		
			for(int loop=0;loop<text_ConfirmationNoList.size();loop++){
				cell_ConfNo = (StatelessGuiSubitemTestObject) text_ConfirmationNoList.get(loop);		
				confNo = Integer.toString(rand.nextInt(1000)+1000);
				if(cell_ConfNo!=null){
					cell_ConfNo.waitForExistence(20, 2);
					cell_ConfNo.doubleClick(atCell(atRow(atIndex(0)), 
											atColumn(atIndex(5))));
					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtHome}+{ExtEnd}{ExtDelete}");
					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputChars(confNo);
					sleep(1);
//					sleep(20);
				}
				else{
					System.out.println("Mandatory field confirmation number is absent on confirm TPP File status pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field confirmation number is absent on confirm TPP File status pop up", Status.BC_FAILED);
					return;
				}			
			}//End of Filling mandatory field confirmation number on confirm TPP File status pop up
			
			//Filling mandatory field confirmed amount on confirm TPP File status pop up
//			ArrayList<GuiTestObject> text_ConfirmedAmtList = Util.getGWTMappedObjects("Html.DIV",".className","x-grid3-cell-inner x-grid3-col-confirmaedAmount");
			ArrayList<GuiTestObject> text_ConfirmedAmtList = Util.getGWTMappedObjects("Html.TABLE",".text",userId);
			System.out.println("text_ConfirmedAmtList size: "+text_ConfirmedAmtList.size());
			StatelessGuiSubitemTestObject cell_ConfAmt = null;		
			if(text_ConfirmationNoList.size()==0){
				System.out.println("Mandatory field confirmed amount could not be found on confirm TPP File status pop up");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field confirmed amount could not be found on confirm TPP File status pop up", Status.BC_FAILED);
				return;
			}		
			for(int loop=0;loop<text_ConfirmedAmtList.size();loop++){
				cell_ConfAmt = (StatelessGuiSubitemTestObject) text_ConfirmedAmtList.get(loop);			
//				confAmt = Integer.toString(rand.nextInt(100)+100);
				System.out.println("Total txnAmt: "+totalTxnAmt);
				confAmt = Double.toString(totalTxnAmt);
				if(cell_ConfAmt!=null){
					cell_ConfAmt.waitForExistence(20, 2);
					cell_ConfAmt.doubleClick(atCell(atRow(atIndex(0)), 
											  atColumn(atIndex(7))));
					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtHome}+{ExtEnd}{ExtDelete}");
					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputChars(confAmt);
					sleep(1);				
				}
				else{
					System.out.println("Mandatory field confirmed amount is absent on confirm TPP File status pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field confirmed amount is absent on confirm TPP File status pop up", Status.BC_FAILED);
					return;
				}			
			}//End of Filling mandatory field confirmed amount on confirm TPP File status pop up
			
			//Selecting Submit And Continue button to Submit And Continue the Change Status TPP pop up 			
			GuiTestObject button_SubmitAndContinue = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit And Continue");
			if(button_SubmitAndContinue!= null){
				button_SubmitAndContinue.waitForExistence(10, 2);
				button_SubmitAndContinue.click();
				sleep(2);	
				//Checking for the existence of the submit confirmation pop up		
				GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.SPAN", ".text", "Confirm Action");
				if(popup_SubmitConfirm==null){			
					System.out.println("Submit confirmation pop up not present");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Submit confirmation pop up not present", Status.BC_FAILED);
					return;			
				}
				else{
					System.out.println("Submit confirmation pop up is present");	
					popup_SubmitConfirm.waitForExistence(30, 2);
					
					//Selecting the Cancel button on the confirmation pop up 		
					GuiTestObject button_ConfirmCancel = Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
					if(button_ConfirmCancel!=null){
						button_ConfirmCancel.click();	
						sleep(5);
					}
					else{
						System.out.println("Cancel button not present on submit confirmation pop up");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
						return;
					}//End of Cancel button on the confirmation pop up
					
					button_SubmitAndContinue.click();
					popup_SubmitConfirm.waitForExistence(30, 2);
					
					//Selecting the Confirm button on the confirmation pop up 		
					GuiTestObject button_Confirm = Util.getMappedObject("Html.BUTTON", ".value", "Confirm");
					if(button_Confirm!=null){
						button_Confirm.click();	
						sleep(20);
					}
					else{
						System.out.println("Confirm button not present on submit confirmation pop up");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
						return;
					}//End of Confirm button on the confirmation pop up
					
				}//End of existence of the submit confirmation pop up check
			
			}
			else{
				System.out.println("Submit And Continue button is absent on on confirm TPP File status pop up");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Submit And Continue button is absent on on confirm TPP File status pop up", Status.BC_FAILED);
				return;
			}//End of else for Submit And Continue button existence check
		
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);

			//Checking successful submission message
			String statusChangeSuccessMsg = "The TPP File status has been changed for "+loopUBound+" File(s)";
			GuiTestObject msg_StatusChangeSuccess = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", statusChangeSuccessMsg);
			if(msg_StatusChangeSuccess!= null){
				msg_StatusChangeSuccess.waitForExistence(30, 2);				
				System.out.println(statusChangeSuccessMsg);
			}
			else{				
				System.out.println("No TPP File status are changed.");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No TPP File status are changed.", Status.BC_FAILED);
				return;
			}//End of Checking successful submission message
			
			//Selecting Cancel button to cancel the Confirm TPP File Status pop up 			
//			GuiTestObject button_CancelTPPChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
			ArrayList<GuiTestObject> button_CancelTPPChangeStatusList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
			GuiTestObject button_CancelTPPChangeStatus = null;
			if(button_CancelTPPChangeStatusList.size()<=0){
				System.out.println("Cancel TPP Change Status button is absent on Confirm TPP File status pop up");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Cancel TPP Change Status button is absent on Confirm TPP File status pop up", Status.BC_FAILED);
				return;
			}
			else{
				button_CancelTPPChangeStatus = button_CancelTPPChangeStatusList.get(button_CancelTPPChangeStatusList.size()-1);
			}
			if(button_CancelTPPChangeStatus!= null){
				button_CancelTPPChangeStatus.waitForExistence(10, 2);
				button_CancelTPPChangeStatus.click();
				sleep(2);				
			}
			else{
				System.out.println("Cancel TPP Change Status button is not found on TPP Change Status pop-up confirmation window");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Cancel TPP Change Status button is not found on TPP Change Status pop-up confirmation window", Status.BC_FAILED);
				return;
			}//End of else for Cancel button existence check
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			sleep(10);
			
			//Returning to the home tab as an exit point
			if(link_home().exists()
					|| link_home().ensureObjectIsVisible()){
				link_home().waitForExistence(20, 2);
				link_home().click();
				//Checking the existence of refresh button at the welcome area on home page				
				GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
				if(button_RefreshAtHome!= null){
					button_RefreshAtHome.waitForExistence(20, 2);
					button_RefreshAtHome.ensureObjectIsVisible();
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Home tab is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Home tab is absent in Batch List Page", Status.BC_FAILED);
				return;
			}//End of returning to the home tab as an exit point
			
			//Component success message
			String cmpSuccessMsg = "The TPP File status has been changed for "+loopUBound+" File(s)";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);

		}//End of try
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}//End of catch
		
	}//End of execute component
	
}//End of class

