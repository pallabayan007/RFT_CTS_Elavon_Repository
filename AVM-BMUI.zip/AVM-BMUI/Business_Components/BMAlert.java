package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.BMAlertHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class BMAlert extends BMAlertHelper
{
	/**
	 * Script Name   : <b>BMAlert</b>
	 * Generated     : <b>Feb 1, 2012 6:32:05 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/02/01
	 * @author axbane1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "BatchAlert";
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 0)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 0 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 0 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Home page
			 * ---Ending on Home Page
			 */

			
			String batchAlertMessage = "";
			//Declaring the batch alert message templates
			String batchAlertMessage1 = "Batches suspended for";
			String batchAlertMessage2 = "Merchant file(s) has/have not been transmitted by a certain time causing settlement window to be missed (process as soon as possible)";
			String totalbatchAlertMessage = "";
			String totalbatchAlertMessageHome = "";
			
			//Searching for the batch alert messages			
			ArrayList<GuiTestObject> list_SelectBatchAlertList = new ArrayList<GuiTestObject>();
			GuiTestObject table_BatchAlertGrid = null;
			batchAlertMessage = batchAlertMessage1;
			//Selecting the batch alert
			RegularExpression regExBatchAlert1 = new RegularExpression("x-auto-[0-9].*",false);
			list_SelectBatchAlertList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchAlert1,"Html.A", ".text", batchAlertMessage);
			System.out.println("list_SelectBatchAlertList1 size: "+list_SelectBatchAlertList.size());
			if(list_SelectBatchAlertList.size()==0){
				batchAlertMessage = batchAlertMessage2;
				//Selecting the batch alert
				RegularExpression regExBatchAlert2 = new RegularExpression("x-auto-[0-9].*",false);
				list_SelectBatchAlertList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchAlert2,"Html.A", ".text", batchAlertMessage);
				System.out.println("list_SelectBatchAlertList2 size: "+list_SelectBatchAlertList.size());
				
				//Checking for no batch alert message
				if(list_SelectBatchAlertList.size()==0){
					System.out.println("Batch Alert message of any of the 2 templates is not found on the Home page batch alert section");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch alert message of any of the 2 templates is not found on the Home page batch alert section", Status.BC_FAILED);
					return;					
				}//End of Checking for no batch alert message
				
			}//End of batchAlertMessage2 select

			table_BatchAlertGrid = list_SelectBatchAlertList.get(list_SelectBatchAlertList.size()-1);				
			
			
			//Checking the existence of the Alerts table on the home page
//			GuiTestObject table_BatchAlertGrid = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "Alerts");
			if(table_BatchAlertGrid!=null){
				//Selecting the batch alert message supplied
				ArrayList<GuiTestObject>list_HomePageBatchAlertLink = Util.getGWTMappedObjects("Html.A", ".text", batchAlertMessage);
				System.out.println("list_HomePageBatchAlertLink size: "+list_HomePageBatchAlertLink.size());
				GuiTestObject link_HomeBatchAlert = null;
				
				//Checking the batch alert message existence
				if(list_HomePageBatchAlertLink.size()<1){
					System.out.println("Batch alert message is not found on the Home page batch alert section");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch alert message is not found on the Home page batch alert section", Status.BC_FAILED);
					return;
				}
				else{
					for(int i=0;i<list_HomePageBatchAlertLink.size();i++){
						System.out.println("Text Value for position "+i+" is : "+list_HomePageBatchAlertLink.get(i).getProperty(".text").toString());
					}					
					link_HomeBatchAlert = list_HomePageBatchAlertLink.get(list_HomePageBatchAlertLink.size()-1);
					//Clicking the batch alert message link
					if(link_HomeBatchAlert!=null){
						link_HomeBatchAlert.waitForExistence(20, 2);
						//Fetching the full batch alert message on the home page
						totalbatchAlertMessageHome = link_HomeBatchAlert.getProperty(".text").toString();
						if(totalbatchAlertMessageHome.contains("(process as soon as possible)")){
							totalbatchAlertMessageHome = totalbatchAlertMessageHome.substring(0, totalbatchAlertMessageHome.indexOf("(process as soon as possible)")).trim();
						}//End of Fetching the full batch alert message on the home page
						System.out.println("totalbatchAlertMessageHome: "+totalbatchAlertMessageHome);
						if(totalbatchAlertMessageHome.isEmpty()){
							System.out.println("Batch alert message is irretrievable on the home page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Batch alert message is irretrievable on the home page", Status.BC_FAILED);
							return;
						}
						link_HomeBatchAlert.click();
						
						//Waiting for the message details to populate on the batch list page and loading message to disappear
						for(int loop=0;loop<20;loop++){
							ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
							System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
							if(progressBar_LoadingList.size()>=1){
								for(int i=0;i<progressBar_LoadingList.size();i++){
									System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
									System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
								}
								GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
								System.out.println("Progressbar checking loopcount: "+loop);
								if(progressBar_Loading!=null){
									System.out.println("The batch alert message details is still NOT populated");
									sleep(2);
									continue;					
								}
								else{
									System.out.println("The batch alert message details is populated");
									break;
								}
							}//End of if for progress bar loading
							else{
								System.out.println("The batch alert message details is/are populated");
								break;
							}//End of else for progress bar loading
							
						}//End of for statement to check the progress bar loading 
				
						sleep(5);
						
						//Checking for the existence of the batch message alert on the top of the details page
						ArrayList<GuiTestObject> text_BatchAlertMsgList = Util.getGWTMappedObjects("Html.DIV", ".text", batchAlertMessage);
						GuiTestObject text_BatchAlertMsg = null;
						if(text_BatchAlertMsgList.size()>0){
							text_BatchAlertMsg = text_BatchAlertMsgList.get(text_BatchAlertMsgList.size()-1);
							
						}
						else{
							System.out.println("Batch alert message is absent on the alert message details page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Batch alert message is absent on the alert message details page", Status.BC_FAILED);
							return;
						}					
						
						if(text_BatchAlertMsg!=null){
							text_BatchAlertMsg.waitForExistence(10, 2);
							totalbatchAlertMessage = text_BatchAlertMsg.getProperty(".text").toString().trim();
							if(totalbatchAlertMessage.isEmpty()){
								System.out.println("Batch alert message is irretrievable on the alert message details page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Batch alert message is irretrievable on the alert message details page", Status.BC_FAILED);
								return;
							}
							System.out.println("totalbatchAlertMessage: "+totalbatchAlertMessage);
							
							//Checking for batch alert message mismatch on home and details page
							if(!totalbatchAlertMessage.equals(totalbatchAlertMessageHome)){
								String batchAlertFailureMsg = "Batch alert message on home page \""+totalbatchAlertMessageHome+"\"" +
																" is not matching with batch alert message on details page \""
																	+totalbatchAlertMessage+"\"";
								System.out.println(batchAlertFailureMsg);
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(BusinessComponentName, batchAlertFailureMsg, Status.BC_FAILED);
								return;
							}//End of Checking for batch alert message mismatch on home and details page
							
							//Checking the existence of Return to home button at the alert message details page				
							GuiTestObject button_ReturnToHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Return To Home");
							if(button_ReturnToHome!= null){					
								button_ReturnToHome.waitForExistence(100, 2);
								button_ReturnToHome.ensureObjectIsVisible();	
								button_ReturnToHome.click();
								
								//Waiting for the message details to populate on the home page and loading message to disappear
								for(int loop=0;loop<20;loop++){
									ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
									System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
									if(progressBar_LoadingList.size()>=1){
										for(int i=0;i<progressBar_LoadingList.size();i++){
											System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
											System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
										}
										GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
										System.out.println("Progressbar checking loopcount: "+loop);
										if(progressBar_Loading!=null){
											System.out.println("The home page is still NOT populated");
											sleep(2);
											continue;					
										}
										else{
											System.out.println("The home page is populated");
											break;
										}
									}//End of if for progress bar loading
									else{
										System.out.println("The home page is/are populated");
										break;
									}//End of else for progress bar loading
									
								}//End of for statement to check the progress bar loading 
						
								sleep(5);
							}
							else{
								System.out.println("Return to Home button is absent in alert message details page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo("UserLogon", "Return to Home button is absent in alert message details page", Status.BC_FAILED);
								return;
							}//End of Checking the existence of Return to home button at the alert message details page
						}
						else{
							System.out.println("Batch alert message is not found on the alert message details page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Batch alert message is not found on the alert message details page", Status.BC_FAILED);
							return;
						}//End of Checking for the existence of the batch message alert on the top of the details page
					}
					else{
						System.out.println("Batch alert message Link is not found on the Home page batch alert section");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Batch alert message Link is not found on the Home page batch alert section", Status.BC_FAILED);
						return;
					}//End of else for batch alert link click
					
				}//End of else for batch alert existence check		
				
			}//End of if for checking the batch alert message table
			else{
				System.out.println("Batch Alert table is absent in Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Batch Alert table is absent in Page", Status.BC_FAILED);
				return;
			}//End of else for checking the batch alert message table 				
			
			//Component success message
			String cmpSuccessMsg = "Batch alert message \""+totalbatchAlertMessageHome+"\" link is found on the home page and alert details page can be opened";
			System.out.println(cmpSuccessMsg);
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
			
					

		}
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}


	}//End of ExecuteComponent
	
}//End of claass

