package Business_Components;
import java.util.ArrayList;
import resources.Business_Components.TxnListVoidHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxghos1
 */
public class TxnListVoid extends TxnListVoidHelper
{
	/**
	 * Script Name   : <b>TxnListVoid</b>
	 * Generated     : <b>Dec 4, 2011 9:53:41 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/12/04
	 * @author sxghos1
	 */
	
	boolean error = false;
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "TxnListVoid";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 3)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 3 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 3 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
		return;
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			String tranStatus = (String) args[0];
			if(tranStatus.isEmpty()){
				tranStatus = "APPROVED";
			}
			tranStatus = tranStatus.toUpperCase();
			String Notes = (String) args[1];
			String multiVoidReq = (String) args[2];
			int loopUBound = 0;
			
			//Verifying whether the Void Transaction  button is enabled or disabled			
			GuiTestObject button_VoidTxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Void Transaction");
			if(button_VoidTxn!= null){
				button_VoidTxn.waitForExistence(20, 2);
				if(button_VoidTxn.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Void Transaction  button is enabled in Transaction search list page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Void Transaction", "Void Transaction  button is enabled in Transaction List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_VoidTxn.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Void Transaction  button is disabled rightly in Transaction search list page while no records are selected");
//					button_VoidTxn.click();
//					sleep(2);
				}
				
			}
			else{
				System.out.println("Void Transaction  button is absent in Transaction search list page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "Void Transaction  button is absent in Transaction search list page", Status.BC_FAILED);
				return;
			}//End of Verifying whether the Void Transaction  button is enabled or disabled

			RegularExpression regExTxnSearch = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
			System.out.println("After regex");
			ArrayList<GuiTestObject> list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearch,"Html.TABLE", ".text", tranStatus);
			System.out.println("After arraylist");
			StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
			System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
			if(list_SelectTxnSearchResultList.size()!=0){
				
				if(multiVoidReq.equalsIgnoreCase("yes")){
					if(list_SelectTxnSearchResultList.size()>2){
						loopUBound = 2;
					}
					else if(list_SelectTxnSearchResultList.size()<=2){
						loopUBound = 1;
					}					
				}				
				else{
					loopUBound = 1;
				}
				
				//Looping through the matching records
				for(int loop=0;loop<loopUBound;loop++){
					System.out.println("checkbox_SearchRecord : "+list_SelectTxnSearchResultList.get(loop).getProperty(".text").toString());
					checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectTxnSearchResultList.get(loop);
//					System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
					if(checkbox_SearchRecord!=null){
//						System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//						System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//						checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//															Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
						checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
															atColumn(atIndex(0))));
						sleep(1);
//						break;
					}
					else{
						System.out.println("Record not matching ");
						continue;
					}
				}
			}
			else{
				System.out.println("No matching record found in Transaction Search List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "No matching record found in Transaction Search List Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Void Transaction button			
			GuiTestObject button_VoidTransaction = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Void Transaction");
			if(button_VoidTransaction!= null){
				button_VoidTransaction.waitForExistence(10, 2);
				if(button_VoidTransaction.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Void Transaction  button is disabled in Transaction search list page even after selecting record(s)");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Void Transaction", "Void Transaction  button is disabled in Transaction search list page even after selecting record(s)", Status.BC_FAILED);
					return;
				}
				button_VoidTransaction.click();
				sleep(5);
			}
			else{
				System.out.println("Void Transaction button is absent in Transaction Search List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "Void Transaction button is absent in Transaction Search List page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Enter Notes in the Void Transaction page
			RegularExpression regExNotes = new RegularExpression("x-auto-[0-9].*-input",false);
//			TextGuiTestObject text_VoidTransactionNotesNotes = (TextGuiTestObject)Util.getMappedObject("Html.TEXTAREA", ".className", "x-form-field x-form-textarea");
			TextGuiTestObject text_VoidTransactionNotesNotes = (TextGuiTestObject)Util.getGWTMappedObject("Html.TEXTAREA", ".id", regExNotes);
			if(text_VoidTransactionNotesNotes!= null){
				text_VoidTransactionNotesNotes.waitForExistence(10, 2);
				text_VoidTransactionNotesNotes.click();
				text_VoidTransactionNotesNotes.setText(Notes);
				sleep(1);
			}
			else{
				System.out.println("Note area is absent in Void Transaction Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "Enter note area is absent in Void Transaction Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Visible to external user check box in the Void Transaction page			
			ArrayList<GuiTestObject> checkbox_VisibleExtUserList = Util.getGWTMappedObjects("Html.DIV", ".text", "Visible to External Users");
			GuiTestObject checkbox_VisibleExtUser = null;
			if(checkbox_VisibleExtUserList.size()!=0){
				checkbox_VisibleExtUser = checkbox_VisibleExtUserList.get(checkbox_VisibleExtUserList.size()-1);
				if(checkbox_VisibleExtUser!= null){				
					checkbox_VisibleExtUser.waitForExistence(10, 2);
					checkbox_VisibleExtUser.click();			
					sleep(1);
				}
				else{
					System.out.println("Visible to external user checkbox is absent in Void Transaction Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Void Transaction", "Visible to external user check box is absent in Void Transaction Page", Status.BC_FAILED);
					return;
				}
			}
			
			else{
				System.out.println("Visible to external user checkbox not found in Void Transaction Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "Visible to external user check box not found in Void Transaction Page", Status.BC_FAILED);
				return;
			}
			
			
			//Selecting Submit button			
			GuiTestObject button_Submit = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Submit");
			if(button_Submit!= null){
				button_Submit.waitForExistence(10, 2);
				button_Submit.click();
				sleep(5);
			}
			else{
				System.out.println("Submit button is absent in Void Transaction Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "Submit button is absent in Void Transaction Page", Status.BC_FAILED);
				return;
			}
			
			//Searching for the confirm action pop up			
			GuiTestObject popup_ConfirmAction = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "Confirm Action");				
			if(popup_ConfirmAction!= null){		
				popup_ConfirmAction.waitForExistence(10, 2);
				
				//Selecting the Cancel button on the confirm action pop up 		
				ArrayList<GuiTestObject> button_ConfirmCancelList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
				GuiTestObject button_ConfirmCancel = null;
				button_ConfirmCancel = button_ConfirmCancelList.get(button_ConfirmCancelList.size()-1);
				if(button_ConfirmCancel!=null){
					button_ConfirmCancel.click();	
					sleep(5);
				}
				else{
					System.out.println("Cancel button not present on confirm action pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
					return;
				}//End of Cancel button on the confirm action pop up
				
				//Clicking Submit Button again
				button_Submit.click();
				popup_ConfirmAction.waitForExistence(10, 2);
				
				//Selecting confirm button on the pop up page			
				GuiTestObject button_Confirm = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Confirm");
				if(button_Confirm!= null){
					button_Confirm.waitForExistence(10, 2);
					button_Confirm.click();
					sleep(15);
				}
				else{
					System.out.println("Confirm button is absent in Confirm action pop up Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Void Transaction", "Confirm button is absent in Confirm action pop up Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Confirm action pop up is absent in Void Transaction Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "Confirm action pop up is absent in Void Transaction Page", Status.BC_FAILED);
				return;
			}
			
			//Checking whether the transaction is void transaction successfully or not
			String msg_VoidTxn  = "0 void failed. "+loopUBound+" void successful.";
			
			GuiTestObject msg_BatchSuccessCreate = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_VoidTxn);
			if(msg_BatchSuccessCreate!= null){
				msg_BatchSuccessCreate.waitForExistence(30, 2);
				System.out.println("Transaction Voided successfully message is displayed on the Void Transaction page");
				//Selecting the newly created batch id			
	/*				TextGuiTestObject text_BatchId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "batchId");
				if(text_BatchId!= null){
					text_BatchId.waitForExistence(10, 2);
					batchId = text_BatchId.getProperty(".value").toString();
					sleep(1);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");	
					System.out.println("Batch created successfully with id: "+batchId);
				}
				else{
					System.out.println("Batch not created successfully");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Create Batch", "Batch not created successfully", Status.BC_FAILED);
					return;
				}*/
			}
			else{
				System.out.println("Successful void message is not displayed on the Void Transaction page");	
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "Successful void message is not displayed on the Void Transaction page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Cancel button			
			GuiTestObject button_Cancel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Cancel");
			if(button_Cancel!= null){
				button_Cancel.waitForExistence(10, 2);
				button_Cancel.click();
				sleep(15);
			}
			else{
				System.out.println("Cancel button is absent in Void Transaction Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Void Transaction", "Cancel button is absent in Void Transaction Page", Status.BC_FAILED);
				return;
			}
			
			
			
			//Selecting the home link to end in the home page				
			link_home().waitForExistence(10, 2);
			link_home().click();
			sleep(15);

			
			//Component success message
			String cmpSuccessMsg = "0 void failed. "+loopUBound+" void successful.";;
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
			
		}
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}


	}//End of ExecuteComponenet
	
}

