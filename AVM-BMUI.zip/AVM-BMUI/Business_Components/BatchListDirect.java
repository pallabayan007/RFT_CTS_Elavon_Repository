package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.BatchListDirectHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class BatchListDirect extends BatchListDirectHelper
{
	/**
	 * Script Name   : <b>BatchListDirect</b>
	 * Generated     : <b>Nov 8, 2011 2:46:50 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/08
	 * @author axbane1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "BatchListDirect";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 0)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 0 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 0 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{			
			String noOfBatchInListPg = "";			
			
			//Selecting the batch management tab from the home tab
            link_batchManagement().waitForExistence(20, 2);
            link_batchManagement().click();
            
            
            //Selecting Batch List Tab under Batch Management tab 
            button_batchListbutton().waitForExistence(60, 2);
            button_batchListbutton().click();
//            GuiTestObject button_BatchList = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Batch List");
//            if(button_BatchList!= null){
//                  button_BatchList.waitForExistence(60, 2);
//                  button_BatchList.click();
////                sleep(15);
//            }
//            else{
//                  System.out.println("Batch List Tab is absent under batch management");
//                  error = true;
//                Util.scenarioStatus = false;
//                CRAFT_Report.LogInfo(tsComponentName, "Batch List Tab is absent under batch management", Status.BC_FAILED);
//                return;
//            }
            
            
            //Waiting for the batch list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The batch list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The batch list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The batch list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 		
			
            
            //Fetching total number of records fetched on the batch list page
			ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
			System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
			GuiTestObject text_totalNoOfBatchRecords = null;
			for(int loop=0;loop<text_PageToolbarList.size();loop++){
				text_totalNoOfBatchRecords = text_PageToolbarList.get(loop);
				System.out.println(text_totalNoOfBatchRecords.getProperty(".text").toString());
			}
			text_totalNoOfBatchRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
			if(text_totalNoOfBatchRecords!= null){
				text_totalNoOfBatchRecords.waitForExistence(10, 2);
				String text_TotalRecordsFetched = text_totalNoOfBatchRecords.getProperty(".text").toString();
				noOfBatchInListPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(" "),text_TotalRecordsFetched.length()).trim();
				System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfBatchInListPg :"+noOfBatchInListPg);
				sleep(1);
				//Checking for the number of batch received record on the batch list page
				if(noOfBatchInListPg.isEmpty()){
					System.out.println("Total Batch  Number is absent on Batch List page bottom toolbar");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Total Batch  Number is absent on Batch List page bottom toolbar", Status.BC_FAILED);
					return;	
				}				
			}
			else{
				System.out.println("Total Batch  records number is absent on batch List-summary view Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Total Batch  records number is absent on batch List-summary view Page", Status.BC_FAILED);
				return;
			}
            
			//Selecting the home tab to return to the home page
			link_home().waitForExistence(30, 2);
		    link_home().click();
            
			
			//Checking the existence of refresh button at the welcome area on home page				
			GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
			if(button_RefreshAtHome!= null){
				button_RefreshAtHome.waitForExistence(20, 2);
				button_RefreshAtHome.ensureObjectIsVisible();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
				return;
			}
            
//          button_batchListbutton().waitForExistence(30, 2);
//          button_batchListbutton().click();
            
            //Component success message
			String cmpSuccessMsg = "#Total Batch number in Batch list page: "+noOfBatchInListPg;
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);

		}
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}
		
	}//End of execute component
}

