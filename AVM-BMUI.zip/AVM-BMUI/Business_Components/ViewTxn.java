package Business_Components;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import resources.Business_Components.ViewTxnHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class ViewTxn extends ViewTxnHelper
{
	/**
	 * Script Name   : <b>ViewTxn</b>
	 * Generated     : <b>Feb 2, 2012 6:22:55 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/02/02
	 * @author sxghos1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "ViewTxn";
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 1)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 1 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 3 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{


		//Place your Code here
		try{
			/*
			 * ---Starting from Transaction List page, i.e. , transaction search tab
			 * ---Ending on Home page, i.e. , Home tab
			 */
			
			String tsComponentName = "ViewTxn";			
			String refNo = (String) args[0];
			String selectTxnString = "";
			String txnId = "";
			int noOfButtons = 0;
			int noOfTextBoxBasicTxn = 0;
			int noOfTextBoxExpandedDetails = 0;
			int noOfTextBoxCustomer = 0;
			int noOfTextBoxCompliance = 0;
			
			//Setting the Txn select string in case of no ref no.
			if(refNo.isEmpty()){
				ArrayList<GuiTestObject> list_SelectTxnSearchResultList = new ArrayList<GuiTestObject>();
				selectTxnString = "USD";
				//Selecting the records to edit in transaction search list page
				RegularExpression regExTxnSearchUSD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
				list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchUSD,"Html.TABLE", ".text", selectTxnString);
				System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
				if(list_SelectTxnSearchResultList.size()==0){
					selectTxnString = "GBP";
					//Selecting the records to edit in transaction search list page
					RegularExpression regExTxnSearchGBP = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
					list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchGBP,"Html.TABLE", ".text", selectTxnString);
					System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
					if(list_SelectTxnSearchResultList.size()==0){
						selectTxnString = "AUD";
						//Selecting the records to edit in transaction search list page
						RegularExpression regExTxnSearchAUD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
						list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchAUD,"Html.TABLE", ".text", selectTxnString);
						System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
						if(list_SelectTxnSearchResultList.size()==0){
							selectTxnString = "EUR";
							//Selecting the records to edit in transaction search list page
							RegularExpression regExTxnSearchEUR = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
							list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchEUR,"Html.TABLE", ".text", selectTxnString);
							System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
							if(list_SelectTxnSearchResultList.size()==0){
								selectTxnString = "CAD";
								//Selecting the records to edit in transaction search list page
								RegularExpression regExTxnSearchCAD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
								list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchCAD,"Html.TABLE", ".text", selectTxnString);
								System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());							
							}//End of CAD select
						}//End of EUR select
					}//End of AUD select
				}//End of GBP select
				
				String searchedTxnString = list_SelectTxnSearchResultList.get(0).getProperty(".text").toString();
				searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf(":")+6, searchedTxnString.length()).trim();
				searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
				System.out.println("searchedTxnString: "+searchedTxnString);
				refNo = searchedTxnString;
				
			}//End of if for Setting the Txn select string in case of no ref no.
			
			//Selecting the first Txn in list by clicking its ref no link			
			ArrayList<GuiTestObject> list_SelectTxnSearchResultList = Util.getGWTMappedObjects("Html.A", ".text", refNo);
			GuiTestObject link_RefNo = null;
			System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
			if(list_SelectTxnSearchResultList.size()>0){
				link_RefNo = list_SelectTxnSearchResultList.get(0);
				//Checking for the existence of the ref no link
				if(link_RefNo != null){
					link_RefNo.waitForExistence(20, 2);
					link_RefNo.click();
					sleep(10);
				}
				else{
					System.out.println("No matching link found in Transaction Search List Page for Reference No.: "+refNo);
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching link found in Transaction Search List Page for Reference No.: "+refNo, Status.BC_FAILED);
					return;
				}//End of Checking for the existence of the ref no link
			}//End of if for ref no link check
			else{
				System.out.println("No matching record found in Transaction Search List Page for Reference No.: "+refNo);
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Transaction Search List Page for Reference No.: "+refNo, Status.BC_FAILED);
				return;
			}
			
			//Searching Void Txn button			
			GuiTestObject button_VoidTxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Void");
			if(button_VoidTxn!= null){
				button_VoidTxn.waitForExistence(10, 2);	
				noOfButtons++;
			}
			else{
				System.out.println("Void button is absent in View Transaction Details Page");
			}
			
			//Searching View Original button			
			GuiTestObject button_ViewOrig = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "View Original");
			if(button_ViewOrig!= null){
				button_ViewOrig.waitForExistence(10, 2);	
				noOfButtons++;
			}
			else{
				System.out.println("View Original button is absent in View Transaction Details Page");
			}
			
			//Searching Delete Txn button			
			GuiTestObject button_Delete = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Delete");
			if(button_Delete!= null){
				button_Delete.waitForExistence(10, 2);	
				noOfButtons++;
			}
			else{
				System.out.println("Delete button is absent in View Transaction Details Page");
			}
			
			//Searching Edit Txn button			
			GuiTestObject button_EditTxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Edit");
			if(button_EditTxn!= null){
				button_EditTxn.waitForExistence(10, 2);	
				noOfButtons++;
			}
			else{
				System.out.println("Edit button is absent in View Transaction Details Page");
			}
			
			//Searching Assign Transaction button			
			GuiTestObject button_AssignTxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Assign Transaction");
			if(button_AssignTxn!= null){
				button_AssignTxn.waitForExistence(10, 2);	
				noOfButtons++;
			}
			else{
				System.out.println("Assign Transaction button is absent in View Transaction Details Page");
			}
			
			//Searching Create New From Existing button			
			GuiTestObject button_CNFETxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Create New From Existing");
			if(button_CNFETxn!= null){
				button_CNFETxn.waitForExistence(10, 2);	
				noOfButtons++;
			}
			else{
				System.out.println("Create New From Existing button is absent in View Transaction Details Page");
			}
			
			//Searching Transaction Life Cycle button			
			GuiTestObject button_TLCTxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Transaction Life Cycle");
			if(button_TLCTxn!= null){
				button_TLCTxn.waitForExistence(10, 2);	
				noOfButtons++;
			}
			else{
				System.out.println("Transaction Life Cycle button is absent in View Transaction Details Page");
			}
			
			//Searching View Receipt button			
			GuiTestObject button_VRTxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "View Receipt");
			if(button_VRTxn!= null){
				button_VRTxn.waitForExistence(10, 2);
				noOfButtons++;
			}
			else{
				System.out.println("View Receipt button is absent in View Transaction Details Page");
			}
			
			//Searching Return to List View button			
			GuiTestObject button_ReturnToListView = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Return to List View");
			if(button_ReturnToListView!= null){
				button_ReturnToListView.waitForExistence(10, 2);
				noOfButtons++;
				//Checking whether the edit button is enabled or disabled
				if(button_ReturnToListView.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Return to List View button is disabled in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Return to List View button is disabled in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
				else{
					System.out.println("Return to List View button is enabled in View Transaction Details Page");
				}			
				//End of Checking whether the edit button is enabled or disabled
			}
			else{
				System.out.println("Return to List View button is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Return to List View button is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}		

			
		//Selecting Basic Txn tab			
		ArrayList<GuiTestObject> link_BasicTxnList = Util.getGWTMappedObjects("Html.A", ".text", "Basic Transaction");
		GuiTestObject link_BasicTxn = null;
		if(link_BasicTxnList.size()==0){
			System.out.println("Basic Transaction Tab returns nil in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Basic Transaction Tab returns nil in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		link_BasicTxn = link_BasicTxnList.get(link_BasicTxnList.size()-1);
		if(link_BasicTxn!= null){
			link_BasicTxn.waitForExistence(10, 2);
			link_BasicTxn.ensureObjectIsVisible();
			link_BasicTxn.click();
			sleep(2);
			
			//Searching Notes link in the View Transaction Details page	
			ArrayList<GuiTestObject> link_NotesList = Util.getGWTMappedObjects("Html.DIV", ".text", "Notes");
			GuiTestObject link_Notes = null;
			if(link_NotesList.size()==0){
				System.out.println("Notes link not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Notes link not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			System.out.println("Size: "+link_NotesList.size());
			for(int i=0;i<link_NotesList.size();i++){
				System.out.println("Id: "+link_NotesList.get(i).getProperty(".id").toString());
				if(link_NotesList.get(i).getProperty(".text").toString().equals("Notes")){
					link_Notes = (GuiTestObject)link_NotesList.get(i+1);
					System.out.println("ArrayList Position: "+(i+1));
					System.out.println("ObjId: "+link_Notes.getProperty(".id").toString());
					System.out.println("Text: "+link_Notes.getProperty(".text").toString());
//					link_Notes.click();
					break;
				}
				else{
					continue;
				}
			}
						
			if(link_Notes!= null){
				link_Notes.waitForExistence(10, 2);	
				System.out.println("Notes link is present in View Transaction Details Page");
			}
			else{
				System.out.println("Notes link is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Notes link is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Property Id text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_PropIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "entityID");
			TextGuiTestObject text_PropId = null;
			if(text_PropIdList.size()==0){
				System.out.println("Property Id not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Property Id not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_PropIdList.size();i++){
				System.out.println("Id: "+text_PropIdList.get(i).getProperty(".id").toString());			
			}
			text_PropId = (TextGuiTestObject)text_PropIdList.get(Math.round(text_PropIdList.size()/2));			
			if(text_PropId!= null){
				text_PropId.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_PropId.getProperty: "+text_PropId.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_PropId.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Property Id textbox is disabled in View Transaction Details Page");
				}
				else if(text_PropId.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Property Id");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Property Id textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Property Id textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Site Id text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_SiteIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "siteId");
			TextGuiTestObject text_SiteId = null;
			if(text_SiteIdList.size()==0){
				System.out.println("Site Id not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Site Id not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_SiteIdList.size();i++){
				System.out.println("Id: "+text_SiteIdList.get(i).getProperty(".id").toString());			
			}
			text_SiteId = (TextGuiTestObject)text_SiteIdList.get(Math.round(text_SiteIdList.size()/2));			
			if(text_SiteId!= null){
				text_SiteId.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_SiteId.getProperty: "+text_SiteId.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_SiteId.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Site Id textbox is disabled in View Transaction Details Page");
				}
				else if(text_SiteId.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Site Id");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Site Id textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Site Id textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Site Name text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_SiteNameList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "tidAlias");
			TextGuiTestObject text_SiteName = null;
			if(text_SiteNameList.size()==0){
				System.out.println("Site Name not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Site Name not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_SiteNameList.size();i++){
				System.out.println("Id: "+text_SiteNameList.get(i).getProperty(".id").toString());			
			}
			text_SiteName = (TextGuiTestObject)text_SiteNameList.get(Math.round(text_SiteNameList.size()/2));			
			if(text_SiteName!= null){
				text_SiteName.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_SiteName.getProperty: "+text_SiteName.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_SiteName.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Site Name textbox is disabled in View Transaction Details Page");
				}
				else if(text_SiteName.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Site Name");					
					sleep(1);
				}//End of Checking whether read only or not				
			}
			else{
				System.out.println("Site Name textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Site Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Merchant Batch Number text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_MerchantBatchNoList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "merchantBatchNumber");
			TextGuiTestObject text_MerchantBatchNo = null;
			if(text_MerchantBatchNoList.size()==0){
				System.out.println("Merchant Batch Number returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Merchant Batch Number returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_MerchantBatchNoList.size();i++){
				System.out.println("Id: "+text_MerchantBatchNoList.get(i).getProperty(".id").toString());			
			}
			text_MerchantBatchNo = (TextGuiTestObject)text_MerchantBatchNoList.get(Math.round(text_MerchantBatchNoList.size()/2));			
			if(text_MerchantBatchNo!= null){
				text_MerchantBatchNo.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_MerchantBatchNo.getProperty: "+text_MerchantBatchNo.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_MerchantBatchNo.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Merchant Batch Number textbox is disabled in View Transaction Details Page");					
				}
				else if(text_MerchantBatchNo.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Merchant Batch Number");					
					sleep(1);
				}//End of Checking whether readonly or not				
			}
			else{
				System.out.println("Merchant Batch Number textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Merchant Batch Number textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching System Batch No. text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_SysBatchIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "batchId");
			TextGuiTestObject text_SysBatchId = null;
			if(text_SysBatchIdList.size()==0){
				System.out.println("System Batch No. not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "System Batch No. not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_SysBatchIdList.size();i++){
				System.out.println("Id: "+text_SysBatchIdList.get(i).getProperty(".id").toString());			
			}
			text_SysBatchId = (TextGuiTestObject)text_SysBatchIdList.get(Math.round(text_SysBatchIdList.size()/2));			
			if(text_SysBatchId!= null){
				text_SysBatchId.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_SysBatchId.getProperty: "+text_SysBatchId.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_SysBatchId.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("System Batch No. textbox is disabled in View Transaction Details Page");
				}
				else if(text_SysBatchId.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside System Batch No.");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("System Batch No. textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "System Batch No. textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Date text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_DateList = Util.getGWTMappedObjects("Html.DIV", ".text", "Date");
			GuiTestObject text_Date = null;
			if(text_DateList.size()==0){
				System.out.println("Date not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Date not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			System.out.println("Size: "+text_DateList.size());
			for(int i=0;i<text_DateList.size();i++){
				System.out.println("Id: "+text_DateList.get(i).getProperty(".id").toString());
				if(text_DateList.get(i).getProperty(".text").toString().equals("Date")){
					text_Date = (GuiTestObject)text_DateList.get(i);
					System.out.println("Loop: "+i);
					System.out.println("ObjId: "+text_Date.getProperty(".id").toString());
					System.out.println("Text: "+text_Date.getProperty(".text").toString());
					break;
				}
				else{
					continue;
				}
			}
						
			if(text_Date!= null){
				text_Date.waitForExistence(10, 2);	
				noOfTextBoxBasicTxn++;
				System.out.println("Date textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Date textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Date textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Time text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TimeList = Util.getGWTMappedObjects("Html.DIV", ".text", "Time");
			GuiTestObject text_Time = null;
			if(text_TimeList.size()==0){
				System.out.println("Time not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Time not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			System.out.println("Size: "+text_TimeList.size());
			for(int i=0;i<text_TimeList.size();i++){
				System.out.println("Id: "+text_TimeList.get(i).getProperty(".id").toString());
				if(text_TimeList.get(i).getProperty(".text").toString().equals("Time")){
					text_Time = (GuiTestObject)text_TimeList.get(i);
					System.out.println("Loop: "+i);
					System.out.println("ObjId: "+text_Time.getProperty(".id").toString());
					System.out.println("Text: "+text_Time.getProperty(".text").toString());
					break;
				}
				else{
					continue;
				}
			}
						
			if(text_Time!= null){
				text_Time.waitForExistence(10, 2);	
				noOfTextBoxBasicTxn++;
				System.out.println("Time textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Time textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Time textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			
			//Searching Business Date text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_BzDateList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Business Date");
			GuiTestObject text_BzDate = null;
			if(text_BzDateList.size()==0){
				System.out.println("Business Date not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Business Date not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_BzDateList.size();i++){
				System.out.println("Text: "+text_BzDateList.get(i).getProperty(".text").toString());			
			}
			text_BzDate = (GuiTestObject)text_BzDateList.get(text_BzDateList.size()-1);			
			if(text_BzDate!= null){
				text_BzDate.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("Business Date textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Business Date textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Business Date textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Reference No. text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_RefNoList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "referenceNumber");
			TextGuiTestObject text_RefNo = null;
			if(text_RefNoList.size()==0){
				System.out.println("Reference No. not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Reference No. not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_RefNoList.size();i++){
				System.out.println("Id: "+text_RefNoList.get(i).getProperty(".id").toString());			
			}
			text_RefNo = (TextGuiTestObject)text_RefNoList.get(Math.round(text_RefNoList.size()/2));			
			if(text_RefNo!= null){
				text_RefNo.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_RefNo.getProperty: "+text_RefNo.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_RefNo.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Reference No. textbox is disabled in View Transaction Details Page");
				}
				else if(text_RefNo.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Reference No.");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Reference No. textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Reference No. textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Global User Field text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_GlobalUserFieldList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "globalUserField");
			TextGuiTestObject text_GlobalUserField = null;
			if(text_GlobalUserFieldList.size()==0){
				System.out.println("Global User Field not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Global User Field not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_GlobalUserFieldList.size();i++){
				System.out.println("Id: "+text_GlobalUserFieldList.get(i).getProperty(".id").toString());			
			}
			text_GlobalUserField = (TextGuiTestObject)text_GlobalUserFieldList.get(Math.round(text_GlobalUserFieldList.size()/2));			
			if(text_GlobalUserField!= null){
				text_GlobalUserField.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_GlobalUserField.getProperty: "+text_GlobalUserField.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_GlobalUserField.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Global User Field textbox is disabled in View Transaction Details Page");
				}
				else if(text_GlobalUserField.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Global User Field");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Global User Field textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Global User Field textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Card Type text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_CardTypeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "paymentType");
			TextGuiTestObject text_CardType = null;
			if(text_CardTypeList.size()==0){
				System.out.println("Card Type not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Card Type not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_CardTypeList.size();i++){
				System.out.println("Id: "+text_CardTypeList.get(i).getProperty(".id").toString());			
			}
			text_CardType = (TextGuiTestObject)text_CardTypeList.get(Math.round(text_CardTypeList.size()/2));			
			if(text_CardType!= null){
				text_CardType.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_CardType.getProperty: "+text_CardType.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_CardType.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Card Type textbox is disabled in View Transaction Details Page");
				}
				else if(text_CardType.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Card Type");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Card Type textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Card Type textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Card Name text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_CardNameList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "cardName");
			TextGuiTestObject text_CardName = null;
			if(text_CardNameList.size()==0){
				System.out.println("Card Name not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Card Name not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_CardNameList.size();i++){
				System.out.println("Id: "+text_CardNameList.get(i).getProperty(".id").toString());			
			}
			text_CardName = (TextGuiTestObject)text_CardNameList.get(Math.round(text_CardNameList.size()/2));			
			if(text_CardName!= null){
				text_CardName.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_CardName.getProperty: "+text_CardName.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_CardName.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Card Name textbox is disabled in View Transaction Details Page");
				}
				else if(text_CardName.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Card Name");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Card Name textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Card Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Account Number text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AcNoList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "accountNumber");
			TextGuiTestObject text_AcNo = null;
			if(text_AcNoList.size()==0){
				System.out.println("Account Number not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Account Number not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_AcNoList.size();i++){
				System.out.println("Id: "+text_AcNoList.get(i).getProperty(".id").toString());			
			}
			text_AcNo = (TextGuiTestObject)text_AcNoList.get(Math.round(text_AcNoList.size()/2));			
			if(text_AcNo!= null){
				text_AcNo.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_AcNo.getProperty: "+text_AcNo.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_AcNo.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Account Number textbox is disabled in View Transaction Details Page");
				}
				else if(text_AcNo.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Account Number");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Account Number textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Account Number textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Token Id text in the View Transaction Details page	
//			ArrayList<GuiTestObject> text_TokenIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "uniqueId");
//			TextGuiTestObject text_TokenId = null;
//			if(text_TokenIdList.size()==0){
//				System.out.println("Token Id not found in View Transaction Details Page");
//				error = true;
//				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Token Id not found in View Transaction Details Page", Status.BC_FAILED);
//				return;
//			}
//			for(int i=0;i<text_TokenIdList.size();i++){
//				System.out.println("Id: "+text_TokenIdList.get(i).getProperty(".id").toString());			
//			}
//			text_TokenId = (TextGuiTestObject)text_TokenIdList.get(Math.round(text_TokenIdList.size()/2));			
//			if(text_TokenId!= null){
//				text_TokenId.waitForExistence(10, 2);
//				noOfTextBoxBasicTxn++;
//				System.out.println("text_TokenId.getProperty: "+text_TokenId.getProperty(".readOnly").toString());
//				//Checking whether read only or not
//				if(text_TokenId.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
//					System.out.println("Token Id textbox is disabled in View Transaction Details Page");
//				}
//				else if(text_TokenId.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
//					System.out.println("Inside Token Id");					
//					sleep(1);
//				}//End of Checking whether read-only or not				
//			}
//			else{
//				System.out.println("Token Id textbox is absent in View Transaction Details Page");
//				error = true;
//				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Token Id textbox is absent in View Transaction Details Page", Status.BC_FAILED);
//				return;
//			}
			
			//Searching Exp Date text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ExpDateList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "expirationDate");
			TextGuiTestObject text_ExpDate = null;
			if(text_ExpDateList.size()==0){
				System.out.println("Exp Date not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Exp Date not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_ExpDateList.size();i++){
				System.out.println("Id: "+text_ExpDateList.get(i).getProperty(".id").toString());			
			}
			text_ExpDate = (TextGuiTestObject)text_ExpDateList.get(Math.round(text_ExpDateList.size()/2));			
			if(text_ExpDate!= null){
				text_ExpDate.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_ExpDate.getProperty: "+text_ExpDate.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_ExpDate.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Exp Date textbox is disabled in View Transaction Details Page");
				}
				else if(text_ExpDate.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Exp Date");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Exp Date textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Exp Date textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Error Code text in the View Transaction Details page	
//			ArrayList<GuiTestObject> text_ErrorCodeList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Error Code");
//			GuiTestObject text_ErrorCode = null;
//			if(text_ErrorCodeList.size()==0){
//				System.out.println("Error Code not found in View Transaction Details Page");
//				error = true;
//				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Error Code not found in View Transaction Details Page", Status.BC_FAILED);
//				return;
//			}
//			for(int i=0;i<text_ErrorCodeList.size();i++){
//				System.out.println("Text: "+text_ErrorCodeList.get(i).getProperty(".text").toString());			
//			}
//			text_ErrorCode = (GuiTestObject)text_ErrorCodeList.get(text_ErrorCodeList.size()-1);			
//			if(text_ErrorCode!= null){
//				text_ErrorCode.waitForExistence(10, 2);	
//				noOfTextBoxBasicTxn++;
//				System.out.println("Error Code textbox is present in View Transaction Details Page");
//			}
//			else{
//				System.out.println("Error Code textbox is absent in View Transaction Details Page");
//				error = true;
//				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Error Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
//				return;
//			}
			
			
			//Searching Transaction Type text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TranTypeList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Tran Type");
			GuiTestObject text_TranType = null;
			if(text_TranTypeList.size()==0){
				System.out.println("Transaction Type not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Type not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_TranTypeList.size();i++){
				System.out.println("Text: "+text_TranTypeList.get(i).getProperty(".text").toString());			
			}
			text_TranType = (GuiTestObject)text_TranTypeList.get(text_TranTypeList.size()-1);			
			if(text_TranType!= null){
				text_TranType.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("Transaction Type textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Transaction Type textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Type textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Transaction Amount text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TxnAmtList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "transactionAmount");
			TextGuiTestObject text_TxnAmt = null;
			if(text_TxnAmtList.size()==0){
				System.out.println("Transaction Amount nto found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Amount not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_TxnAmtList.size();i++){
				System.out.println("Id: "+text_TxnAmtList.get(i).getProperty(".id").toString());			
			}
			text_TxnAmt = (TextGuiTestObject)text_TxnAmtList.get(Math.round(text_TxnAmtList.size()/2));			
			if(text_TxnAmt!= null){
				text_TxnAmt.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_TxnAmt.getProperty: "+text_TxnAmt.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_TxnAmt.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Transaction Amount textbox is disabled in View Transaction Details Page");
				}
				else if(text_TxnAmt.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Txn Amount");					
					sleep(1);
				}//End of Checking whether read only or not				
			}
			else{
				System.out.println("Transaction Amount textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Amount textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Settled Currency text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_SettledCurrList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "settlementCurrency");
			TextGuiTestObject text_SettledCurr = null;
			if(text_SettledCurrList.size()==0){
				System.out.println("Settled Currency not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Settled Currency not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_SettledCurrList.size();i++){
				System.out.println("Id: "+text_SettledCurrList.get(i).getProperty(".id").toString());			
			}
			text_SettledCurr = (TextGuiTestObject)text_SettledCurrList.get(Math.round(text_SettledCurrList.size()/2));			
			if(text_SettledCurr!= null){
				text_SettledCurr.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_SettledCurr.getProperty: "+text_SettledCurr.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_SettledCurr.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Settled Currency textbox is disabled in View Transaction Details Page");
				}
				else if(text_SettledCurr.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Settled Currency");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Settled Currency textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Settled Currency textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching AuthCode text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AuthCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "authorizationCode");
			TextGuiTestObject text_AuthCode = null;
			if(text_AuthCodeList.size()==0){
				System.out.println("AuthCode not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "AuthCode not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_AuthCodeList.size();i++){
				System.out.println("Id: "+text_AuthCodeList.get(i).getProperty(".id").toString());			
			}
			text_AuthCode = (TextGuiTestObject)text_AuthCodeList.get(Math.round(text_AuthCodeList.size()/2));			
			if(text_AuthCode!= null){
				text_AuthCode.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_AuthCode.getProperty: "+text_AuthCode.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_AuthCode.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("AuthCode textbox is disabled in View Transaction Details Page");
				}
				else if(text_AuthCode.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside AuthCode");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("AuthCode textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "AuthCode textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Entry Mode text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_EntryModeList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Entry Mode");
			GuiTestObject text_EntryMode = null;
			if(text_EntryModeList.size()==0){
				System.out.println("Entry Mode not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Entry Mode not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_EntryModeList.size();i++){
				System.out.println("Text: "+text_EntryModeList.get(i).getProperty(".text").toString());			
			}
			text_EntryMode = (GuiTestObject)text_EntryModeList.get(text_EntryModeList.size()-1);			
			if(text_EntryMode!= null){
				text_EntryMode.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("Entry Mode textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Entry Mode textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Entry Mode textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Online Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_OnlineIndicatorList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Online Indicator");
			GuiTestObject text_OnlineIndicator = null;
			if(text_OnlineIndicatorList.size()==0){
				System.out.println("Online Indicator not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Online Indicator not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_OnlineIndicatorList.size();i++){
				System.out.println("Text: "+text_OnlineIndicatorList.get(i).getProperty(".text").toString());			
			}
			text_OnlineIndicator = (GuiTestObject)text_OnlineIndicatorList.get(text_OnlineIndicatorList.size()-1);			
			if(text_OnlineIndicator!= null){
				text_OnlineIndicator.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("Online Indicator textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Online Indicator textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Online Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Card-holder Name text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_CardholderNameList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "cardholderName");
			TextGuiTestObject text_CardholderName = null;
			if(text_CardholderNameList.size()==0){
				System.out.println("Cardholder Name not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Cardholder Name not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_CardholderNameList.size();i++){
				System.out.println("Id: "+text_CardholderNameList.get(i).getProperty(".id").toString());			
			}
			text_CardholderName = (TextGuiTestObject)text_CardholderNameList.get(Math.round(text_CardholderNameList.size()/2));			
			if(text_CardholderName!= null){
				text_CardholderName.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_CardholderName.getProperty: "+text_CardholderName.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_CardholderName.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Cardholder Name textbox is disabled in View Transaction Details Page");
				}
				else if(text_CardholderName.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Cardholder Name");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Cardholder Name textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Cardholder Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Transaction Status text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TxnStatusList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "statusInternalLabel");
			TextGuiTestObject text_TxnStatus = null;
			if(text_TxnStatusList.size()==0){
				System.out.println("Transaction Status not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Status not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_TxnStatusList.size();i++){
				System.out.println("Id: "+text_TxnStatusList.get(i).getProperty(".id").toString());			
			}
			text_TxnStatus = (TextGuiTestObject)text_TxnStatusList.get(Math.round(text_TxnStatusList.size()/2));			
			if(text_TxnStatus!= null){
				text_TxnStatus.waitForExistence(10, 2);
				noOfTextBoxBasicTxn++;
				System.out.println("text_TxnStatus.getProperty: "+text_TxnStatus.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_TxnStatus.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Transaction Status textbox is disabled in View Transaction Details Page");
				}
				else if(text_TxnStatus.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Transaction Status");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Transaction Status textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Status textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}	
			
		}//End of if for basic Txn tab selection
		else{
			System.out.println("Basic Transaction Tab is absent in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Basic Transaction Tab is absent in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		//End of Selecting Basic Txn tab
		
		//Selecting Expanded Detail tab	
		ArrayList<GuiTestObject> link_ExpandDetList = Util.getGWTMappedObjects("Html.A", ".text", "Expanded Detail");
		GuiTestObject link_ExpandDet = null;
		if(link_ExpandDetList.size()==0){
			System.out.println("Expanded Detail Tab returns nil in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Expanded Detail Tab returns nil in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		link_ExpandDet = link_ExpandDetList.get(link_ExpandDetList.size()-1);		
		if(link_ExpandDet!= null){
			link_ExpandDet.waitForExistence(10, 2);
			link_ExpandDet.ensureObjectIsVisible();
			link_ExpandDet.click();
			sleep(5);
			
			//Searching Notes link in the View Transaction Details page	
			ArrayList<GuiTestObject> link_NotesList = Util.getGWTMappedObjects("Html.DIV", ".text", "Notes");
			GuiTestObject link_Notes = null;
			if(link_NotesList.size()==0){
				System.out.println("Notes link not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Notes link not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			System.out.println("Size: "+link_NotesList.size());
			for(int i=0;i<link_NotesList.size();i++){
				System.out.println("Id: "+link_NotesList.get(i).getProperty(".id").toString());
				if(link_NotesList.get(i).getProperty(".text").toString().equals("Notes")){
					link_Notes = (GuiTestObject)link_NotesList.get(i+1);
					System.out.println("ArrayList Position: "+(i+1));
					System.out.println("ObjId: "+link_Notes.getProperty(".id").toString());
					System.out.println("Text: "+link_Notes.getProperty(".text").toString());
//					link_Notes.click();
					break;
				}
				else{
					continue;
				}
			}
						
			if(link_Notes!= null){
				link_Notes.waitForExistence(10, 2);	
				System.out.println("Notes link is present in View Transaction Details Page");
			}
			else{
				System.out.println("Notes link is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Notes link is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Message Set text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_MsgSetList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "messageSet");
			TextGuiTestObject text_MsgSet = null;
			if(text_MsgSetList.size()==0){
				System.out.println("Message Set not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Message Set not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_MsgSetList.size();i++){
				System.out.println("Id: "+text_MsgSetList.get(i).getProperty(".id").toString());			
			}
			text_MsgSet = (TextGuiTestObject)text_MsgSetList.get(Math.round(text_MsgSetList.size()/2));			
			if(text_MsgSet!= null){
				text_MsgSet.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_MsgSet.getProperty: "+text_MsgSet.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_MsgSet.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Message Set textbox is disabled in View Transaction Details Page");
				}
				else if(text_MsgSet.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Message Set");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Message Set textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Message Set textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Employee Id text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_EmpIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "employeeId");
			TextGuiTestObject text_EmpId = null;
			if(text_EmpIdList.size()==0){
				System.out.println("Employee Id not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Employee Id not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_EmpIdList.size();i++){
				System.out.println("Id: "+text_EmpIdList.get(i).getProperty(".id").toString());			
			}
			text_EmpId = (TextGuiTestObject)text_EmpIdList.get(Math.round(text_EmpIdList.size()/2));			
			if(text_EmpId!= null){
				text_EmpId.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_EmpId.getProperty: "+text_EmpId.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_EmpId.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Employee Id textbox is disabled in View Transaction Details Page");
				}
				else if(text_EmpId.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Employee Id");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Employee Id textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Employee Id textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Tax Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TaxIndicatorList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Tax Indicator");
			GuiTestObject text_TaxIndicator = null;
			if(text_TaxIndicatorList.size()==0){
				System.out.println("Tax Indicator not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Tax Indicator not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_TaxIndicatorList.size();i++){
				System.out.println("Text: "+text_TaxIndicatorList.get(i).getProperty(".text").toString());			
			}
			text_TaxIndicator = (GuiTestObject)text_TaxIndicatorList.get(text_TaxIndicatorList.size()-1);			
			if(text_TaxIndicator!= null){
				text_TaxIndicator.waitForExistence(10, 2);	
				noOfTextBoxExpandedDetails++;
				System.out.println("Tax Indicator textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Tax Indicator textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Tax Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}	
			
			//Searching Tax Amount text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TaxAmtList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "tax1Amount");
			TextGuiTestObject text_TaxAmt = null;
			if(text_TaxAmtList.size()==0){
				System.out.println("Tax Amount not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Tax Amount not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_TaxAmtList.size();i++){
				System.out.println("Id: "+text_TaxAmtList.get(i).getProperty(".id").toString());			
			}
			text_TaxAmt = (TextGuiTestObject)text_TaxAmtList.get(Math.round(text_TaxAmtList.size()/2));			
			if(text_TaxAmt!= null){
				text_TaxAmt.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_TaxAmt.getProperty: "+text_TaxAmt.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_TaxAmt.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Tax Amount textbox is disabled in View Transaction Details Page");
				}
				else if(text_TaxAmt.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Tax Amount");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Tax Amount textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Tax Amount textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Customer Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_CustCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "customerCode");
			TextGuiTestObject text_CustCode = null;
			if(text_CustCodeList.size()==0){
				System.out.println("Customer Code not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Customer Code not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_CustCodeList.size();i++){
				System.out.println("Id: "+text_CustCodeList.get(i).getProperty(".id").toString());			
			}
			text_CustCode = (TextGuiTestObject)text_CustCodeList.get(Math.round(text_CustCodeList.size()/2));			
			if(text_CustCode!= null){
				text_CustCode.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_CustCode.getProperty: "+text_CustCode.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_CustCode.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Customer Code textbox is disabled in View Transaction Details Page");
				}
				else if(text_CustCode.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Customer Code");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Customer Code textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Customer Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching DCC Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_DCCIndicatorList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "dccIndicator");
			TextGuiTestObject text_DCCIndicator = null;
			if(text_DCCIndicatorList.size()==0){
				System.out.println("DCC Indicator not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "DCC Indicator not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_DCCIndicatorList.size();i++){
				System.out.println("Id: "+text_DCCIndicatorList.get(i).getProperty(".id").toString());			
			}
			text_DCCIndicator = (TextGuiTestObject)text_DCCIndicatorList.get(Math.round(text_DCCIndicatorList.size()/2));			
			if(text_DCCIndicator!= null){
				text_DCCIndicator.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_DCCIndicator.getProperty: "+text_DCCIndicator.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_DCCIndicator.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("DCC Indicator textbox is disabled in View Transaction Details Page");
				}
				else if(text_DCCIndicator.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside DCC Indicator");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("DCC Indicator textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "DCC Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Conversion Date text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ConvDateList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Conversion Date");
			GuiTestObject text_ConvDate = null;
			if(text_ConvDateList.size()==0){
				System.out.println("Conversion Date not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Conversion Date not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_ConvDateList.size();i++){
				System.out.println("Text: "+text_ConvDateList.get(i).getProperty(".text").toString());			
			}
			text_ConvDate = (GuiTestObject)text_ConvDateList.get(text_ConvDateList.size()-1);			
			if(text_ConvDate!= null){
				text_ConvDate.waitForExistence(10, 2);	
				noOfTextBoxExpandedDetails++;
				System.out.println("Conversion Date textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Conversion Date textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Conversion Date textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Conversion Time text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ConvTimeList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Conversion Time");
			GuiTestObject text_ConvTime = null;
			if(text_ConvTimeList.size()==0){
				System.out.println("Conversion Time not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Conversion Time not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_ConvTimeList.size();i++){
				System.out.println("Text: "+text_ConvTimeList.get(i).getProperty(".text").toString());			
			}
			text_ConvTime = (GuiTestObject)text_ConvTimeList.get(text_ConvTimeList.size()-1);			
			if(text_ConvTime!= null){
				text_ConvTime.waitForExistence(10, 2);	
				noOfTextBoxExpandedDetails++;
				System.out.println("Conversion Time textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Conversion Time textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Conversion Time textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Funded Currency text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_FundedCurrList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "transactionDCCInfo.merchantCurrency");
			TextGuiTestObject text_FundedCurr = null;
			if(text_FundedCurrList.size()==0){
				System.out.println("Funded Currency not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Funded Currency not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_FundedCurrList.size();i++){
				System.out.println("Id: "+text_FundedCurrList.get(i).getProperty(".id").toString());			
			}
			text_FundedCurr = (TextGuiTestObject)text_FundedCurrList.get(Math.round(text_FundedCurrList.size()/2));			
			if(text_FundedCurr!= null){
				text_FundedCurr.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_FundedCurr.getProperty: "+text_FundedCurr.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_FundedCurr.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Funded Currency textbox is disabled in View Transaction Details Page");
				}
				else if(text_FundedCurr.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Funded Currency");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Funded Currency textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Funded Currency textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Auth Currency text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AuthCurrList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "transactionDCCInfo.authCurrency");
			TextGuiTestObject text_AuthCurr = null;
			if(text_AuthCurrList.size()==0){
				System.out.println("Auth Currency not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Auth Currency not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_AuthCurrList.size();i++){
				System.out.println("Id: "+text_AuthCurrList.get(i).getProperty(".id").toString());			
			}
			text_AuthCurr = (TextGuiTestObject)text_AuthCurrList.get(Math.round(text_AuthCurrList.size()/2));			
			if(text_AuthCurr!= null){
				text_AuthCurr.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_AuthCurr.getProperty: "+text_AuthCurr.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_AuthCurr.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Auth Currency textbox is disabled in View Transaction Details Page");
				}
				else if(text_AuthCurr.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Auth Currency");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Auth Currency textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Auth Currency textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Original Auth Amount text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_OrigAuthAmntList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "origAuthAmount");
			TextGuiTestObject text_OrigAuthAmnt = null;
			if(text_OrigAuthAmntList.size()==0){
				System.out.println("Original Auth Amount not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Original Auth Amount not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_OrigAuthAmntList.size();i++){
				System.out.println("Id: "+text_OrigAuthAmntList.get(i).getProperty(".id").toString());			
			}
			text_OrigAuthAmnt = (TextGuiTestObject)text_OrigAuthAmntList.get(Math.round(text_OrigAuthAmntList.size()/2));			
			if(text_OrigAuthAmnt!= null){
				text_OrigAuthAmnt.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_OrigAuthAmnt.getProperty: "+text_OrigAuthAmnt.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_OrigAuthAmnt.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Original Auth Amount textbox is disabled in View Transaction Details Page");
				}
				else if(text_OrigAuthAmnt.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Original Auth Amount");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Original Auth Amount textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Original Auth Amount textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Converted Amount text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ConvrtAmntList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "transactionDCCInfo.convertedAmount");
			TextGuiTestObject text_ConvrtAmnt = null;
			if(text_ConvrtAmntList.size()==0){
				System.out.println("Converted Amount not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Converted Amount not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_ConvrtAmntList.size();i++){
				System.out.println("Id: "+text_ConvrtAmntList.get(i).getProperty(".id").toString());			
			}
			text_ConvrtAmnt = (TextGuiTestObject)text_ConvrtAmntList.get(Math.round(text_ConvrtAmntList.size()/2));			
			if(text_ConvrtAmnt!= null){
				text_ConvrtAmnt.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_ConvrtAmnt.getProperty: "+text_ConvrtAmnt.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_ConvrtAmnt.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Converted Amount textbox is disabled in View Transaction Details Page");
				}
				else if(text_ConvrtAmnt.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Converted Amount");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Converted Amount textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Converted Amount textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Exchange Rate text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ExchngRateList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "transactionDCCInfo.exchangeRate");
			TextGuiTestObject text_ExchngRate = null;
			if(text_ExchngRateList.size()==0){
				System.out.println("Exchange Rate not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Exchange Rate not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_ExchngRateList.size();i++){
				System.out.println("Id: "+text_ExchngRateList.get(i).getProperty(".id").toString());			
			}
			text_ExchngRate = (TextGuiTestObject)text_ExchngRateList.get(Math.round(text_ExchngRateList.size()/2));			
			if(text_ExchngRate!= null){
				text_ExchngRate.waitForExistence(10, 2);
				noOfTextBoxExpandedDetails++;
				System.out.println("text_ExchngRate.getProperty: "+text_ExchngRate.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_ExchngRate.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Exchange Rate textbox is disabled in View Transaction Details Page");
				}
				else if(text_ExchngRate.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Exchange Rate");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Exchange Rate textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Exchange Rate textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			
		}//End of if for expanded detail tab
		else{
			System.out.println("Expanded Detail Tab is absent in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Expanded Detail Tab is absent in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		//End of Selecting Expanded Detail tab
		
		
		
		//Selecting Customer tab
		ArrayList<GuiTestObject> link_CustomerList = Util.getGWTMappedObjects("Html.A", ".text", "Customer");
		GuiTestObject link_Customer = null;
		if(link_CustomerList.size()==0){
			System.out.println("Customer Tab returns nil in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Customer Tab returns nil in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		link_Customer = link_CustomerList.get(link_CustomerList.size()-1);		
		if(link_Customer!= null){
			link_Customer.waitForExistence(10, 2);
			link_Customer.ensureObjectIsVisible();
			link_Customer.click();
			sleep(5);
			
			//Searching Notes link in the View Transaction Details page	
			ArrayList<GuiTestObject> link_NotesList = Util.getGWTMappedObjects("Html.DIV", ".text", "Notes");
			GuiTestObject link_Notes = null;
			if(link_NotesList.size()==0){
				System.out.println("Notes link not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Notes link not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			System.out.println("Size: "+link_NotesList.size());
			for(int i=0;i<link_NotesList.size();i++){
				System.out.println("Id: "+link_NotesList.get(i).getProperty(".id").toString());
				if(link_NotesList.get(i).getProperty(".text").toString().equals("Notes")){
					link_Notes = (GuiTestObject)link_NotesList.get(i+1);
					System.out.println("ArrayList Position: "+(i+1));
					System.out.println("ObjId: "+link_Notes.getProperty(".id").toString());
					System.out.println("Text: "+link_Notes.getProperty(".text").toString());
//					link_Notes.click();
					break;
				}
				else{
					continue;
				}
			}
						
			if(link_Notes!= null){
				link_Notes.waitForExistence(10, 2);	
				System.out.println("Notes link is present in View Transaction Details Page");
			}
			else{
				System.out.println("Notes link is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Notes link is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching First Name text in the View Transaction Details page
			ArrayList<GuiTestObject> text_fNameList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "addressVerification.firstName");
			TextGuiTestObject text_fName = null;
			if(text_fNameList.size()==0){
				System.out.println("First Name returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "First Name returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_fNameList.size();i++){
				System.out.println("Id: "+text_fNameList.get(i).getProperty(".id").toString());			
			}
			text_fName = (TextGuiTestObject)text_fNameList.get(Math.round(text_fNameList.size()/2));			
			if(text_fName!= null){
				text_fName.waitForExistence(10, 2);
				noOfTextBoxCustomer++;
				System.out.println("text_fName.getProperty: "+text_fName.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_fName.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("First Name textbox is disabled in View Transaction Details Page");					
				}
				else if(text_fName.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside First Name");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("First Name textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "First Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Last Name text in the View Transaction Details page
			ArrayList<GuiTestObject> text_lNameList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "addressVerification.lastName");
			TextGuiTestObject text_lName = null;
			if(text_lNameList.size()==0){
				System.out.println("Last Name returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Last Name returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_lNameList.size();i++){
				System.out.println("Id: "+text_lNameList.get(i).getProperty(".id").toString());			
			}
			text_lName = (TextGuiTestObject)text_lNameList.get(Math.round(text_lNameList.size()/2));			
			if(text_lName!= null){
				text_lName.waitForExistence(10, 2);
				noOfTextBoxCustomer++;
				System.out.println("text_lName.getProperty: "+text_lName.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_lName.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Last Name textbox is disabled in View Transaction Details Page");					
				}
				else if(text_lName.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Last Name");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Last Name textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Last Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Street Address text in the View Transaction Details page
			ArrayList<GuiTestObject> text_streetNameList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "addressVerification.streetName");
			TextGuiTestObject text_streetName = null;
			if(text_streetNameList.size()==0){
				System.out.println("Street Address returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Street Address returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_streetNameList.size();i++){
				System.out.println("Id: "+text_streetNameList.get(i).getProperty(".id").toString());			
			}
			text_streetName = (TextGuiTestObject)text_streetNameList.get(Math.round(text_streetNameList.size()/2));			
			if(text_streetName!= null){
				text_streetName.waitForExistence(10, 2);
				noOfTextBoxCustomer++;
				System.out.println("text_streetName.getProperty: "+text_streetName.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_streetName.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Street Address textbox is disabled in View Transaction Details Page");					
				}
				else if(text_streetName.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Street Address");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Street Address textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Street Address textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching City text in the View Transaction Details page
			ArrayList<GuiTestObject> text_cityList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "addressVerification.city");
			TextGuiTestObject text_city = null;
			if(text_cityList.size()==0){
				System.out.println("City returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "City returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_cityList.size();i++){
				System.out.println("Id: "+text_cityList.get(i).getProperty(".id").toString());			
			}
			text_city = (TextGuiTestObject)text_cityList.get(Math.round(text_cityList.size()/2));			
			if(text_city!= null){
				text_city.waitForExistence(10, 2);
				noOfTextBoxCustomer++;
				System.out.println("text_city.getProperty: "+text_city.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_city.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("City textbox is disabled in View Transaction Details Page");					
				}
				else if(text_city.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside City");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("City textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "City textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}	
			
			//Searching State Code text in the View Transaction Details page
			ArrayList<GuiTestObject> text_stateCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "addressVerification.stateCode");
			TextGuiTestObject text_stateCode = null;
			if(text_stateCodeList.size()==0){
				System.out.println("State Code returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "State Code returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_stateCodeList.size();i++){
				System.out.println("Id: "+text_stateCodeList.get(i).getProperty(".id").toString());			
			}
			text_stateCode = (TextGuiTestObject)text_stateCodeList.get(Math.round(text_stateCodeList.size()/2));			
			if(text_stateCode!= null){
				text_stateCode.waitForExistence(10, 2);
				noOfTextBoxCustomer++;
				System.out.println("text_stateCode.getProperty: "+text_stateCode.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_stateCode.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("State Code textbox is disabled in View Transaction Details Page");					
				}
				else if(text_stateCode.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside State Code");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("State Code textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "State Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Zip Code text in the View Transaction Details page
			ArrayList<GuiTestObject> text_zipCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "addressVerification.zipCode");
			TextGuiTestObject text_zipCode = null;
			if(text_zipCodeList.size()==0){
				System.out.println("Zip Code returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Zip Code returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_zipCodeList.size();i++){
				System.out.println("Id: "+text_zipCodeList.get(i).getProperty(".id").toString());			
			}
			text_zipCode = (TextGuiTestObject)text_zipCodeList.get(Math.round(text_zipCodeList.size()/2));			
			if(text_zipCode!= null){
				text_zipCode.waitForExistence(10, 2);
				noOfTextBoxCustomer++;
				System.out.println("text_zipCode.getProperty: "+text_zipCode.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_zipCode.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Zip Code textbox is disabled in View Transaction Details Page");					
				}
				else if(text_zipCode.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Zip Code");					
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Zip Code textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Zip Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}			
			
		}//End of Customer tab
		else{
			System.out.println("Customer Tab is absent in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Customer Tab is absent in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		//End of Selecting Customer tab
		
		//Selecting Compliance tab	
		ArrayList<GuiTestObject> link_ComplianceList = Util.getGWTMappedObjects("Html.A", ".text", "Compliance");
		GuiTestObject link_Compliance = null;
		if(link_ComplianceList.size()==0){
			System.out.println("Compliance Tab returns nil in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Compliance Tab returns nil in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		link_Compliance = link_ComplianceList.get(link_ComplianceList.size()-1);		
		if(link_Compliance!= null){
			link_Compliance.waitForExistence(10, 2);
			link_Compliance.ensureObjectIsVisible();
			link_Compliance.click();
			sleep(5);
			
			//Searching Notes link in the View Transaction Details page	
			ArrayList<GuiTestObject> link_NotesList = Util.getGWTMappedObjects("Html.DIV", ".text", "Notes");
			GuiTestObject link_Notes = null;
			if(link_NotesList.size()==0){
				System.out.println("Notes link not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Notes link not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			System.out.println("Size: "+link_NotesList.size());
			for(int i=0;i<link_NotesList.size();i++){
				System.out.println("Id: "+link_NotesList.get(i).getProperty(".id").toString());
				if(link_NotesList.get(i).getProperty(".text").toString().equals("Notes")){
					link_Notes = (GuiTestObject)link_NotesList.get(i+1);
					System.out.println("ArrayList Position: "+(i+1));
					System.out.println("ObjId: "+link_Notes.getProperty(".id").toString());
					System.out.println("Text: "+link_Notes.getProperty(".text").toString());
//					link_Notes.click();
					break;
				}
				else{
					continue;
				}
			}
						
			if(link_Notes!= null){
				link_Notes.waitForExistence(10, 2);	
				System.out.println("Notes link is present in View Transaction Details Page");
			}
			else{
				System.out.println("Notes link is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Notes link is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching TPP Response Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TPPResponseCodeList = Util.getGWTMappedObjects("Html.LABEL", ".text", "TPP Response Code");
			GuiTestObject text_TPPResponseCode = null;
			if(text_TPPResponseCodeList.size()==0){
				System.out.println("TPP Response Code not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "TPP Response Code not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_TPPResponseCodeList.size();i++){
				System.out.println("Text: "+text_TPPResponseCodeList.get(i).getProperty(".text").toString());			
			}
			text_TPPResponseCode = (GuiTestObject)text_TPPResponseCodeList.get(text_TPPResponseCodeList.size()-1);			
			if(text_TPPResponseCode!= null){
				text_TPPResponseCode.waitForExistence(10, 2);	
				noOfTextBoxCompliance++;
				System.out.println("TPP Response Code textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("TPP Response Code textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "TPP Response Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Error Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ErrorCodeList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Error Code");
			GuiTestObject text_ErrorCode = null;
			if(text_ErrorCodeList.size()==0){
				System.out.println("Error Code not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Error Code not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_ErrorCodeList.size();i++){
				System.out.println("Text: "+text_ErrorCodeList.get(i).getProperty(".text").toString());			
			}
			text_ErrorCode = (GuiTestObject)text_ErrorCodeList.get(text_ErrorCodeList.size()-1);			
			if(text_ErrorCode!= null){
				text_ErrorCode.waitForExistence(10, 2);	
				noOfTextBoxCompliance++;
				System.out.println("Error Code textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Error Code textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Error Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Reply Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ReplyCodeList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Reply Code");
			GuiTestObject text_ReplyCode = null;
			if(text_ReplyCodeList.size()==0){
				System.out.println("Reply Code not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Reply Code not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_ReplyCodeList.size();i++){
				System.out.println("Text: "+text_ReplyCodeList.get(i).getProperty(".text").toString());			
			}
			text_ReplyCode = (GuiTestObject)text_ReplyCodeList.get(text_ReplyCodeList.size()-1);			
			if(text_ReplyCode!= null){
				text_ReplyCode.waitForExistence(10, 2);	
				noOfTextBoxCompliance++;
				System.out.println("Reply Code textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Reply Code textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Reply Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			//Selecting Authorizer text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AuthorizerList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "authorizer");
			System.out.println("text_AuthorizerList Size: "+text_AuthorizerList.size());
			TextGuiTestObject text_Authorizer = null;
			if(text_AuthorizerList.size()==0){
				System.out.println("Authorizer returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Authorizer returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_AuthorizerList.size()==1){
				for(int i=0;i<text_AuthorizerList.size();i++){
					System.out.println("Id: "+text_AuthorizerList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthorizerList.get(i).getProperty(".value").toString());
				}
				text_Authorizer = (TextGuiTestObject)text_AuthorizerList.get(text_AuthorizerList.size()-1);			
				if(text_Authorizer!= null){
					text_Authorizer.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_Authorizer.getProperty: "+text_Authorizer.getProperty(".value").toString().trim());
					System.out.println("Got Authorizer on text_AuthorizerList.size()-1");					
				}
				else{
					System.out.println("Authorizer textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Authorizer textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_AuthorizerList.size();i++){
					System.out.println("Id: "+text_AuthorizerList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthorizerList.get(i).getProperty(".value").toString());
				}
				text_Authorizer = (TextGuiTestObject)text_AuthorizerList.get(Math.round(text_AuthorizerList.size()/2)-1);			
				if(text_Authorizer!= null){
					text_Authorizer.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_Authorizer.getProperty: "+text_Authorizer.getProperty(".value").toString().trim());
					System.out.println("Got Authorizer on (text_AuthorizerList.size()/2)-1");
										
				}
				else{
					System.out.println("Authorizer textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Authorizer textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting Transaction Id text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TxnIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "transactionId");
			System.out.println("text_TxnIdList Size: "+text_TxnIdList.size());
			TextGuiTestObject text_TxnId = null;
			if(text_TxnIdList.size()==0){
				System.out.println("Transaction Id returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Id returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_TxnIdList.size()==1){
				for(int i=0;i<text_TxnIdList.size();i++){
					System.out.println("Id: "+text_TxnIdList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_TxnIdList.get(i).getProperty(".value").toString());
				}
				text_TxnId = (TextGuiTestObject)text_TxnIdList.get(text_TxnIdList.size()-1);			
				if(text_TxnId!= null){
					text_TxnId.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_TxnId.getProperty: "+text_TxnId.getProperty(".value").toString().trim());
					txnId = text_TxnId.getProperty(".value").toString().trim();					
				}
				else{
					System.out.println("Transaction Id textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction Id textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_TxnIdList.size();i++){
					System.out.println("Id: "+text_TxnIdList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_TxnIdList.get(i).getProperty(".value").toString());
				}
				text_TxnId = (TextGuiTestObject)text_TxnIdList.get(Math.round(text_TxnIdList.size()/2)-1);			
				if(text_TxnId!= null){
					text_TxnId.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_TxnId.getProperty: "+text_TxnId.getProperty(".value").toString().trim());
					txnId = text_TxnId.getProperty(".value").toString().trim();					
				}
				else{
					System.out.println("Transaction Id textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction Id textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}			
			
			//Selecting Validation Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ValidationCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "validationCode");
			System.out.println("text_ValidationCodeList Size: "+text_ValidationCodeList.size());
			TextGuiTestObject text_ValidationCode = null;
			if(text_ValidationCodeList.size()==0){
				System.out.println("Validation Code returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Validation Code returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_ValidationCodeList.size()==1){
				for(int i=0;i<text_ValidationCodeList.size();i++){
					System.out.println("Id: "+text_ValidationCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_ValidationCodeList.get(i).getProperty(".value").toString());
				}
				text_ValidationCode = (TextGuiTestObject)text_ValidationCodeList.get(text_ValidationCodeList.size()-1);			
				if(text_ValidationCode!= null){
					text_ValidationCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_ValidationCode.getProperty: "+text_ValidationCode.getProperty(".value").toString().trim());
					System.out.println("Got Validation Code on text_ValidationCodeList.size()-1");					
				}
				else{
					System.out.println("Validation Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Validation Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_ValidationCodeList.size();i++){
					System.out.println("Id: "+text_ValidationCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_ValidationCodeList.get(i).getProperty(".value").toString());
				}
				text_ValidationCode = (TextGuiTestObject)text_ValidationCodeList.get(Math.round(text_ValidationCodeList.size()/2)-1);			
				if(text_ValidationCode!= null){
					text_ValidationCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_ValidationCode.getProperty: "+text_ValidationCode.getProperty(".value").toString().trim());
					System.out.println("Got Validation Code on (text_ValidationCodeList.size()/2)-1");
										
				}
				else{
					System.out.println("Validation Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Validation Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}	
			
			//Selecting ACI text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ACIIndicatorList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "aciIndicator");
			System.out.println("text_ACIIndicatorList Size: "+text_ACIIndicatorList.size());
			TextGuiTestObject text_ACIIndicator = null;
			if(text_ACIIndicatorList.size()==0){
				System.out.println("ACI returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "ACI returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_ACIIndicatorList.size()==1){
				for(int i=0;i<text_ACIIndicatorList.size();i++){
					System.out.println("Id: "+text_ACIIndicatorList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_ACIIndicatorList.get(i).getProperty(".value").toString());
				}
				text_ACIIndicator = (TextGuiTestObject)text_ACIIndicatorList.get(text_ACIIndicatorList.size()-1);			
				if(text_ACIIndicator!= null){
					text_ACIIndicator.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_ACIIndicator.getProperty: "+text_ACIIndicator.getProperty(".value").toString().trim());
					System.out.println("Got ACI on text_ACIIndicatorList.size()-1");					
				}
				else{
					System.out.println("ACI textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "ACI textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_ACIIndicatorList.size();i++){
					System.out.println("Id: "+text_ACIIndicatorList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_ACIIndicatorList.get(i).getProperty(".value").toString());
				}
				text_ACIIndicator = (TextGuiTestObject)text_ACIIndicatorList.get(Math.round(text_ACIIndicatorList.size()/2)-1);			
				if(text_ACIIndicator!= null){
					text_ACIIndicator.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_ACIIndicator.getProperty: "+text_ACIIndicator.getProperty(".value").toString().trim());
					System.out.println("Got ACI on (text_ACIIndicatorList.size()/2)-1");
										
				}
				else{
					System.out.println("ACI textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "ACI textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting Reason Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ReasonCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "reasonCode");
			System.out.println("text_ReasonCodeList Size: "+text_ReasonCodeList.size());
			TextGuiTestObject text_ReasonCode = null;
			if(text_ReasonCodeList.size()==0){
				System.out.println("Reason Code returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Reason Code returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_ReasonCodeList.size()==1){
				for(int i=0;i<text_ReasonCodeList.size();i++){
					System.out.println("Id: "+text_ReasonCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_ReasonCodeList.get(i).getProperty(".value").toString());
				}
				text_ReasonCode = (TextGuiTestObject)text_ReasonCodeList.get(text_ReasonCodeList.size()-1);			
				if(text_ReasonCode!= null){
					text_ReasonCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_ReasonCode.getProperty: "+text_ReasonCode.getProperty(".value").toString().trim());
					System.out.println("Got Reason Code on text_ReasonCodeList.size()-1");					
				}
				else{
					System.out.println("Reason Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Reason Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_ReasonCodeList.size();i++){
					System.out.println("Id: "+text_ReasonCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_ReasonCodeList.get(i).getProperty(".value").toString());
				}
				text_ReasonCode = (TextGuiTestObject)text_ReasonCodeList.get(Math.round(text_ReasonCodeList.size()/2)-1);			
				if(text_ReasonCode!= null){
					text_ReasonCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_ReasonCode.getProperty: "+text_ReasonCode.getProperty(".value").toString().trim());
					System.out.println("Got Reason Code on (text_ReasonCodeList.size()/2)-1");
										
				}
				else{
					System.out.println("Reason Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Reason Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting POS Entry Mode text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_POSEntryModeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "entryMode");
			System.out.println("text_POSEntryModeList Size: "+text_POSEntryModeList.size());
			TextGuiTestObject text_POSEntryMode = null;
			if(text_POSEntryModeList.size()==0){
				System.out.println("POS Entry Mode returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "POS Entry Mode returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_POSEntryModeList.size()==1){
				for(int i=0;i<text_POSEntryModeList.size();i++){
					System.out.println("Id: "+text_POSEntryModeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_POSEntryModeList.get(i).getProperty(".value").toString());
				}
				text_POSEntryMode = (TextGuiTestObject)text_POSEntryModeList.get(text_POSEntryModeList.size()-1);			
				if(text_POSEntryMode!= null){
					text_POSEntryMode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_POSEntryMode.getProperty: "+text_POSEntryMode.getProperty(".value").toString().trim());
					System.out.println("Got POS Entry Mode on text_POSEntryModeList.size()-1");					
				}
				else{
					System.out.println("POS Entry Mode textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "POS Entry Mode textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_POSEntryModeList.size();i++){
					System.out.println("Id: "+text_POSEntryModeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_POSEntryModeList.get(i).getProperty(".value").toString());
				}
				text_POSEntryMode = (TextGuiTestObject)text_POSEntryModeList.get(Math.round(text_POSEntryModeList.size()/2)-1);			
				if(text_POSEntryMode!= null){
					text_POSEntryMode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_POSEntryMode.getProperty: "+text_POSEntryMode.getProperty(".value").toString().trim());
					System.out.println("Got POS Entry Mode on (text_POSEntryModeList.size()/2)-1");
										
				}
				else{
					System.out.println("POS Entry Mode textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "POS Entry Mode textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting CVV2 Response text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_CVV2ResponseList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "cvv2Response");
			System.out.println("text_CVV2ResponseList Size: "+text_CVV2ResponseList.size());
			TextGuiTestObject text_CVV2Response = null;
			if(text_CVV2ResponseList.size()==0){
				System.out.println("CVV2 Response returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "CVV2 Response returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_CVV2ResponseList.size()==1){
				for(int i=0;i<text_CVV2ResponseList.size();i++){
					System.out.println("Id: "+text_CVV2ResponseList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_CVV2ResponseList.get(i).getProperty(".value").toString());
				}
				text_CVV2Response = (TextGuiTestObject)text_CVV2ResponseList.get(text_CVV2ResponseList.size()-1);			
				if(text_CVV2Response!= null){
					text_CVV2Response.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_CVV2Response.getProperty: "+text_CVV2Response.getProperty(".value").toString().trim());
					System.out.println("Got CVV2 Response on text_CVV2ResponseList.size()-1");					
				}
				else{
					System.out.println("CVV2 Response textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "CVV2 Response textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_CVV2ResponseList.size();i++){
					System.out.println("Id: "+text_CVV2ResponseList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_CVV2ResponseList.get(i).getProperty(".value").toString());
				}
				text_CVV2Response = (TextGuiTestObject)text_CVV2ResponseList.get(Math.round(text_CVV2ResponseList.size()/2)-1);			
				if(text_CVV2Response!= null){
					text_CVV2Response.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_CVV2Response.getProperty: "+text_CVV2Response.getProperty(".value").toString().trim());
					System.out.println("Got CVV2 Response on (text_CVV2ResponseList.size()/2)-1");
										
				}
				else{
					System.out.println("CVV2 Response textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "CVV2 Response textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting Total Incremental Auths text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_IncCountsList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "incrementalCount");
			System.out.println("text_IncCountsList Size: "+text_IncCountsList.size());
			TextGuiTestObject text_IncCounts = null;
			if(text_IncCountsList.size()==0){
				System.out.println("Total Incremental Auths returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Total Incremental Auths returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_IncCountsList.size()==1){
				for(int i=0;i<text_IncCountsList.size();i++){
					System.out.println("Id: "+text_IncCountsList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_IncCountsList.get(i).getProperty(".value").toString());
				}
				text_IncCounts = (TextGuiTestObject)text_IncCountsList.get(text_IncCountsList.size()-1);			
				if(text_IncCounts!= null){
					text_IncCounts.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_IncCounts.getProperty: "+text_IncCounts.getProperty(".value").toString().trim());
					System.out.println("Got Total Incremental Auths on text_IncCountsList.size()-1");					
				}
				else{
					System.out.println("Total Incremental Auths textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Total Incremental Auths textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_IncCountsList.size();i++){
					System.out.println("Id: "+text_IncCountsList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_IncCountsList.get(i).getProperty(".value").toString());
				}
				text_IncCounts = (TextGuiTestObject)text_IncCountsList.get(Math.round(text_IncCountsList.size()/2)-1);			
				if(text_IncCounts!= null){
					text_IncCounts.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_IncCounts.getProperty: "+text_IncCounts.getProperty(".value").toString().trim());
					System.out.println("Got Total Incremental Auths on (text_IncCountsList.size()/2)-1");
										
				}
				else{
					System.out.println("Total Incremental Auths textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Total Incremental Auths textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting Auth Reversal Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AuthRevIndicatorList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "authReversalIndicator");
			System.out.println("text_AuthRevIndicatorList Size: "+text_AuthRevIndicatorList.size());
			TextGuiTestObject text_AuthRevIndicator = null;
			if(text_AuthRevIndicatorList.size()==0){
				System.out.println("Auth Reversal Indicator returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Auth Reversal Indicator returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_AuthRevIndicatorList.size()==1){
				for(int i=0;i<text_AuthRevIndicatorList.size();i++){
					System.out.println("Id: "+text_AuthRevIndicatorList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthRevIndicatorList.get(i).getProperty(".value").toString());
				}
				text_AuthRevIndicator = (TextGuiTestObject)text_AuthRevIndicatorList.get(text_AuthRevIndicatorList.size()-1);			
				if(text_AuthRevIndicator!= null){
					text_AuthRevIndicator.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AuthRevIndicator.getProperty: "+text_AuthRevIndicator.getProperty(".value").toString().trim());
					System.out.println("Got Auth Reversal Indicator on text_AuthRevIndicatorList.size()-1");					
				}
				else{
					System.out.println("Auth Reversal Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Auth Reversal Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_AuthRevIndicatorList.size();i++){
					System.out.println("Id: "+text_AuthRevIndicatorList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthRevIndicatorList.get(i).getProperty(".value").toString());
				}
				text_AuthRevIndicator = (TextGuiTestObject)text_AuthRevIndicatorList.get(Math.round(text_AuthRevIndicatorList.size()/2)-1);			
				if(text_AuthRevIndicator!= null){
					text_AuthRevIndicator.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AuthRevIndicator.getProperty: "+text_AuthRevIndicator.getProperty(".value").toString().trim());
					System.out.println("Got Auth Reversal Indicator on (text_AuthRevIndicatorList.size()/2)-1");
										
				}
				else{
					System.out.println("Auth Reversal Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Auth Reversal Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting Miscellaneous text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_MiscellaneousList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "miscellaneous");
			System.out.println("text_MiscellaneousList Size: "+text_MiscellaneousList.size());
			TextGuiTestObject text_Miscellaneous = null;
			if(text_MiscellaneousList.size()==0){
				System.out.println("Miscellaneous returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Miscellaneous returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_MiscellaneousList.size()==1){
				for(int i=0;i<text_MiscellaneousList.size();i++){
					System.out.println("Id: "+text_MiscellaneousList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_MiscellaneousList.get(i).getProperty(".value").toString());
				}
				text_Miscellaneous = (TextGuiTestObject)text_MiscellaneousList.get(text_MiscellaneousList.size()-1);			
				if(text_Miscellaneous!= null){
					text_Miscellaneous.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_Miscellaneous.getProperty: "+text_Miscellaneous.getProperty(".value").toString().trim());
					System.out.println("Got Miscellaneous on text_MiscellaneousList.size()-1");					
				}
				else{
					System.out.println("Miscellaneous textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Miscellaneous textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_MiscellaneousList.size();i++){
					System.out.println("Id: "+text_MiscellaneousList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_MiscellaneousList.get(i).getProperty(".value").toString());
				}
				text_Miscellaneous = (TextGuiTestObject)text_MiscellaneousList.get(Math.round(text_MiscellaneousList.size()/2)-1);			
				if(text_Miscellaneous!= null){
					text_Miscellaneous.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_Miscellaneous.getProperty: "+text_Miscellaneous.getProperty(".value").toString().trim());
					System.out.println("Got Miscellaneous on (text_MiscellaneousList.size()/2)-1");
										
				}
				else{
					System.out.println("Miscellaneous textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Miscellaneous textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting Message Source text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_MessageSourceList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "messageDescription");
			System.out.println("text_MessageSourceList Size: "+text_MessageSourceList.size());
			TextGuiTestObject text_MessageSource = null;
			if(text_MessageSourceList.size()==0){
				System.out.println("Message Source returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Message Source returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_MessageSourceList.size()==1){
				for(int i=0;i<text_MessageSourceList.size();i++){
					System.out.println("Id: "+text_MessageSourceList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_MessageSourceList.get(i).getProperty(".value").toString());
				}
				text_MessageSource = (TextGuiTestObject)text_MessageSourceList.get(text_MessageSourceList.size()-1);			
				if(text_MessageSource!= null){
					text_MessageSource.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_MessageSource.getProperty: "+text_MessageSource.getProperty(".value").toString().trim());
					System.out.println("Got Message Source on text_MessageSourceList.size()-1");					
				}
				else{
					System.out.println("Message Source textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Message Source textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_MessageSourceList.size();i++){
					System.out.println("Id: "+text_MessageSourceList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_MessageSourceList.get(i).getProperty(".value").toString());
				}
				text_MessageSource = (TextGuiTestObject)text_MessageSourceList.get(Math.round(text_MessageSourceList.size()/2)-1);			
				if(text_MessageSource!= null){
					text_MessageSource.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_MessageSource.getProperty: "+text_MessageSource.getProperty(".value").toString().trim());
					System.out.println("Got Message Source on (text_MessageSourceList.size()/2)-1");
										
				}
				else{
					System.out.println("Message Source textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Message Source textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting Retrieval Reference No text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_RetrivalRefNoList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "retrievalReference");
			System.out.println("text_RetrivalRefNoList Size: "+text_RetrivalRefNoList.size());
			TextGuiTestObject text_RetrivalRefNo = null;
			if(text_RetrivalRefNoList.size()==0){
				System.out.println("Retrieval Reference No returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Retrieval Reference No returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_RetrivalRefNoList.size()==1){
				for(int i=0;i<text_RetrivalRefNoList.size();i++){
					System.out.println("Id: "+text_RetrivalRefNoList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_RetrivalRefNoList.get(i).getProperty(".value").toString());
				}
				text_RetrivalRefNo = (TextGuiTestObject)text_RetrivalRefNoList.get(text_RetrivalRefNoList.size()-1);			
				if(text_RetrivalRefNo!= null){
					text_RetrivalRefNo.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_RetrivalRefNo.getProperty: "+text_RetrivalRefNo.getProperty(".value").toString().trim());
					System.out.println("Got Retrieval Reference No on text_RetrivalRefNoList.size()-1");					
				}
				else{
					System.out.println("Retrieval Reference No textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Retrieval Reference No textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_RetrivalRefNoList.size();i++){
					System.out.println("Id: "+text_RetrivalRefNoList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_RetrivalRefNoList.get(i).getProperty(".value").toString());
				}
				text_RetrivalRefNo = (TextGuiTestObject)text_RetrivalRefNoList.get(Math.round(text_RetrivalRefNoList.size()/2)-1);			
				if(text_RetrivalRefNo!= null){
					text_RetrivalRefNo.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_RetrivalRefNo.getProperty: "+text_RetrivalRefNo.getProperty(".value").toString().trim());
					System.out.println("Got Retrieval Reference No on (text_RetrivalRefNoList.size()/2)-1");
										
				}
				else{
					System.out.println("Retrieval Reference No textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Retrieval Reference No textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Selecting Host Ref text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_HostRefList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "hostRef");
			System.out.println("text_HostRefList Size: "+text_HostRefList.size());
			TextGuiTestObject text_HostRef = null;
			if(text_HostRefList.size()==0){
				System.out.println("Host Ref returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Host Ref returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_HostRefList.size()==1){
				for(int i=0;i<text_HostRefList.size();i++){
					System.out.println("Id: "+text_HostRefList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_HostRefList.get(i).getProperty(".value").toString());
				}
				text_HostRef = (TextGuiTestObject)text_HostRefList.get(text_HostRefList.size()-1);			
				if(text_HostRef!= null){
					text_HostRef.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_HostRef.getProperty: "+text_HostRef.getProperty(".value").toString().trim());
					System.out.println("Got Host Ref on text_HostRefList.size()-1");					
				}
				else{
					System.out.println("Host Ref textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Host Ref textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_HostRefList.size();i++){
					System.out.println("Id: "+text_HostRefList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_HostRefList.get(i).getProperty(".value").toString());
				}
				text_HostRef = (TextGuiTestObject)text_HostRefList.get(Math.round(text_HostRefList.size()/2)-1);			
				if(text_HostRef!= null){
					text_HostRef.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_HostRef.getProperty: "+text_HostRef.getProperty(".value").toString().trim());
					System.out.println("Got Host Ref on (text_HostRefList.size()/2)-1");
										
				}
				else{
					System.out.println("Host Ref textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Host Ref textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}	

			//Selecting Card Entry Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_CardEntryIndList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "cardEntryIndicator");
			System.out.println("text_CardEntryIndList Size: "+text_CardEntryIndList.size());
			TextGuiTestObject text_CardEntryInd = null;
			if(text_CardEntryIndList.size()==0){
				System.out.println("Card Entry Indicator returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Card Entry Indicator returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_CardEntryIndList.size()==1){
				for(int i=0;i<text_CardEntryIndList.size();i++){
					System.out.println("Id: "+text_CardEntryIndList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_CardEntryIndList.get(i).getProperty(".value").toString());
				}
				text_CardEntryInd = (TextGuiTestObject)text_CardEntryIndList.get(text_CardEntryIndList.size()-1);			
				if(text_CardEntryInd!= null){
					text_CardEntryInd.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_CardEntryInd.getProperty: "+text_CardEntryInd.getProperty(".value").toString().trim());
					System.out.println("Got Card Entry Indicator on text_CardEntryIndList.size()-1");					
				}
				else{
					System.out.println("Card Entry Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Card Entry Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_CardEntryIndList.size();i++){
					System.out.println("Id: "+text_CardEntryIndList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_CardEntryIndList.get(i).getProperty(".value").toString());
				}
				text_CardEntryInd = (TextGuiTestObject)text_CardEntryIndList.get(Math.round(text_CardEntryIndList.size()/2)-1);			
				if(text_CardEntryInd!= null){
					text_CardEntryInd.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_CardEntryInd.getProperty: "+text_CardEntryInd.getProperty(".value").toString().trim());
					System.out.println("Got Card Entry Indicator on (text_CardEntryIndList.size()/2)-1");
										
				}
				else{
					System.out.println("Card Entry Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Card Entry Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching RFID Entry Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_RFIDEntryIndList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "rfidEntryIndicator");
			System.out.println("text_RFIDEntryIndList Size: "+text_RFIDEntryIndList.size());
			TextGuiTestObject text_RFIDEntryInd = null;
			if(text_RFIDEntryIndList.size()==0){
				System.out.println("RFID Entry Indicator returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "RFID Entry Indicator returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_RFIDEntryIndList.size()==1){
				for(int i=0;i<text_RFIDEntryIndList.size();i++){
					System.out.println("Id: "+text_RFIDEntryIndList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_RFIDEntryIndList.get(i).getProperty(".value").toString());
				}
				text_RFIDEntryInd = (TextGuiTestObject)text_RFIDEntryIndList.get(text_RFIDEntryIndList.size()-1);			
				if(text_RFIDEntryInd!= null){
					text_RFIDEntryInd.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_RFIDEntryInd.getProperty: "+text_RFIDEntryInd.getProperty(".value").toString().trim());
					System.out.println("Got RFID Entry Indicator on text_RFIDEntryIndList.size()-1");					
				}
				else{
					System.out.println("RFID Entry Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "RFID Entry Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_RFIDEntryIndList.size();i++){
					System.out.println("Id: "+text_RFIDEntryIndList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_RFIDEntryIndList.get(i).getProperty(".value").toString());
				}
				text_RFIDEntryInd = (TextGuiTestObject)text_RFIDEntryIndList.get(Math.round(text_RFIDEntryIndList.size()/2)-1);			
				if(text_RFIDEntryInd!= null){
					text_RFIDEntryInd.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_RFIDEntryInd.getProperty: "+text_RFIDEntryInd.getProperty(".value").toString().trim());
					System.out.println("Got RFID Entry Indicator on (text_RFIDEntryIndList.size()/2)-1");
										
				}
				else{
					System.out.println("RFID Entry Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "RFID Entry Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching Preferred Customer Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_PrefCustIndList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "preferredCustomerIndicator");
			System.out.println("text_PrefCustIndList Size: "+text_PrefCustIndList.size());
			TextGuiTestObject text_PrefCustInd = null;
			if(text_PrefCustIndList.size()==0){
				System.out.println("Preferred Customer Indicator returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Preferred Customer Indicator returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_PrefCustIndList.size()==1){
				for(int i=0;i<text_PrefCustIndList.size();i++){
					System.out.println("Id: "+text_PrefCustIndList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_PrefCustIndList.get(i).getProperty(".value").toString());
				}
				text_PrefCustInd = (TextGuiTestObject)text_PrefCustIndList.get(text_PrefCustIndList.size()-1);			
				if(text_PrefCustInd!= null){
					text_PrefCustInd.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_PrefCustInd.getProperty: "+text_PrefCustInd.getProperty(".value").toString().trim());
					System.out.println("Got Preferred Customer Indicator on text_PrefCustIndList.size()-1");					
				}
				else{
					System.out.println("Preferred Customer Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Preferred Customer Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_PrefCustIndList.size();i++){
					System.out.println("Id: "+text_PrefCustIndList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_PrefCustIndList.get(i).getProperty(".value").toString());
				}
				text_PrefCustInd = (TextGuiTestObject)text_PrefCustIndList.get(Math.round(text_PrefCustIndList.size()/2)-1);			
				if(text_PrefCustInd!= null){
					text_PrefCustInd.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_PrefCustInd.getProperty: "+text_PrefCustInd.getProperty(".value").toString().trim());
					System.out.println("Got Preferred Customer Indicator on (text_PrefCustIndList.size()/2)-1");
										
				}
				else{
					System.out.println("Preferred Customer Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Preferred Customer Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching Magnetic Stripe Quality Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_MagStrpQualIndList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "magneticStripeQualityIndicator");
			System.out.println("text_MagStrpQualIndList Size: "+text_MagStrpQualIndList.size());
			TextGuiTestObject text_MagStrpQualInd = null;
			if(text_MagStrpQualIndList.size()==0){
				System.out.println("Magnetic Stripe Quality Indicator returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Magnetic Stripe Quality Indicator returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_MagStrpQualIndList.size()==1){
				for(int i=0;i<text_MagStrpQualIndList.size();i++){
					System.out.println("Id: "+text_MagStrpQualIndList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_MagStrpQualIndList.get(i).getProperty(".value").toString());
				}
				text_MagStrpQualInd = (TextGuiTestObject)text_MagStrpQualIndList.get(text_MagStrpQualIndList.size()-1);			
				if(text_MagStrpQualInd!= null){
					text_MagStrpQualInd.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_MagStrpQualInd.getProperty: "+text_MagStrpQualInd.getProperty(".value").toString().trim());
					System.out.println("Got Magnetic Stripe Quality Indicator on text_MagStrpQualIndList.size()-1");					
				}
				else{
					System.out.println("Magnetic Stripe Quality Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Magnetic Stripe Quality Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_MagStrpQualIndList.size();i++){
					System.out.println("Id: "+text_MagStrpQualIndList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_MagStrpQualIndList.get(i).getProperty(".value").toString());
				}
				text_MagStrpQualInd = (TextGuiTestObject)text_MagStrpQualIndList.get(Math.round(text_MagStrpQualIndList.size()/2)-1);			
				if(text_MagStrpQualInd!= null){
					text_MagStrpQualInd.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_MagStrpQualInd.getProperty: "+text_MagStrpQualInd.getProperty(".value").toString().trim());
					System.out.println("Got Magnetic Stripe Quality Indicator on (text_MagStrpQualIndList.size()/2)-1");
										
				}
				else{
					System.out.println("Magnetic Stripe Quality Indicator textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Magnetic Stripe Quality Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching Authentication Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AuthenticationCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "authenticationCode");
			System.out.println("text_AuthenticationCodeList Size: "+text_AuthenticationCodeList.size());
			TextGuiTestObject text_AuthenticationCode = null;
			if(text_AuthenticationCodeList.size()==0){
				System.out.println("Authentication Code returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Authentication Code returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_AuthenticationCodeList.size()==1){
				for(int i=0;i<text_AuthenticationCodeList.size();i++){
					System.out.println("Id: "+text_AuthenticationCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthenticationCodeList.get(i).getProperty(".value").toString());
				}
				text_AuthenticationCode = (TextGuiTestObject)text_AuthenticationCodeList.get(text_AuthenticationCodeList.size()-1);			
				if(text_AuthenticationCode!= null){
					text_AuthenticationCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AuthenticationCode.getProperty: "+text_AuthenticationCode.getProperty(".value").toString().trim());
					System.out.println("Got Authentication Code on text_AuthenticationCodeList.size()-1");					
				}
				else{
					System.out.println("Authentication Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Authentication Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_AuthenticationCodeList.size();i++){
					System.out.println("Id: "+text_AuthenticationCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthenticationCodeList.get(i).getProperty(".value").toString());
				}
				text_AuthenticationCode = (TextGuiTestObject)text_AuthenticationCodeList.get(Math.round(text_AuthenticationCodeList.size()/2)-1);			
				if(text_AuthenticationCode!= null){
					text_AuthenticationCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AuthenticationCode.getProperty: "+text_AuthenticationCode.getProperty(".value").toString().trim());
					System.out.println("Got Authentication Code on (text_AuthenticationCodeList.size()/2)-1");
										
				}
				else{
					System.out.println("Authentication Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Authentication Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching Commercial Card Type text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_CommCardTypeList = Util.getGWTMappedObjects("Html.LABEL", ".text", "Commercial Card Type");
			GuiTestObject text_CommCardType = null;
			if(text_CommCardTypeList.size()==0){
				System.out.println("Commercial Card Type not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Commercial Card Type not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_CommCardTypeList.size();i++){
				System.out.println("Text: "+text_CommCardTypeList.get(i).getProperty(".text").toString());			
			}
			text_CommCardType = (GuiTestObject)text_CommCardTypeList.get(text_CommCardTypeList.size()-1);			
			if(text_CommCardType!= null){
				text_CommCardType.waitForExistence(10, 2);
				noOfTextBoxCompliance++;
				System.out.println("Commercial Card Type textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("Commercial Card Type textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Commercial Card Type textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			
			//Searching AVS Result Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AVSResultCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "avsResultCode");
			System.out.println("text_AVSResultCodeList Size: "+text_AVSResultCodeList.size());
			TextGuiTestObject text_AVSResultCode = null;
			if(text_AVSResultCodeList.size()==0){
				System.out.println("AVS Result Code returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "AVS Result Code returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_AVSResultCodeList.size()==1){
				for(int i=0;i<text_AVSResultCodeList.size();i++){
					System.out.println("Id: "+text_AVSResultCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AVSResultCodeList.get(i).getProperty(".value").toString());
				}
				text_AVSResultCode = (TextGuiTestObject)text_AVSResultCodeList.get(text_AVSResultCodeList.size()-1);			
				if(text_AVSResultCode!= null){
					text_AVSResultCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AVSResultCode.getProperty: "+text_AVSResultCode.getProperty(".value").toString().trim());
					System.out.println("Got AVS Result Code on text_AVSResultCodeList.size()-1");					
				}
				else{
					System.out.println("AVS Result Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "AVS Result Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_AVSResultCodeList.size();i++){
					System.out.println("Id: "+text_AVSResultCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AVSResultCodeList.get(i).getProperty(".value").toString());
				}
				text_AVSResultCode = (TextGuiTestObject)text_AVSResultCodeList.get(Math.round(text_AVSResultCodeList.size()/2)-1);			
				if(text_AVSResultCode!= null){
					text_AVSResultCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AVSResultCode.getProperty: "+text_AVSResultCode.getProperty(".value").toString().trim());
					System.out.println("Got AVS Result Code on (text_AVSResultCodeList.size()/2)-1");
										
				}
				else{
					System.out.println("AVS Result Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "AVS Result Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching E Commerce Indicator text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_ECommIndList = Util.getGWTMappedObjects("Html.LABEL", ".text", "E Commerce Indicator");
			GuiTestObject text_ECommInd = null;
			if(text_ECommIndList.size()==0){
				System.out.println("E Commerce Indicator not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "E Commerce Indicator not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_ECommIndList.size();i++){
				System.out.println("Text: "+text_ECommIndList.get(i).getProperty(".text").toString());			
			}
			text_ECommInd = (GuiTestObject)text_ECommIndList.get(text_ECommIndList.size()-1);			
			if(text_ECommInd!= null){
				text_ECommInd.waitForExistence(10, 2);	
				noOfTextBoxCompliance++;
				System.out.println("E Commerce Indicator textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("E Commerce Indicator textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "E Commerce Indicator textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching CAVV Response text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_CAVVRespList = Util.getGWTMappedObjects("Html.LABEL", ".text", "CAVV Response");
			GuiTestObject text_CAVVResp = null;
			if(text_CAVVRespList.size()==0){
				System.out.println("CAVV Response not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "CAVV Response not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_CAVVRespList.size();i++){
				System.out.println("Text: "+text_CAVVRespList.get(i).getProperty(".text").toString());			
			}
			text_CAVVResp = (GuiTestObject)text_CAVVRespList.get(text_CAVVRespList.size()-1);			
			if(text_CAVVResp!= null){
				text_CAVVResp.waitForExistence(10, 2);	
				noOfTextBoxCompliance++;
				System.out.println("CAVV Response textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("CAVV Response textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "CAVV Response textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Searching Authorization Merchant ID text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AuthMerchntIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "authMerchantId");
			System.out.println("text_AuthMerchntIdList Size: "+text_AuthMerchntIdList.size());
			TextGuiTestObject text_AuthMerchntId = null;
			if(text_AuthMerchntIdList.size()==0){
				System.out.println("Authorization Merchant ID returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Authorization Merchant ID returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_AuthMerchntIdList.size()==1){
				for(int i=0;i<text_AuthMerchntIdList.size();i++){
					System.out.println("Id: "+text_AuthMerchntIdList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthMerchntIdList.get(i).getProperty(".value").toString());
				}
				text_AuthMerchntId = (TextGuiTestObject)text_AuthMerchntIdList.get(text_AuthMerchntIdList.size()-1);			
				if(text_AuthMerchntId!= null){
					text_AuthMerchntId.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AuthMerchntId.getProperty: "+text_AuthMerchntId.getProperty(".value").toString().trim());
					System.out.println("Got Authorization Merchant ID on text_AuthMerchntIdList.size()-1");					
				}
				else{
					System.out.println("Authorization Merchant ID textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Authorization Merchant ID textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_AuthMerchntIdList.size();i++){
					System.out.println("Id: "+text_AuthMerchntIdList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthMerchntIdList.get(i).getProperty(".value").toString());
				}
				text_AuthMerchntId = (TextGuiTestObject)text_AuthMerchntIdList.get(Math.round(text_AuthMerchntIdList.size()/2)-1);			
				if(text_AuthMerchntId!= null){
					text_AuthMerchntId.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AuthMerchntId.getProperty: "+text_AuthMerchntId.getProperty(".value").toString().trim());
					System.out.println("Got Authorization Merchant ID on (text_AuthMerchntIdList.size()/2)-1");
										
				}
				else{
					System.out.println("Authorization Merchant ID textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Authorization Merchant ID textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching Authorization Processor Name text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AuthTppNameList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "authTppName");
			System.out.println("text_AuthTppNameList Size: "+text_AuthTppNameList.size());
			TextGuiTestObject text_AuthTppName = null;
			if(text_AuthTppNameList.size()==0){
				System.out.println("Authorization Processor Name returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Authorization Processor Name returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_AuthTppNameList.size()==1){
				for(int i=0;i<text_AuthTppNameList.size();i++){
					System.out.println("Id: "+text_AuthTppNameList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthTppNameList.get(i).getProperty(".value").toString());
				}
				text_AuthTppName = (TextGuiTestObject)text_AuthTppNameList.get(text_AuthTppNameList.size()-1);			
				if(text_AuthTppName!= null){
					text_AuthTppName.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AuthTppName.getProperty: "+text_AuthTppName.getProperty(".value").toString().trim());
					System.out.println("Got Authorization Processor Name on text_AuthTppNameList.size()-1");					
				}
				else{
					System.out.println("Authorization Processor Name textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Authorization Processor Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_AuthTppNameList.size();i++){
					System.out.println("Id: "+text_AuthTppNameList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_AuthTppNameList.get(i).getProperty(".value").toString());
				}
				text_AuthTppName = (TextGuiTestObject)text_AuthTppNameList.get(Math.round(text_AuthTppNameList.size()/2)-1);			
				if(text_AuthTppName!= null){
					text_AuthTppName.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_AuthTppName.getProperty: "+text_AuthTppName.getProperty(".value").toString().trim());
					System.out.println("Got Authorization Processor Name on (text_AuthTppNameList.size()/2)-1");
										
				}
				else{
					System.out.println("Authorization Processor Name textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Authorization Processor Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching Settlement Merchant ID text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_SettleMerchantIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "settleMerchantId");
			System.out.println("text_SettleMerchantIdList Size: "+text_SettleMerchantIdList.size());
			TextGuiTestObject text_SettleMerchantId = null;
			if(text_SettleMerchantIdList.size()==0){
				System.out.println("Settlement Merchant ID returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Settlement Merchant ID returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_SettleMerchantIdList.size()==1){
				for(int i=0;i<text_SettleMerchantIdList.size();i++){
					System.out.println("Id: "+text_SettleMerchantIdList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_SettleMerchantIdList.get(i).getProperty(".value").toString());
				}
				text_SettleMerchantId = (TextGuiTestObject)text_SettleMerchantIdList.get(text_SettleMerchantIdList.size()-1);			
				if(text_SettleMerchantId!= null){
					text_SettleMerchantId.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_SettleMerchantId.getProperty: "+text_SettleMerchantId.getProperty(".value").toString().trim());
					System.out.println("Got Settlement Merchant ID on text_SettleMerchantIdList.size()-1");					
				}
				else{
					System.out.println("Settlement Merchant ID textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Settlement Merchant ID textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_SettleMerchantIdList.size();i++){
					System.out.println("Id: "+text_SettleMerchantIdList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_SettleMerchantIdList.get(i).getProperty(".value").toString());
				}
				text_SettleMerchantId = (TextGuiTestObject)text_SettleMerchantIdList.get(Math.round(text_SettleMerchantIdList.size()/2)-1);			
				if(text_SettleMerchantId!= null){
					text_SettleMerchantId.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_SettleMerchantId.getProperty: "+text_SettleMerchantId.getProperty(".value").toString().trim());
					System.out.println("Got Settlement Merchant ID on (text_SettleMerchantIdList.size()/2)-1");
										
				}
				else{
					System.out.println("Settlement Merchant ID textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Settlement Merchant ID textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching Settlement Processor Name text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_SettleTppNameList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "settleTppName");
			System.out.println("text_SettleTppNameList Size: "+text_SettleTppNameList.size());
			TextGuiTestObject text_SettleTppName = null;
			if(text_SettleTppNameList.size()==0){
				System.out.println("Settlement Processor Name returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Settlement Processor Name returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_SettleTppNameList.size()==1){
				for(int i=0;i<text_SettleTppNameList.size();i++){
					System.out.println("Id: "+text_SettleTppNameList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_SettleTppNameList.get(i).getProperty(".value").toString());
				}
				text_SettleTppName = (TextGuiTestObject)text_SettleTppNameList.get(text_SettleTppNameList.size()-1);			
				if(text_SettleTppName!= null){
					text_SettleTppName.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_SettleTppName.getProperty: "+text_SettleTppName.getProperty(".value").toString().trim());
					System.out.println("Got Settlement Processor Name on text_SettleTppNameList.size()-1");					
				}
				else{
					System.out.println("Settlement Processor Name textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Settlement Processor Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_SettleTppNameList.size();i++){
					System.out.println("Id: "+text_SettleTppNameList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_SettleTppNameList.get(i).getProperty(".value").toString());
				}
				text_SettleTppName = (TextGuiTestObject)text_SettleTppNameList.get(Math.round(text_SettleTppNameList.size()/2)-1);			
				if(text_SettleTppName!= null){
					text_SettleTppName.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_SettleTppName.getProperty: "+text_SettleTppName.getProperty(".value").toString().trim());
					System.out.println("Got Settlement Processor Name on (text_SettleTppNameList.size()/2)-1");
										
				}
				else{
					System.out.println("Settlement Processor Name textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Settlement Processor Name textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching E2EE Response Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_E2EEResCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "e2eeRespCode");
			System.out.println("text_E2EEResCodeList Size: "+text_E2EEResCodeList.size());
			TextGuiTestObject text_E2EEResCode = null;
			if(text_E2EEResCodeList.size()==0){
				System.out.println("E2EE Response Code returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "E2EE Response Code returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_E2EEResCodeList.size()==1){
				for(int i=0;i<text_E2EEResCodeList.size();i++){
					System.out.println("Id: "+text_E2EEResCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_E2EEResCodeList.get(i).getProperty(".value").toString());
				}
				text_E2EEResCode = (TextGuiTestObject)text_E2EEResCodeList.get(text_E2EEResCodeList.size()-1);			
				if(text_E2EEResCode!= null){
					text_E2EEResCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_E2EEResCode.getProperty: "+text_E2EEResCode.getProperty(".value").toString().trim());
					System.out.println("Got E2EE Response Code on text_E2EEResCodeList.size()-1");					
				}
				else{
					System.out.println("E2EE Response Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "E2EE Response Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_E2EEResCodeList.size();i++){
					System.out.println("Id: "+text_E2EEResCodeList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_E2EEResCodeList.get(i).getProperty(".value").toString());
				}
				text_E2EEResCode = (TextGuiTestObject)text_E2EEResCodeList.get(Math.round(text_E2EEResCodeList.size()/2)-1);			
				if(text_E2EEResCode!= null){
					text_E2EEResCode.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_E2EEResCode.getProperty: "+text_E2EEResCode.getProperty(".value").toString().trim());
					System.out.println("Got E2EE Response Code on (text_E2EEResCodeList.size()/2)-1");
										
				}
				else{
					System.out.println("E2EE Response Code textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "E2EE Response Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			
			//Searching E2EE Serial No text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_E2EESerialNoList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "e2eeSerialNo");
			System.out.println("text_E2EESerialNoList Size: "+text_E2EESerialNoList.size());
			TextGuiTestObject text_E2EESerialNo = null;
			if(text_E2EESerialNoList.size()==0){
				System.out.println("E2EE Serial No returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "E2EE Serial No returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_E2EESerialNoList.size()==1){
				for(int i=0;i<text_E2EESerialNoList.size();i++){
					noOfTextBoxCompliance++;
					System.out.println("Id: "+text_E2EESerialNoList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_E2EESerialNoList.get(i).getProperty(".value").toString());
				}
				text_E2EESerialNo = (TextGuiTestObject)text_E2EESerialNoList.get(text_E2EESerialNoList.size()-1);			
				if(text_E2EESerialNo!= null){
					text_E2EESerialNo.waitForExistence(10, 2);
					System.out.println("text_E2EESerialNo.getProperty: "+text_E2EESerialNo.getProperty(".value").toString().trim());
					System.out.println("Got E2EE Serial No on text_E2EESerialNoList.size()-1");					
				}
				else{
					System.out.println("E2EE Serial No textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "E2EE Serial No textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_E2EESerialNoList.size();i++){
					System.out.println("Id: "+text_E2EESerialNoList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_E2EESerialNoList.get(i).getProperty(".value").toString());
				}
				text_E2EESerialNo = (TextGuiTestObject)text_E2EESerialNoList.get(Math.round(text_E2EESerialNoList.size()/2)-1);			
				if(text_E2EESerialNo!= null){
					text_E2EESerialNo.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_E2EESerialNo.getProperty: "+text_E2EESerialNo.getProperty(".value").toString().trim());
					System.out.println("Got E2EE Serial No on (text_E2EESerialNoList.size()/2)-1");
										
				}
				else{
					System.out.println("E2EE Serial No textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "E2EE Serial No textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			//Searching E2EE Encryption Method text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_E2EEEncryptMethodList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "e2eeEncryptMethod");
			System.out.println("text_E2EEEncryptMethodList Size: "+text_E2EEEncryptMethodList.size());
			TextGuiTestObject text_E2EEEncryptMethod = null;
			if(text_E2EEEncryptMethodList.size()==0){
				System.out.println("E2EE Encryption Method returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "E2EE Encryption Method returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_E2EEEncryptMethodList.size()==1){
				for(int i=0;i<text_E2EEEncryptMethodList.size();i++){
					System.out.println("Id: "+text_E2EEEncryptMethodList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_E2EEEncryptMethodList.get(i).getProperty(".value").toString());
				}
				text_E2EEEncryptMethod = (TextGuiTestObject)text_E2EEEncryptMethodList.get(text_E2EEEncryptMethodList.size()-1);			
				if(text_E2EEEncryptMethod!= null){
					text_E2EEEncryptMethod.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_E2EEEncryptMethod.getProperty: "+text_E2EEEncryptMethod.getProperty(".value").toString().trim());
					System.out.println("Got E2EE Encryption Method on text_E2EEEncryptMethodList.size()-1");					
				}
				else{
					System.out.println("E2EE Encryption Method textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "E2EE Encryption Method textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_E2EEEncryptMethodList.size();i++){
					System.out.println("Id: "+text_E2EEEncryptMethodList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_E2EEEncryptMethodList.get(i).getProperty(".value").toString());
				}
				text_E2EEEncryptMethod = (TextGuiTestObject)text_E2EEEncryptMethodList.get(Math.round(text_E2EEEncryptMethodList.size()/2)-1);			
				if(text_E2EEEncryptMethod!= null){
					text_E2EEEncryptMethod.waitForExistence(10, 2);
					noOfTextBoxCompliance++;
					System.out.println("text_E2EEEncryptMethod.getProperty: "+text_E2EEEncryptMethod.getProperty(".value").toString().trim());
					System.out.println("Got E2EE Encryption Method on (text_E2EEEncryptMethodList.size()/2)-1");
										
				}
				else{
					System.out.println("E2EE Encryption Method textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "E2EE Encryption Method textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}	

			//Searching E2EE Encryption Status text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_E2EEEncryptStatusList = Util.getGWTMappedObjects("Html.LABEL", ".text", "E2EE Encryption Status");
			GuiTestObject text_E2EEEncryptStatus = null;
			if(text_E2EEEncryptStatusList.size()==0){
				System.out.println("E2EE Encryption Status not found in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "E2EE Encryption Status not found in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_E2EEEncryptStatusList.size();i++){
				System.out.println("Text: "+text_E2EEEncryptStatusList.get(i).getProperty(".text").toString());			
			}
			text_E2EEEncryptStatus = (GuiTestObject)text_E2EEEncryptStatusList.get(text_E2EEEncryptStatusList.size()-1);			
			if(text_E2EEEncryptStatus!= null){
				text_E2EEEncryptStatus.waitForExistence(10, 2);	
				noOfTextBoxCompliance++;
				System.out.println("E2EE Encryption Status textbox is present in View Transaction Details Page");
			}
			else{
				System.out.println("E2EE Encryption Status textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "E2EE Encryption Status textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			
		}//End of Compliance tab
		else{
			System.out.println("Compliance Tab is absent in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Compliance Tab is absent in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		//End of Selecting Compliance tab
		
		//Selecting Basic Transaction Tab again
		link_BasicTxn.click();
		sleep(15);
		
		//Validating the number of text fields available on the view Txn page
		//Validating basic txn tab
		if(noOfTextBoxBasicTxn<22){
			System.out.println("Total Text Field number under Basic Transaction tab in View Transaction Details Page should be at-least >=22 instead of current number of : "+noOfTextBoxBasicTxn);
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Total Text Field number under Basic Transaction tab in View Transaction Details Page should be >=22 instead of current number of : "+noOfTextBoxBasicTxn, Status.BC_FAILED);
			return;
		}//End of basic txn tab validation
		
		//Validating expanded details tab
		if(noOfTextBoxExpandedDetails<13){
			System.out.println("Total Text Field number under Expanded Details tab in View Transaction Details Page should be >=13 instead of current number of : "+noOfTextBoxExpandedDetails);
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Total Text Field number under Expanded Details tab in View Transaction Details Page should be >=13 instead of current number of : "+noOfTextBoxExpandedDetails, Status.BC_FAILED);
			return;
		}//End of expanded details tab validation
		
		//Validating customer tab
		if(noOfTextBoxCustomer!=6){
			System.out.println("Total Text Field number under Customer tab in View Transaction Details Page should be =6 instead of current number of : "+noOfTextBoxCustomer);
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Total Text Field number under Customer tab in View Transaction Details Page should be =6 instead of current number of : "+noOfTextBoxCustomer, Status.BC_FAILED);
			return;
		}//End of customer tab validation
		
		//Validating compliance tab
		if(noOfTextBoxCompliance!=33){
			System.out.println("Total Text Field number under Compliance tab in View Transaction Details Page should be =6 instead of current number of : "+noOfTextBoxCompliance);
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Total Text Field number under Compliance tab in View Transaction Details Page should be =6 instead of current number of : "+noOfTextBoxCompliance, Status.BC_FAILED);
			return;
		}//End of compliance tab validation
		
		//End of Validating the number of text fields available on the view Txn page
		
//		//Selecting the Submit button on View Transaction Details Page	
//		GuiTestObject button_Submit = Util.getMappedObject("Html.BUTTON", ".value", "Submit");
//		if(button_Submit!=null){
//			button_Submit.waitForExistence(10, 2);
//			noOfButtons++;
////			button_Submit.click();	
////			sleep(5);			
//		}
//		else{
//			System.out.println("Submit button not present on View Transaction Details Page");
//			error = true;
//			Util.scenarioStatus = false;
//			CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Submit button not present on View Transaction Details Page", Status.BC_FAILED);
//			return;
//		}//End of Submit button on View Transaction Details Page
		
		
		
		button_ReturnToListView.click();
		
		//Waiting for the Home page to be displayed and loading message to disappear
		for(int loop=0;loop<20;loop++){
			ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
			System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
			if(progressBar_LoadingList.size()>=1){
				for(int i=0;i<progressBar_LoadingList.size();i++){
					System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
					System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
				}
				GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
				System.out.println("Progressbar checking loopcount: "+loop);
				if(progressBar_Loading!=null){
					System.out.println("The Transaction List page is still NOT populated");
					sleep(2);
					continue;					
				}
				else{
					System.out.println("The Transaction List page is populated");
					break;
				}
			}//End of if for progress bar loading
			else{
				System.out.println("The Transaction List page is populated");
				break;
			}//End of else for progress bar loading
			
		}//End of for statement to check the progress bar loading 
		
		sleep(5);
		
		
		//Returning to the home tab as an exit point
		if(link_home().exists()
				|| link_home().ensureObjectIsVisible()){
			link_home().waitForExistence(20, 2);
			link_home().click();
			//Waiting for the Home page to be displayed and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(2);
			//Checking the existence of refresh button at the welcome area on home page				
			GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
			if(button_RefreshAtHome!= null){
				button_RefreshAtHome.waitForExistence(20, 2);
				button_RefreshAtHome.ensureObjectIsVisible();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
				return;
			}
			sleep(10);
		}
		else{
			System.out.println("Home tab is absent in View Transaction Detail Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Home tab is absent in View Transaction Detail Page", Status.BC_FAILED);
			return;
		}//End of returning to the home tab as an exit point
	
		
		//Component success message
		String cmpSuccessMsg = "Selected Transaction with Id: "+txnId+" :have been viewed successfully." +
								" # Total number of buttons found: "+noOfButtons+
								" # Total number of Text Fields found on Basic Transaction Tab(Except Industry Specific Fields): "+noOfTextBoxBasicTxn+
								" # Total number of Text Fields found on Expanded Details Tab(Except Industry Specific Fields): "+noOfTextBoxExpandedDetails+
								" # Total number of Text Fields found on Customer Tab: "+noOfTextBoxCustomer+
								" # Total number of Text Fields found on Compliance Tab: "+noOfTextBoxCompliance+
								" # Along with these \"Notes\" link found on every tab";
		
		System.out.println(cmpSuccessMsg);
		CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
		
		}
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();			
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}
		
	}//End of Execute Component
	
}//End of class

