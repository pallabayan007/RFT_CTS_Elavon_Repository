package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.BatchAddNoteHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxghos1
 */
public class BatchAddNote extends BatchAddNoteHelper
{
	/**
	 * Script Name   : <b>BatchAddNote</b>
	 * Generated     : <b>Dec 20, 2011 12:44:41 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/12/20
	 * @author sxghos1
	 */

	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "BatchAddNote";

	public void testMain(Object[] args) 
	{
		// TODO Insert code here

		try
		{
			if (args.length < 3)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 3 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 3 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");

				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}

			}		

		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}

	}//End of testMain()

	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{			
			String batchStatus = (String) args[0];		
			batchStatus = batchStatus.toUpperCase();
			String view = "";
			String multiRecordAddNote = (String) args[1];
			String notes = (String) args[2];

			//Waiting for the batch list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The batch list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The batch list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The batch list is populated");
					break;
				}//End of else for progress bar loading

			}//End of for statement to check the progress bar loading 

			//Verifying whether the Add Notes button is enabled or disabled			
			GuiTestObject button_AddNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Add Notes");
			if(button_AddNotes!= null){
				button_AddNotes.waitForExistence(10, 2);
				if(button_AddNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Add Notes button is enabled in Batch List Page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Add Notes button is enabled in Batch List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_AddNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Add Notes button is disabled rightly in Batch List Page while no records are selected");
				}

			}
			else{
				System.out.println("Add Notes button is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Add Notes button is absent in Batch List page", Status.BC_FAILED);
				return;
			}

			RegularExpression regExBatchSearch = new RegularExpression("batchListGrid_x-auto-[0-9].*",false);
			if(batchStatus.isEmpty()){
				//			view = "Expanded View";
				view = "View";
				//Selecting the records to add note to a batch in batch search list page
				ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", view);
				StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
				System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
				if(list_SelectBatchSearchResultList.size()!=0){
					int loopUBound = 0;
					if(multiRecordAddNote.equalsIgnoreCase("false")){
						loopUBound = 1;
					}
					else if(list_SelectBatchSearchResultList.size()>4){
						loopUBound = 4;
					}
					else if(list_SelectBatchSearchResultList.size()<4){
						loopUBound = list_SelectBatchSearchResultList.size();
					}

					//Looping through the matching records
					for(int loop=0;loop<loopUBound;loop++){
						System.out.println("checkbox_SearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
						checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
						//					System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
						if(checkbox_SearchRecord!=null){
							//						System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
							//						System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
							//						checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
							//															Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
							checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
									atColumn(atIndex(0))));
							sleep(1);
							//						break;
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
					}
				}
				else{
					System.out.println("No matching record found in Batch List Page with Expanded View");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Batch List Page with Expanded View", Status.BC_FAILED);
					return;
				}
			}
			else if(!batchStatus.isEmpty()){
				//Selecting the records to add note to a batch in batch search list page
				//			RegularExpression regExBatchSearch1 = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
				ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", batchStatus);
				StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
				System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
				if(list_SelectBatchSearchResultList.size()!=0){
					int loopUBound = 0;
					if(multiRecordAddNote.equalsIgnoreCase("false")){
						loopUBound = 1;
					}
					else if(list_SelectBatchSearchResultList.size()>4){
						loopUBound = 4;
					}
					else if(list_SelectBatchSearchResultList.size()<4){
						loopUBound = list_SelectBatchSearchResultList.size();
					}

					//Looping through the matching records
					for(int loop=0;loop<loopUBound;loop++){
						System.out.println("checkbox_SearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
						checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
//							System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
						if(checkbox_SearchRecord!=null){
//							System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//							System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//							checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//							Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
							checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
									atColumn(atIndex(0))));
							sleep(1);
//							break;
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
					}
				}
				else{
					System.out.println("No matching record found in Batch List Page for batch status: "+batchStatus);
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Batch List Page for batch status: "+batchStatus, Status.BC_FAILED);
					return;
				}
			}


			//Selecting the Add Notes button to add a note to the selected records	
			GuiTestObject button_AddBatchNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Add Notes");
			if(button_AddBatchNotes!= null){
				button_AddBatchNotes.waitForExistence(10, 2);
				//Checking whether the add notes button is enabled or disabled
				if(button_AddBatchNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Add Notes button is disabled in Batch List Page even after selecting records");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Add Notes button is disabled in Batch List Page even after selecting records", Status.BC_FAILED);
					return;
				}
				else if(button_AddBatchNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					button_AddBatchNotes.click();
					sleep(6);
					//Checking for the existence of the Add batch Notes confirm existence 
					GuiTestObject popup_AddNotesConfirm = Util.getMappedObject("Html.SPAN", ".text", "Add Batch Notes");					
					if(popup_AddNotesConfirm!=null){
						popup_AddNotesConfirm.waitForExistence(20, 2);
						//Selecting Cancel button to cancel the Add batch Notes pop up 			
						GuiTestObject button_CancelAddNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
						if(button_CancelAddNotes!= null){
							button_CancelAddNotes.waitForExistence(10, 2);
							button_CancelAddNotes.click();
							sleep(2);
							button_AddBatchNotes.waitForExistence(10,2);
						}
						else{
							System.out.println("Cancel button is absent on add batch notes pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on add batch notes pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for cancel button existence check

						//Selecting the add notes button again to make the add batch notes pop up re-appear
						button_AddBatchNotes.click();
						sleep(10);
						
						//Validating Submit button			
						GuiTestObject button_SubmitAddBatchNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
						if(button_SubmitAddBatchNotes!= null){
							button_SubmitAddBatchNotes.waitForExistence(10, 2);
							System.out.println("button_SubmitAddBatchNotes.getProperty(aria-disabled).toString(): "+button_SubmitAddBatchNotes.getProperty("aria-disabled").toString());
							//Validating whether the submit button is enabled/disabled
							if(button_SubmitAddBatchNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
								System.out.println("Submit button is disabled on add batch notes pop-up confirmation window");
								//Selecting Cancel button			
								ArrayList<GuiTestObject> button_CancelAddBatchNotesList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
								GuiTestObject button_CancelAddBatchNotes = null;
								if(button_CancelAddBatchNotesList.size()<1){
									System.out.println("Cancel button is not found on add batch notes pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Cancel is not found on add batch notes pop-up confirmation window", Status.BC_FAILED);
									return;
								}
								button_CancelAddBatchNotes = button_CancelAddBatchNotesList.get(button_CancelAddBatchNotesList.size()-1);
								if(button_CancelAddBatchNotes!= null){
									button_CancelAddBatchNotes.waitForExistence(10, 2);
									button_CancelAddBatchNotes.click();
									sleep(2);
									button_AddBatchNotes.waitForExistence(10,2);
								}
								else{
									System.out.println("Cancel button is absent on add batch notes pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Cancel is absent on add batch notes pop-up confirmation window", Status.BC_FAILED);
									return;
								}//End of else for cancel button existence check

							}//End of if for submit button disabled validation	
//							else if(button_SubmitAddBatchNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
							else{
								System.out.println("Submit button is enabled on add batch pop-up confirmation window");

								//Selecting Enter Notes in the Add Batch Notes pop-up
								RegularExpression regExNotes = new RegularExpression("x-auto-[0-9].*-input",false);
								//TextGuiTestObject text_VoidTransactionNotesNotes = (TextGuiTestObject)Util.getMappedObject("Html.TEXTAREA", ".className", "x-form-field x-form-textarea");
								TextGuiTestObject text_BatchNotes = (TextGuiTestObject)Util.getGWTMappedObject("Html.TEXTAREA", ".id", regExNotes);
								if(text_BatchNotes!= null){
									text_BatchNotes.waitForExistence(10, 2);
									text_BatchNotes.click();
									text_BatchNotes.setText(notes);
									sleep(1);
								}
								else{
									System.out.println("Enter Notes area is absent in Add Batch Notes popup");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Enter Notes area is absent in Add Batch Notes popup", Status.BC_FAILED);
									return;
								}

								//Selecting Visible to external user check box in the Add Batch Notes popup			
								ArrayList<GuiTestObject> checkbox_VisibleExtUserList = Util.getGWTMappedObjects("Html.DIV", ".text", "Visible to External Users");
								GuiTestObject checkbox_VisibleExtUser = null;
								if(checkbox_VisibleExtUserList.size()!=0){
									checkbox_VisibleExtUser = checkbox_VisibleExtUserList.get(checkbox_VisibleExtUserList.size()-1);
									if(checkbox_VisibleExtUser!= null){				
										checkbox_VisibleExtUser.waitForExistence(10, 2);
										checkbox_VisibleExtUser.click();			
										sleep(1);
									}
									else{
										System.out.println("Visible to external user checkbox is absent in Add Batch Notes popup");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Visible to external user check box is absent in Add Batch Notes popup", Status.BC_FAILED);
										return;
									}
								}

								else{
									System.out.println("Visible to external user checkbox not found in Add Batch Notes popup");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Visible to external user check box not found in Add Batch Notes popup", Status.BC_FAILED);
									return;
								}


								button_SubmitAddBatchNotes.click();

								//Checking for the existence of the submit confirmation pop up		
								GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.SPAN", ".text", "Confirm Action");
								if(popup_SubmitConfirm==null){			
									System.out.println("Submit confirmation pop up not present");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Submit confirmation pop up not present", Status.BC_FAILED);
									return;			
								}
								else{
									System.out.println("Submit confirmation pop up is present");	
									popup_SubmitConfirm.waitForExistence(30, 2);

									//Selecting the Cancel button on the confirmation pop up 		
									ArrayList<GuiTestObject> button_ConfirmCancelList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
									GuiTestObject button_ConfirmCancel = null;
									if(button_ConfirmCancelList.size()<1){
										System.out.println("Cancel button is not found on submit pop-up confirmation window");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Cancel is not found on submit pop-up confirmation window", Status.BC_FAILED);
										return;
									}
									button_ConfirmCancel = button_ConfirmCancelList.get(button_ConfirmCancelList.size()-1);
									if(button_ConfirmCancel!=null){
										button_ConfirmCancel.click();	
										sleep(5);
									}
									else{
										System.out.println("Cancel button not present on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
										return;
									}//End of Cancel button on the confirmation pop up


									button_SubmitAddBatchNotes.click();
									popup_SubmitConfirm.waitForExistence(10, 2);

									//Selecting the Confirm button on the confirmation pop up 		
									GuiTestObject button_Confirm = Util.getMappedObject("Html.BUTTON", ".value", "Confirm");
									if(button_Confirm!=null){
										button_Confirm.click();	
										sleep(20);
									}
									else{
										System.out.println("Confirm button not present on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
										return;
									}//End of Confirm button on the confirmation pop up

								}//End of existence of the submit confirmation pop up check

								//Searching for the successful note addition message 
								String msg_NoteAddString = "Notes added Successfully";
								GuiTestObject msg_NoteAddSuccess = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_NoteAddString);
								if(msg_NoteAddSuccess!=null){
									msg_NoteAddSuccess.waitForExistence(30, 2);
									System.out.println("Notes addition is Successful");			

								}
								else{
									System.out.println("Notes addition is unsuccessful");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName,"Notes addition is unsuccessful" , Status.BC_FAILED);
									return;
								}//End of searching for the successful note addition message

								//Selecting Cancel button on Add Batch Note pop-up		
								GuiTestObject button_Cancel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Cancel");
								if(button_Cancel!= null){
									button_Cancel.waitForExistence(10, 2);
									button_Cancel.click();
									sleep(15);
								}
								else{
									System.out.println("Cancel button is absent in Add Batch Note pop-up	");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent in Add Batch Note pop-up	", Status.BC_FAILED);
									return;
								}//End of Cancel button on the add batch note pop-up
							}//End of else if for submit button enabled validation


						}//End of if for submit add batch note button on add batch note pop-up confirmation window
						else{
							System.out.println("Submit button is absent on add batch note pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Submit button is absent on add batch note pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for submit button on add batch note pop-up check					

					}//End of if for the add batch note confirm action pop up
					else{
						System.out.println("Add Batch Note confirm action popup is absent after clicking Submit button");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Add Batch Note confirm action popup is absent after clicking Submit button", Status.BC_FAILED);
						return;
					}//End of else for the add batch note confirm action pop up
					
				}//End of else if for add note button enable/disable check

			}//End of if for Add Notes button existence check
			else{
				System.out.println("Add Notes button is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Add Notes button is absent in Batch List page", Status.BC_FAILED);
				return;
			}

			//Returning to the home tab as an exit point
			if(link_home().exists()
					|| link_home().ensureObjectIsVisible()){
				link_home().waitForExistence(20, 2);
				link_home().click();
				//Waiting for the batch list to populate on the batch list page and loading message to disappear
				for(int loop=0;loop<20;loop++){
					ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
					System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
					if(progressBar_LoadingList.size()>=1){
						for(int i=0;i<progressBar_LoadingList.size();i++){
							System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
							System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
						}
						GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
						System.out.println("Progressbar checking loopcount: "+loop);
						if(progressBar_Loading!=null){
							System.out.println("The batch list is still NOT populated");
							sleep(2);
							continue;					
						}
						else{
							System.out.println("The batch list is populated");
							break;
						}
					}//End of if for progress bar loading
					else{
						System.out.println("The batch list is populated");
						break;
					}//End of else for progress bar loading

				}//End of for statement to check the progress bar loading 
				//Checking the existence of refresh button at the welcome area on home page				
				GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
				if(button_RefreshAtHome!= null){
					button_RefreshAtHome.waitForExistence(20, 2);
					button_RefreshAtHome.ensureObjectIsVisible();
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Home tab is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Home tab is absent in Batch List Page", Status.BC_FAILED);
				return;
			}//End of returning to the home tab as an exit point


			//Component success message
			String cmpSuccessMsg = "Notes added to Selected Batch(s) have been successfully";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
		}
		catch(Exception e){			
			//		StackTraceElement[] sArr = e.getStackTrace();
			//		System.out.println(sArr[sArr.length-1]);
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}

	}//End of Execute Component

}//End of class
