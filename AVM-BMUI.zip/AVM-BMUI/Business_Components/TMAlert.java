package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.TMAlertHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class TMAlert extends TMAlertHelper
{
	/**
	 * Script Name   : <b>TMAlert</b>
	 * Generated     : <b>Feb 1, 2012 12:55:57 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/02/01
	 * @author sxghos1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "TxnAlert";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 0)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 0 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 0 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Home page
			 * ---Ending on Home Page
			 */

			
			String txnAlertMessage = "";
			//Declaring the batch alert message templates
			String txnAlertMessage1 = "Completed transactions are present that are at least";
			String txnAlertMessage2 = "Outstanding authorizations are present that are at least";
			String txnAlertMessage3 = "transactions are present that are not authorized due to missing Authorization Codes from your Processor." +
										" Please delete the transactions or call your processor for voice-authorization and edit the transactions" +
										" with new auth code.";
			String txnAlertMessage4 = "transactions for settlement doesn't match with transactions sent out for deposit.";
			String totaltxnAlertMessage = "";
			String totaltxnAlertMessageHome = "";
			
			//Searching for the transaction alert messages			
			ArrayList<GuiTestObject> list_SelectTxnAlertList = new ArrayList<GuiTestObject>();
			GuiTestObject table_TxnAlertGrid = null;
			txnAlertMessage = txnAlertMessage1;
			//Selecting the transaction alert
			RegularExpression regExTxnAlert1 = new RegularExpression("x-auto-[0-9].*",false);
			list_SelectTxnAlertList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnAlert1,"Html.A", ".text", txnAlertMessage);
			System.out.println("list_SelectTxnAlertList1 size: "+list_SelectTxnAlertList.size());
			if(list_SelectTxnAlertList.size()==0){
				txnAlertMessage = txnAlertMessage2;
				//Selecting the transaction alert
				RegularExpression regExTxnAlert2 = new RegularExpression("x-auto-[0-9].*",false);
				list_SelectTxnAlertList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnAlert2,"Html.A", ".text", txnAlertMessage);
				System.out.println("list_SelectTxnAlertList2 size: "+list_SelectTxnAlertList.size());
				if(list_SelectTxnAlertList.size()==0){
					txnAlertMessage = txnAlertMessage3;
					//Selecting the transaction alert
					RegularExpression regExTxnAlert3 = new RegularExpression("x-auto-[0-9].*",false);
					list_SelectTxnAlertList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnAlert3,"Html.A", ".text", txnAlertMessage);
					System.out.println("list_SelectTxnAlertList3 size: "+list_SelectTxnAlertList.size());	
					if(list_SelectTxnAlertList.size()==0){
						txnAlertMessage = txnAlertMessage4;
						//Selecting the transaction alert
						RegularExpression regExTxnAlert4 = new RegularExpression("x-auto-[0-9].*",false);
						list_SelectTxnAlertList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnAlert4,"Html.A", ".text", txnAlertMessage);
						System.out.println("list_SelectTxnAlertList3 size: "+list_SelectTxnAlertList.size());	
						//Checking for no transaction alert message
						if(list_SelectTxnAlertList.size()==0){
							System.out.println("Transaction Alert message of any of the 4 templates is not found on the Home page batch alert section");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Transaction alert message of any of the 4 templates is not found on the Home page batch alert section", Status.BC_FAILED);
							return;					
						}//End of Checking for no transaction alert message
						
					}//End of txnAlertMessage4 select
					
				}//End of txnAlertMessage3 select
				
			}//End of txnAlertMessage2 select

			table_TxnAlertGrid = list_SelectTxnAlertList.get(list_SelectTxnAlertList.size()-1);			
			
			//Checking the existence of the Alerts table on the home page
//			GuiTestObject table_TxnAlertGrid = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "Alerts");
			if(table_TxnAlertGrid!=null){
				//Selecting the transaction alert message supplied
				ArrayList<GuiTestObject>list_HomePageTxnAlertLink = Util.getGWTMappedObjects("Html.A", ".text", txnAlertMessage);
				System.out.println("list_HomePageTxnAlertLink size: "+list_HomePageTxnAlertLink.size());
				GuiTestObject link_HomeTxnAlert = null;
				
				//Checking the transaction alert message existence
				if(list_HomePageTxnAlertLink.size()<1){
					System.out.println("Transaction Alert message is not found on the Home page batch alert section");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction alert message is not found on the Home page batch alert section", Status.BC_FAILED);
					return;
				}
				else{
					for(int i=0;i<list_HomePageTxnAlertLink.size();i++){
						System.out.println("Text Value for position "+i+" is : "+list_HomePageTxnAlertLink.get(i).getProperty(".text").toString());
					}					
					link_HomeTxnAlert = list_HomePageTxnAlertLink.get(list_HomePageTxnAlertLink.size()-1);
					//Clicking the transaction alert message link
					if(link_HomeTxnAlert!=null){
						link_HomeTxnAlert.waitForExistence(20, 2);
						//Fetching the full transaction alert message on the home page
						totaltxnAlertMessageHome = link_HomeTxnAlert.getProperty(".text").toString();
						if(totaltxnAlertMessageHome.contains("(process as soon as possible)")){
							totaltxnAlertMessageHome = totaltxnAlertMessageHome.substring(0, totaltxnAlertMessageHome.indexOf("(process as soon as possible)")).trim();
						}//End of Fetching the full transaction alert message on the home page
						System.out.println("totaltxnAlertMessageHome: "+totaltxnAlertMessageHome);
						if(totaltxnAlertMessageHome.isEmpty()){
							System.out.println("Transaction alert message is irretrievable on the home page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Transaction alert message is irretrievable on the home page", Status.BC_FAILED);
							return;
						}
						link_HomeTxnAlert.click();
						
						//Waiting for the message details to populate on the transaction alert list page and loading message to disappear
						for(int loop=0;loop<20;loop++){
							ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
							System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
							if(progressBar_LoadingList.size()>=1){
								for(int i=0;i<progressBar_LoadingList.size();i++){
									System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
									System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
								}
								GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
								System.out.println("Progressbar checking loopcount: "+loop);
								if(progressBar_Loading!=null){
									System.out.println("The transaction alert message details is still NOT populated");
									sleep(2);
									continue;					
								}
								else{
									System.out.println("The transaction alert message details is populated");
									break;
								}
							}//End of if for progress bar loading
							else{
								System.out.println("The transaction alert message details is/are populated");
								break;
							}//End of else for progress bar loading
							
						}//End of for statement to check the progress bar loading 
				
						sleep(5);
						
						//Checking the existence of alert message on the top of alert details page except message type 
						if(!txnAlertMessage.equals(txnAlertMessage3)){
							//Checking for the existence of the transaction message alert on the top of the details page
							ArrayList<GuiTestObject> text_TxnAlertMsgList = Util.getGWTMappedObjects("Html.DIV", ".text", txnAlertMessage);
							GuiTestObject text_TxnAlertMsg = null;
							if(text_TxnAlertMsgList.size()>0){
								text_TxnAlertMsg = text_TxnAlertMsgList.get(text_TxnAlertMsgList.size()-1);
								
							}
							else{
								System.out.println("Transaction alert message is absent on the alert message details page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Transaction alert message is absent on the alert message details page", Status.BC_FAILED);
								return;
							}					
							
							if(text_TxnAlertMsg!=null){
								text_TxnAlertMsg.waitForExistence(10, 2);
								totaltxnAlertMessage = text_TxnAlertMsg.getProperty(".text").toString().trim();
								if(totaltxnAlertMessage.isEmpty()){
									System.out.println("Transaction alert message is irretrievable on the alert message details page");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Transaction alert message is irretrievable on the alert message details page", Status.BC_FAILED);
									return;
								}
								System.out.println("totaltxnAlertMessage: "+totaltxnAlertMessage);
								
								//Checking for transaction alert message mismatch on home and details page
								if(!totaltxnAlertMessage.equals(totaltxnAlertMessageHome)){
									String txnAlertFailureMsg = "Transaction alert message on home page \""+totaltxnAlertMessageHome+"\"" +
																	" is not matching with batch alert message on details page \""
																		+totaltxnAlertMessage+"\"";
									System.out.println(txnAlertFailureMsg);
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(BusinessComponentName, txnAlertFailureMsg, Status.BC_FAILED);
									return;
								}//End of Checking for transaction alert message mismatch on home and details page
								
								//Checking the existence of Return to home button on the alert message details page				
								GuiTestObject button_ReturnToHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Return To Home");
								if(button_ReturnToHome!= null){					
									button_ReturnToHome.waitForExistence(100, 2);
									button_ReturnToHome.ensureObjectIsVisible();	
									button_ReturnToHome.click();
									
									//Waiting for the message details to populate on the home page and loading message to disappear
									for(int loop=0;loop<20;loop++){
										ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
										System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
										if(progressBar_LoadingList.size()>=1){
											for(int i=0;i<progressBar_LoadingList.size();i++){
												System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
												System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
											}
											GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
											System.out.println("Progressbar checking loopcount: "+loop);
											if(progressBar_Loading!=null){
												System.out.println("The home page is still NOT populated");
												sleep(2);
												continue;					
											}
											else{
												System.out.println("The home page is populated");
												break;
											}
										}//End of if for progress bar loading
										else{
											System.out.println("The home page is/are populated");
											break;
										}//End of else for progress bar loading
										
									}//End of for statement to check the progress bar loading 
							
									sleep(5);
								}
								else{
									System.out.println("Return to Home button is absent in alert message details page");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo("UserLogon", "Return to Home button is absent in alert message details page", Status.BC_FAILED);
									return;
								}//End of Checking the existence of Return to home button at the alert message details page								
								
							}
							else{
								System.out.println("Transaction Alert message is not found on the alert message details page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Transaction Alert message is not found on the alert message details page", Status.BC_FAILED);
								return;
							}//End of Checking for the existence of the batch message alert on the top of the details page
							
						}//End of if Checking the existence of alert message on the top of alert details page except message type	
						else{
							//Checking the existence of Return to home button on the alert message details page				
							GuiTestObject button_ReturnToHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Return to Home");
							if(button_ReturnToHome!= null){					
								button_ReturnToHome.waitForExistence(100, 2);
								button_ReturnToHome.ensureObjectIsVisible();	
								button_ReturnToHome.click();
								
								//Waiting for the message details to populate on the home page and loading message to disappear
								for(int loop=0;loop<20;loop++){
									ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
									System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
									if(progressBar_LoadingList.size()>=1){
										for(int i=0;i<progressBar_LoadingList.size();i++){
											System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
											System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
										}
										GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
										System.out.println("Progressbar checking loopcount: "+loop);
										if(progressBar_Loading!=null){
											System.out.println("The home page is still NOT populated");
											sleep(2);
											continue;					
										}
										else{
											System.out.println("The home page is populated");
											break;
										}
									}//End of if for progress bar loading
									else{
										System.out.println("The home page is/are populated");
										break;
									}//End of else for progress bar loading
									
								}//End of for statement to check the progress bar loading 
						
								sleep(5);
							}
							else{
								System.out.println("Return to Home button is absent in alert message details page");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo("UserLogon", "Return to Home button is absent in alert message details page", Status.BC_FAILED);
								return;
							}//End of Checking the existence of Return to home button at the alert message details page
							
						}//End of else of if Checking the existence of alert message on the top of alert details page except message type
						
					}//End of if for transaction alert message 
					else{
						System.out.println("Transaction Alert message Link is not found on the Home page batch alert section");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Transaction Alert message Link is not found on the Home page batch alert section", Status.BC_FAILED);
						return;
						
					}//End of else for txn alert link click
					
				}//End of else for txn alert existence check		
				
			}//End of if for checking the txn alert message table
			else{
				System.out.println("Transaction Alert table is absent in Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Alert table is absent in Page", Status.BC_FAILED);
				return;
			}//End of else for checking the txn alert message table 				
			
			//Component success message
			String cmpSuccessMsg = "";
			if(txnAlertMessage.equals(txnAlertMessage3)){
				cmpSuccessMsg = "Transaction alert message \""+totaltxnAlertMessageHome+"\" link is found on the home page & can be opened";
				System.out.println(cmpSuccessMsg);
				CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
			}
			else{
				cmpSuccessMsg = "Transaction alert message \""+totaltxnAlertMessageHome+"\" link is found on the home page & can be opened " +
									"and matching with the alert details page message";
				System.out.println(cmpSuccessMsg);
				CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
			}
			
			
					

		}
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}


	}//End of ExecuteComponent
	
}//End of claass
