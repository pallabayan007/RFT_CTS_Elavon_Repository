package Business_Components;
import resources.Business_Components.UserLogoffHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxsouvi
 *� 2011, Cognizant Technology Solutions. All Rights Reserved. The information contained herein is subject to change without notice.
 */
public class UserLogoff extends UserLogoffHelper
{	
	/**
	 * Script Name   : <b>UserLogoff</b>
	 * Generated     : <b>Sep 5, 2011 9:13:02 AM</b>
	 * Subject   	 : 
	 * Test Purpose  : 
	 * /Requirement(s)
	 * Covered
	 * Original Host : WinXP Version2002 Service Pack 3
	 * Assumption(s) : 
	 * @since  2011/09/05
	 * @author sxsouvi
	 */
	
	boolean error = false;
	
	public void testMain(Object[] args) 
	{
		//Enter scenarioName and TestCaseName to execute this Script alone
		String BusinessComponentName = this.getClass().getName();
		setCurrentLogFilter(DISABLE_LOGGING);
		
		try
		{
			CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
			ExecuteComponent();
			CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
			
		}
		catch(Exception ex)
		{
			 CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing "+ BusinessComponentName,ex.toString(),Status.FAIL);
		}
		

	}//End of void testMain()
	
	//Executable user interface actions
	public void ExecuteComponent()
	{
		try{
			/*
			 * ---Starting from corresponding application active page
			 */
			//Clicking the logout link at the top of the page
//			Link_Logout().click(atPoint(3,10));
			
			
			//Checking the existence of the logout link 
			if(Link_Logout().exists()){
				Link_Logout().waitForExistence(20, 2);
				Link_Logout().click();
				sleep(5);
				TestObject[] logoutConfirm_buttonObject = getRootTestObject().find(atDescendant(".class","Html.BUTTON",".value","OK"));
				System.out.println("logoutConfirm_buttonObject.length: "+logoutConfirm_buttonObject.length);
				if (logoutConfirm_buttonObject.length>0){
					System.out.println("Inside if loop");
					GuiTestObject logoutConfirm_buttonField = (GuiTestObject)logoutConfirm_buttonObject[0];
					logoutConfirm_buttonField.waitForExistence(10,1);
					sleep(2);
					System.out.println("Log out confirm OK button found");
					logoutConfirm_buttonField.click();
					System.out.println("Log out confirm OK button clicked");
				}
				else{				
					System.out.println("Log out confirm OK button not found");
					error = true;					
//					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("UserLogoff", "Log out confirm OK button not found", Status.BC_FAILED);
//					return;
				}
				sleep(5);
				//Closing the browser
//				browser_htmlBrowser(document_elavonPortal(),MAY_EXIT).close();
				browser_htmlBrowser(document_elavonCentralAuthenti(),MAY_EXIT).close();
				System.out.println("Browser closed");
				sleep(1);
				
				/*
				 * Selecting the ok button on the browser close pop up confirmation
				 * in case of logging off from an active session
				 */
				if(okbutton().exists()){
					okbutton().click();
				}
				else{
					//Selecting Edit Cancel button			
					GuiTestObject button_BrowserCloseOK = (GuiTestObject)Util.getMappedObject("Html.DialogButton", ".text", "OK");
					if(button_BrowserCloseOK!= null){
						button_BrowserCloseOK.waitForExistence(10, 2);	
						button_BrowserCloseOK.click();
					}
					else{
						System.out.println("No OK button found to close the browser session");
//						error = true;
//						CRAFT_Report.LogInfo("UserLogoff", "No OK button found to close the browser session", Status.BC_FAILED);
					}
				}
			}
//			else if(browser_htmlBrowser(document_elavonCentralAuthenti(),MAY_EXIT).exists()){
			else{
				System.out.println("Log out confirm link not found/disabled");
				error = true;					
//				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("UserLogoff", "Log out confirm link not found/disabled", Status.BC_FAILED);
//				return;
				
				//Checking the existence of the logout link if not found then closing the browser
				TestObject[] currentBrowserlist = getRootTestObject().find(atDescendant(".class","Html.HtmlBrowser",".window",new RegularExpression("[0-9].*",false)));    
				BrowserTestObject currentBrowser = null;
				System.out.println("currentBrowserlist length:"+currentBrowserlist.length);
				
				if(currentBrowserlist.length>0){
					for(int loop=0;loop<currentBrowserlist.length;loop++){
				    	currentBrowser = (BrowserTestObject) currentBrowserlist[loop];
				    	if(currentBrowser!=null){
				    		if(currentBrowser.getProperty(".documentName").toString().contains("jazz")){
				    			currentBrowser.minimize();
				    			System.out.println("Window minimized with id:"+currentBrowser.getProperty(".window").toString());
				    			sleep(2);
				    		}
				    		else{
				    			System.out.println(currentBrowser.getProperty(".window").toString());
					    		currentBrowser.close();
					    		if(okbutton().exists()){
					    			okbutton().click();
					    		}
					    		else{
					    			//Selecting Edit Cancel button			
					    			GuiTestObject button_BrowserCloseOK = (GuiTestObject)Util.getMappedObject("Html.DialogButton", ".text", "OK");
					    			if(button_BrowserCloseOK!= null){
					    				button_BrowserCloseOK.waitForExistence(10, 2);	
					    				button_BrowserCloseOK.click();
					    			}
					    			else{
					    				System.out.println("No OK button found to close the browser session");					    									    			}
					    		}//End of if
					    		
				    		}//End of else
				    		
				    	}//End of if
				    	else{
				    		System.out.println("Null object found of browser type");
//				    		error = true;
//				    		CRAFT_Report.LogInfo("UserLogoff", "Null object found of browser type", Status.BC_FAILED);
				    		break;
				    	}
				    }//End of for
					
				}//End of if
				else{//Checking the existence of any open browser if not found then doing nothing
					System.out.println("No Active browser session found open");
					error = true;
//					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("UserLogoff", "No Active browser session found open", Status.BC_FAILED);
//					return;				
				}//End of Checking the existence of any open browser if not found then doing nothing
				
//				//Checking the existence of the logout link if not found then closing the browser
//				browser_htmlBrowser(document_elavonCentralAuthenti(),MAY_EXIT).close();
//				sleep(2);
//				
//				/*
//				 * Selecting the ok button on the browser close pop up confirmation
//				 * in case of logging off from an active session
//				 */
//				if(okbutton().exists()){
//					okbutton().click();
//				}
//				System.out.println("Log out confirm link not found/disabled");
//				error = true;
////				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo("UserLogoff", "Log out confirm link not found/disabled", Status.BC_FAILED);
////				return;
				
			}//End of Checking the existence of the logout link if not found the closing the browser	
			

			//Clicking the Ok button on the logout confirmation pop up
//			Link_Logout().click(atPoint(3,10));
//			button_LogoutConfirmOKbutton().waitForExistence(10, 1);
//			button_LogoutConfirmOKbutton().click();			
			
//			//Checking for successful application user log off
//			CRAFT_Report.LogInfo("UserLogoff", "User Logged Off & Closed Browser", Status.BC_PASSED);
			
			
			//Checking for successful application user log off
			if(error){
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
//				CRAFT_Report.LogInfo("UserLogoff", "User could not Log Off & Close Browser successfully", Status.BC_FAILED);
			}//End of if for successful log off checking
			else{
				CRAFT_Report.LogInfo("UserLogoff", "User Logged Off & Closed Browser", Status.BC_PASSED);
			}//End of else for successful log out checking

		}//End of try block
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}//End of catch block

	}//End of ExecuteComponenet
	
}//End of class

