package Business_Components;
import java.util.ArrayList;
import resources.Business_Components.UserLogonHelper;
import ApplicationProperties.EnvironmentVariables;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxsouvi
 *� 2011, Cognizant Technology Solutions. All Rights Reserved. The information contained herein is subject to change without notice.
 */
public class UserLogon extends UserLogonHelper
{	
	/**
	 * Script Name   : <b>UserLogon</b>
	 * Generated     : <b>Sep 9, 2011 3:29:33 AM</b>
	 * Subject   	 : 
	 * Test Purpose  : 
	 * /Requirement(s)
	 * Covered
	 * Original Host : WinXP Version2002 Service Pack 3
	 * Assumption(s) : 
	 * @since  2011/09/09
	 * @author sxsouvi
	 */
	
	boolean error = false;	
	
	public void testMain(Object[] args) 
	{
		//Enter business component
		String BusinessComponentName = this.getClass().getName();
//		setCurrentLogFilter(DISABLE_LOGGING);
		try
		{
			if (args.length < 2)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 2 arg, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 2 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}		       		
			}

		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
		}
		
	}//End of testMain()
	
	public void ExecuteComponent(Object[] userId)
	{
//		System.out.println("Inside User Log on Execute");
		try{
			/*
			 * ---Starting from log on page
			 */
			//Looping through different user ids supplied
			for (int i = 0; i < userId.length; ++i)
			{
				//Closing any unwanted opened browser
				TestObject[] currentBrowserlist = getRootTestObject().find(atDescendant(".class","Html.HtmlBrowser",".window",new RegularExpression("[0-9].*",false)));    
				BrowserTestObject currentBrowser = null;
				System.out.println("currentBrowserlist length:"+currentBrowserlist.length);
				
				if(currentBrowserlist.length>0){
					for(int loop=0;loop<currentBrowserlist.length;loop++){
				    	currentBrowser = (BrowserTestObject) currentBrowserlist[loop];
				    	if(currentBrowser!=null){
				    		if(currentBrowser.getProperty(".documentName").toString().contains("jazz")){
				    			currentBrowser.minimize();
				    			System.out.println("Window minimized with id:"+currentBrowser.getProperty(".window").toString());
				    			sleep(2);
				    		}
				    		else{
				    			System.out.println(currentBrowser.getProperty(".window").toString());
					    		currentBrowser.close();
					    		if(okbutton().exists()){
					    			okbutton().click();
					    		}
					    		else{
					    			//Selecting Edit Cancel button			
					    			GuiTestObject button_BrowserCloseOK = (GuiTestObject)Util.getMappedObject("Html.DialogButton", ".text", "OK");
					    			if(button_BrowserCloseOK!= null){
					    				button_BrowserCloseOK.waitForExistence(10, 2);	
					    				button_BrowserCloseOK.click();
					    			}
					    			else{
					    				System.out.println("No OK button found to close the browser session");					    				
					    			}
					    		}
				    		}
				    		
				    	}
				    	else{
				    		System.out.println("Null object found of browser type");
				    		break;
				    	}
				    }//End of for
				}
				else{
					System.out.println("No active open browser window found");
				}//End of Closing any unwanted opened browser
			    
				System.out.println( " userId["+i+"] = "+userId[i]);				
				//Opening the application 
				startBrowser(EnvironmentVariables.AVMUrl);
//				System.out.println("After start browser");
				sleep(20);
				
				browser_htmlBrowser(document_elavonCentralAuthenti(),MAY_EXIT).maximize();
				sleep(2);
				
//				text_username().waitForExistence(20, 2);				
//				//Checking for text box and button existence on log on page
//				if(!text_username().exists()
//						|| !text_password().exists()
//						|| !link_submit().exists()){
//					System.out.println("Inside pwd text box check");
//					error = true;	
//					Util.scenarioStatus = false;
//					CRAFT_Report.LogInfo("UserLogon", "Logon fields absent for user "+userId[i], Status.BC_FAILED);
//					return;
//				}//End of if for log on page checking
//				else{
//					text_username().setText((String)userId[i]);
//					text_password().setText((String)userId[i+1]);
//					link_submit().click();
//					sleep(10);
//				}//End of if for log on page checking
				
				//Checking the existence of user name at the log on page				
				TextGuiTestObject text_UserName = (TextGuiTestObject)Util.getMappedObject("Html.INPUT.text", ".id", "username");
				if(text_UserName!= null){
					text_UserName.waitForExistence(100, 2);
					text_UserName.ensureObjectIsVisible();
					text_UserName.setText((String)userId[i]);
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("UserLogon", "User Name text box is absent in User logon page", Status.BC_FAILED);
					return;
				}
				//Checking the existence of password at the log on page				
				TextGuiTestObject text_Pwd = (TextGuiTestObject)Util.getMappedObject("Html.INPUT.password", ".id", "password");
				if(text_Pwd!= null){
					text_Pwd.waitForExistence(100, 2);
					text_Pwd.ensureObjectIsVisible();
					text_Pwd.setText((String)userId[i+1]);
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("UserLogon", "Password text box is absent in User logon page", Status.BC_FAILED);
					return;
				}
				//Checking the existence of submit button at the log on page				
				GuiTestObject link_Submit = (GuiTestObject)Util.getMappedObject("Html.A", ".text", "Submit");
				if(link_Submit!= null){
					link_Submit.waitForExistence(100, 2);
					link_Submit.ensureObjectIsVisible();
					link_Submit.click();
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("UserLogon", "Submit link is absent in User logon page", Status.BC_FAILED);
					return;
				}
				
				//Checking the existence of Login Failed message on the log on page	
				sleep(10);
				GuiTestObject text_LoginFailed = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "Login failed.");
				if(text_LoginFailed!= null){
					text_LoginFailed.waitForExistence(10, 2);	
					if(text_LoginFailed.exists()
							&& text_LoginFailed.ensureObjectIsVisible()){
						System.out.println("Login Failed due to wrong User Name/Password");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo("UserLogon", "Login Failed due to wrong User Name/Password", Status.BC_FAILED);
						return;
					}
										
				}
				else{
					System.out.println("Login successfull");
				}
				
				sleep(50);
				
//				//Waiting for the home page to populate
//				for(int loop=0;loop<20;loop++){
//					ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
////					ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
//					System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
//					if(progressBar_LoadingList.size()>=1){
//						for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
//							System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
//							System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
//						}
//						GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
//						System.out.println("Progressbar checking loopcount: "+loop);
//						if(progressBar_Loading!=null){
//							System.out.println("The home page is still NOT populated");
//							sleep(2);
//							continue;					
//						}
//						else{
//							System.out.println("The home page is populated");
//							break;
//						}
//					}//End of if for progress bar loading
//					else{
//						System.out.println("The Home page is populated");
//						break;
//					}//End of else for progress bar loading
//					
//				}//End of for statement to check the progress bar loading 
//				
//				sleep(30);
				
				//Checking the existence of the welcome message at the welcome area on home page				
				GuiTestObject text_WelcomeMsg = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "Welcome to Elavon Global Gateway");
				if(text_WelcomeMsg!= null){					
					text_WelcomeMsg.waitForExistence(100, 2);
					text_WelcomeMsg.ensureObjectIsVisible();				
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("UserLogon", "Welcome message is absent in home page after User logon", Status.BC_FAILED);
					return;
				}
				
				
//				//Checking the existence of refresh button at the welcome area on home page				
//				GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Refresh");
//				if(button_RefreshAtHome!= null){					
//					button_RefreshAtHome.waitForExistence(100, 2);
//					button_RefreshAtHome.ensureObjectIsVisible();				
//				}
//				else{
//					error = true;
//					Util.scenarioStatus = false;
//					CRAFT_Report.LogInfo("UserLogon", "Refresh button is absent in home page after User logon", Status.BC_FAILED);
//					return;
//				}
				
//				button_refreshButtonAtHome().waitForExistence(90,2);
				
//				//Checking the existence of refresh button at the welcome area on home page
//				if(!button_RefreshAtHome().exists()){
//					error = true;	
//					Util.scenarioStatus = false;
//					CRAFT_Report.LogInfo("UserLogon", "Home page unavailable after Logon for user "+userId[i], Status.BC_FAILED);
//					return;
//				
//				}//End of if for refresh button checking
//				else{
//					button_refreshButtonAtHome().ensureObjectIsVisible();
//					
//				}//End of else for home tab checking

				//Checking for successful application user log on
				if(error){
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("UserLogon", "Applciation user Log on with user "+userId[i], Status.BC_FAILED);
				}//End of if for successful log on checking
				else{
					CRAFT_Report.LogInfo("UserLogon", "Application user Log on with user "+userId[i], Status.BC_PASSED);
				}//End of else for successful log on checking

				i=i+1;

			}//End of for statement for user looping
			System.out.println("End of Application user Log on execute");

		}//End of try for business component
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}
	}//End of ExecuteComponent()

}//End of class UserLogon

