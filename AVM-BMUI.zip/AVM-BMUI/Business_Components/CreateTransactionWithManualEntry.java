package Business_Components;
import resources.Business_Components.CreateTransactionWithManualEntryHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import java.util.ArrayList;
import java.util.Random;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxsouvi
 */
public class CreateTransactionWithManualEntry extends CreateTransactionWithManualEntryHelper
{
	/**
	 * Script Name   : <b>CreateCase</b>
	 * Generated     : <b>Sep 5, 2011 9:02:46 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/09/05
	 * @author sxsouvi
	 */
	
	boolean error = false;
	protected String transactionId = "";
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
		
	
	public String testMain(Object[] args) 
	{
		//Enter business component
		String BusinessComponentName = this.getClass().getName();
		
		try
		{
			if (args.length < 8)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 8 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 8 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return "";
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error||transactionId.isEmpty()){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return "";
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return "";
		}
		
		return transactionId;		
	}//End of main method
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		//Variable declaration section
//		Random randomGenerator = new Random();
//		String entityId = "COGBMUIBtchElavonretail - 1000789";
//		String site = "defect 22503 - 1009925";
//		String mandatoryFlag = (String) args[0];

		String entityId = (String) args[1];
		String site = (String) args[2];
		System.out.println("site: "+site);
		String paymentType = (String) args[3];
		String tranType = (String) args[4];
		String accNo = (String) args[5];
		String expDate = (String) args[6];
//		String tranAmt = Integer.toString(randomGenerator.nextInt(1000)+100);
		String tranAmt = (String) args[7];
		
		
		try{
			/*
			 * ---Starting from Transaction Management home page, i.e. , transaction search tab
			 * ---Ending on Transaction Management home page, i.e. , transaction search tab
			 */
			
			//Selecting the transaction Management tab
			link_transactionManagement().waitForExistence(10, 2);
			link_transactionManagement().click();
			sleep(5);
//			button_transactionSearchbutton().click();
			
			//Selecting the create transaction sub menu 
//			button_createTransactionbutton().waitForExistence(5, 2);
//			button_createTransactionbutton().click();
			GuiTestObject submenu_CreateTxn = Util.getMappedObject("Html.BUTTON", ".value", "Create Transaction");
			if(submenu_CreateTxn!= null){
				submenu_CreateTxn.waitForExistence(10, 2);
				submenu_CreateTxn.click();				
				sleep(5);
			}
			else{
				System.out.println("Mandatory SubMenu item Create Transaction is absent under transaction management tab");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory SubMenu item Create Transaction is absent under transaction management tab", Status.BC_FAILED);
				return;
			}
			
			
			//Selecting entity			
			TextGuiTestObject text_Entity = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "entityTO");
			if(text_Entity!= null){
				text_Entity.waitForExistence(10, 2);
				text_Entity.click();
				text_Entity.setText(entityId);
				sleep(2);
				//Selecting the entity from the drop down
//				RegularExpression regExEntityDropDwn = new RegularExpression("x-auto-[0-9].*",false);
//				ArrayList<GuiTestObject> list_EntityList = Util.getGWTMappedObjects("Html.DIV",".id",regExEntityDropDwn, "Html.DIV",".text", entityId);
				ArrayList<GuiTestObject> list_EntityList = Util.getGWTMappedObjects("Html.DIV",".text", entityId);
				GuiTestObject list_Entity = list_EntityList.get(list_EntityList.size()-1);
//				TextGuiTestObject list_site = (TextGuiTestObject) Util.getMappedObject("Html.DIV", ".text", "Cut-Off Monthly");
				for(int i=0;i<list_EntityList.size();i++){
					System.out.println("list_EntityList: "+list_EntityList.get(i).getProperty(".text").toString());
				}
				if(list_Entity!=null){
					System.out.println("Inside the entity dropdown list");	
					list_Entity.click();
					sleep(5);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputChars("{ExtDown}{ExtDown}{ENTER}");
				}
				else{
					System.out.println("Mandatory Field(s) Entity list dropdown not found on create transaction page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) Entity list drop down not found on create transaction page", Status.BC_FAILED);
					return;
				}//End of selection the frequency from the drop down
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) Entity is absent in create transaction page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Site			
			TextGuiTestObject text_Site = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "terminalTO");
			if(text_Site!= null){
				text_Site.waitForExistence(10, 2);
				text_Site.click();
				text_Site.setText(site);
				sleep(2);
				//Selecting the frequency from the drop down
//				RegularExpression regExFreqDropDwn = new RegularExpression("x-auto-[0-9].*",false);
//				ArrayList<GuiTestObject> list_siteList = Util.getGWTMappedObjects("Html.DIV",".id",regExFreqDropDwn, "Html.DIV",".text", site);
				ArrayList<GuiTestObject> list_siteList = Util.getGWTMappedObjects("Html.DIV",".text", site);
				GuiTestObject list_site = list_siteList.get(list_siteList.size()-1);
//				TextGuiTestObject list_site = (TextGuiTestObject) Util.getMappedObject("Html.DIV", ".text", "Cut-Off Monthly");
				for(int i=0;i<list_siteList.size();i++){
					System.out.println("list_siteList: "+list_siteList.get(i).getProperty(".text").toString());
				}
				if(list_site!=null){
					System.out.println("Inside the site dropdown list");	
					list_site.click();
					sleep(5);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputChars("{ExtDown}{ExtDown}{ENTER}");
					//Waiting for the home page to populate
					for(int loop=0;loop<20;loop++){
						ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//						ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
						System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
						if(progressBar_LoadingList.size()>=1){
							for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
								System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
								System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
							}
							GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
							System.out.println("Progressbar checking loopcount: "+loop);
							if(progressBar_Loading!=null){
								System.out.println("The home page is still NOT populated");
								sleep(2);
								continue;					
							}
							else{
								System.out.println("The home page is populated");
								break;
							}
						}//End of if for progress bar loading
						else{
							System.out.println("The Home page is populated");
							break;
						}//End of else for progress bar loading
						
					}//End of for statement to check the progress bar loading 
					
					sleep(5);					
				}
				else{
					System.out.println("Mandatory Field(s) Site list dropdown not found on create transaction page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) Site list drop down not found on create transaction page", Status.BC_FAILED);
					return;
				}//End of selection the frequency from the drop down
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");					
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) Site is absent in create transaction page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Payment type
			TextGuiTestObject text_PaymentType = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "paymentTypeTO");
			if(text_PaymentType!= null){
				text_PaymentType.waitForExistence(10, 2);
				text_PaymentType.click();
				sleep(1);
//				//Selecting the Credit Card from the select box 
//				GuiTestObject list_PaymentType = (GuiTestObject) Util.getGWTMappedObject("Html.DIV", ".text", paymentType);
//				if (list_PaymentType!= null){
//					list_PaymentType.click();
//					System.out.println("Clicked on CREDIT CARD from list box");
//				}
//				else{
//					System.out.println("Select list for payment type not found");
//					error = true;
//					Util.scenarioStatus = false;
//					CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Select list for payment type not found", Status.BC_FAILED);
//					return;
//				}
				//Selecting the Credit Card from the select box 
				int paymentTypeListItemCount = 0;
				ArrayList<GuiTestObject> list_PaymentTypeList = Util.getGWTMappedObjects("Html.DIV", ".text", paymentType);
				GuiTestObject list_PaymentType = null;
				System.out.println("list_PaymentTypeList size: "+list_PaymentTypeList.size());
				for(int i=0;i<list_PaymentTypeList.size();i++){
					System.out.println("list_PaymentTypeList Text: "+list_PaymentTypeList.get(i).getProperty(".text").toString());
					System.out.println("list_PaymentTypeList Id: "+list_PaymentTypeList.get(i).getProperty(".id").toString());
				}
				
				//Checking whether the payment type drop down exists or not
				if(list_PaymentTypeList.size()!=0){
					list_PaymentType = list_PaymentTypeList.get(list_PaymentTypeList.size()-1);
					//Checking whether the payment type drop down exists & consists any value or not
					if (list_PaymentType!= null){			
						String paymentTypeList = list_PaymentType.getProperty(".text").toString();
						paymentTypeListItemCount = (int) Util.stringWordCount(paymentTypeList, " ");
						
						//Checking whether the payment type drop down consists any value or not
						if(paymentTypeListItemCount==0){
							System.out.println("Select list drop-down for payment type doesn't contain any value");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Select list drop-down for payment type doesn't contain any value", Status.BC_FAILED);
							return;
						}
						else{
							System.out.println("paymentTypeListItemCount: "+paymentTypeListItemCount);
							//Selecting the payment type by keystrokes and checking the corresponding values 
							for(int loop=0; loop<paymentTypeListItemCount; loop++){
								text_PaymentType.click();
								browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtDown}{ENTER}");
							    sleep(1);
							    System.out.println(text_PaymentType.getProperty(".value").toString());
								if(text_PaymentType.getProperty(".value").toString().equalsIgnoreCase(paymentType)){
							    	break;
							    }
						    }//End of for statement
						}//End of Checking whether the payment type drop down consists any value or not
					}
					else{
						System.out.println("Select list for payment type not found");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Select list for payment type not found", Status.BC_FAILED);
						return;
					}//End of Checking whether the payment type drop down exists & consists any value or not
					
				}
				else{
					System.out.println("Select list for payment type drop down not found");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Select list for payment type drop down not found", Status.BC_FAILED);
					return;
				}//End of Checking whether the payment type drop down exists or not
//				sleep(5);
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) Payment Type is absent in create transaction page", Status.BC_FAILED);
				return;
			}//End of Selecting Payment type
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);
			
			//Selecting Transaction type
			TextGuiTestObject text_TranType = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "tranTypeTO");
			if(text_TranType!= null){
				text_TranType.waitForExistence(10, 2);
				text_TranType.click();
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtDown}{ExtDown}{ExtDown}{ExtDown}{ENTER}");
				//Selecting the Credit Card from the select box 
				int txnTypeListItemCount = 0;
				ArrayList<GuiTestObject> list_TxnTypeList = Util.getGWTMappedObjects("Html.DIV", ".text", tranType);
				GuiTestObject list_TxnType = null;
				System.out.println("list_TxnTypeList size: "+list_TxnTypeList.size());
				for(int i=0;i<list_TxnTypeList.size();i++){
					System.out.println("list_TxnTypeList Text: "+list_TxnTypeList.get(i).getProperty(".text").toString());
					System.out.println("list_TxnTypeList Id: "+list_TxnTypeList.get(i).getProperty(".id").toString());
				}
				
				//Checking whether the Transaction Type drop down exists or not
				if(list_TxnTypeList.size()!=0){
					list_TxnType = list_TxnTypeList.get(list_TxnTypeList.size()-1);
					//Checking whether the Transaction Type drop down exists & consists any value or not
					if (list_TxnType!= null){			
						String txnTypeList = list_TxnType.getProperty(".text").toString();
						txnTypeListItemCount = (int) Util.stringWordCount(txnTypeList, " ");
						
						//Checking whether the Transaction Type drop down consists any value or not
						if(txnTypeListItemCount==0){
							System.out.println("Select list drop-down for Transaction Type doesn't contain any value");
//							error = true;
//							Util.scenarioStatus = false;
//							CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Select list drop-down for Transaction Type doesn't contain any value", Status.BC_FAILED);
//							return;
						}
						else{
							System.out.println("txnTypeListItemCount: "+txnTypeListItemCount);
							//Selecting the Transaction Type by keystrokes and checking the corresponding values 
							for(int loop=0; loop<txnTypeListItemCount; loop++){
								text_TranType.click();
								browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtDown}{ENTER}");
							    sleep(1);
							    System.out.println(text_TranType.getProperty(".value").toString());
								if(text_TranType.getProperty(".value").toString().equalsIgnoreCase(tranType)){
							    	break;
							    }
						    }//End of for statement
						}//End of Checking whether the Transaction Type drop down consists any value or not
					}
					else{
						System.out.println("Select list for Transaction Type not found");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Select list for Transaction Type not found", Status.BC_FAILED);
						return;
					}//End of Checking whether the Transaction Type drop down exists & consists any value or not
					
				}
				else{
					System.out.println("Select list for Transaction Type drop down not found");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Select list for Transaction Type drop down not found", Status.BC_FAILED);
					return;
				}//End of Checking whether the Transaction Type drop down exists or not
//				sleep(5);
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) Transaction Type is absent in create transaction page", Status.BC_FAILED);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtDown}{ExtDown}{ExtDown}{ExtDown}{Num~}");
				return;
			}//End of selecting Transaction Type
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);
			
			//Selecting a/c no			
			TextGuiTestObject text_AccNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "accountNo");
			if(text_AccNo!= null){
				text_AccNo.waitForExistence(10, 2);
				text_AccNo.click();
				text_AccNo.setText(accNo);
				sleep(2);
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) A/c No is absent in create transaction page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Exp Date			
			TextGuiTestObject text_ExpDate = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "expDate");
			if(text_ExpDate!= null){
				text_ExpDate.waitForExistence(10, 2);
				text_ExpDate.setText(expDate);
				sleep(2);
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) Exp Date is absent in create transaction page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Transaction Amount			
			TextGuiTestObject text_TranAmt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "transactionAmount");
			if(text_TranAmt!= null){
				text_TranAmt.waitForExistence(10, 2);
				text_TranAmt.setText(tranAmt);
				sleep(2);
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory field(s) Transaction Amount is absent in create transaction page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Submit button			
			GuiTestObject button_Submit = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
			if(button_Submit!= null){
				button_Submit.click();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Submit button is absent in create transaction page", Status.BC_FAILED);
				return;
			}
			sleep(30);
			
			//Selecting View Receipt button			
			GuiTestObject button_ViewReceipt = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "View Receipt");
			if(button_ViewReceipt!= null){
				button_ViewReceipt.waitForExistence(10, 2);
				button_ViewReceipt.click();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "View Receipt button is absent in create transaction page", Status.BC_FAILED);
				return;
			}
			sleep(5);
			
			//Fetching the transaction id from the view receipt pop up 
//			if (Util.getGWTMappedObject("Html.DIV", ".name", "transactionId").exists()
//					|| Util.getGWTMappedObject("Html.DIV", ".name", "transactionId")!= null){
//				sleep(2);
//				transactionId = (String) Util.getGWTMappedObject("Html.DIV", ".name", "transactionId").getProperty(".value");
//				System.out.println("Tran ID: "+transactionId);
//			}
//			else if(Util.getGWTMappedObject("Html.DIV", ".name", "transactionId")== null){
//				System.out.println("Transaction Id not found on confirmation pop up page");
//				error = true;
//				Util.scenarioStatus = false;
////				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Transaction id not found on view receipt page", Status.BC_FAILED);
//				return;
//			}
			
			GuiTestObject button_DoneViewReceipt = (GuiTestObject)Util.getMappedObject("Html.INPUT.text", ".name", "transactionId");
			if(button_DoneViewReceipt!= null){
				button_DoneViewReceipt.waitForExistence(10, 2);
				transactionId = (String) button_DoneViewReceipt.getProperty(".value");
				System.out.println("Tran ID: "+transactionId);
//				button_DoneViewReceipt.click();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Done button is absent in view receipt page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Done button on the View Receipt
//			if(Util.getMappedObject("Html.BUTTON", ".value", "Done")!= null){
//				GuiTestObject button_DoneViewReceipt = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Done");
//				button_DoneViewReceipt.click();
//			}
//			else{
//				error = true;
//				Util.scenarioStatus = false;
////				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Done button is absent in view receipt page", Status.BC_FAILED);
//				return;
//			}
			browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}{TAB}{ENTER}");
			sleep(5);
			
			//Selecting Done button on the transaction confirmation page			
			GuiTestObject button_Done = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Done");
			if(button_Done!= null){
				button_Done.click();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Done button is absent in transaction confirmation page", Status.BC_FAILED);
				return;
			}
			sleep(5);
			
			//Selecting the transaction search tab to end there
//			button_transactionSearchbutton().click();
//			sleep(5);
			GuiTestObject submenu_TxnSearch = Util.getMappedObject("Html.BUTTON", ".value", "Transaction Search");
			if(submenu_TxnSearch!= null){
				submenu_TxnSearch.waitForExistence(10, 2);
				submenu_TxnSearch.click();				
				sleep(5);
			}
			else{
				System.out.println("Mandatory SubMenu item Transaction Search is absent under transaction management tab");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("Create Transaction-Manual Entry", "Mandatory SubMenu item Transaction Search is absent under transaction management tab", Status.BC_FAILED);
				return;
			}
			
			//Component success message
			
			if(!transactionId.isEmpty()){
				CRAFT_Report.LogInfo(BusinessComponentName, "Transaction for manual entry created successfully with id: "+transactionId, Status.BC_PASSED);
			}
			else if(transactionId.isEmpty()){
				CRAFT_Report.LogInfo(BusinessComponentName, "Transaction for manual entry not created successfully", Status.BC_FAILED);
			}
		}//End of try for business component
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}//End of catch for business component


	}//End of ExecuteComponenet
}

