package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.CNFEOffsetTxnHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class CNFEOffsetTxn extends CNFEOffsetTxnHelper
{
	/**
	 * Script Name   : <b>CNFEOffsetTxn</b>
	 * Generated     : <b>Dec 30, 2011 6:12:21 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/12/30
	 * @author axbane1
	 */
	
	boolean error = false;
	protected String transactionId = "";
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "CNFEOffsetTxn";
	
	public String testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 1)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 1 arg, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 1 input, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return "";
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error||transactionId.isEmpty()){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return "";
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return "";
		}
		
		return transactionId;		
	}//End of main method
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		// TODO Insert code here
		
		//Place your Code here
		
		try{
			/*
			 * ---Starting from Txn List page,Transaction Search -> Transaction List
			 * ---Ending on Home page, i.e. , Home tab
			 */
			
			String refNo = (String) args[0];
			String selectTxnString = "";
			String searchedTxnString = "";
			String tranType = "";
			String offsetTranType = "";
			
			//Selecting the records with Approved status to edit in transaction search list page
			ArrayList<GuiTestObject> list_SelectTxnSearchResultList = new ArrayList<GuiTestObject>();
			//Assigning the select string
			if(!refNo.isEmpty()){
				selectTxnString = refNo;
				RegularExpression regExTxnSearchUSD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
				list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchUSD,"Html.TABLE", ".text", selectTxnString);
				System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
				if(list_SelectTxnSearchResultList.size()<1){
					System.out.println("No Transaction found on Transaction List page");	
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No Transaction found on Transaction List page", Status.BC_FAILED);
					return;
				}
			}
			else{
				selectTxnString = "USD";
				//Selecting the records to edit in transaction search list page
				RegularExpression regExTxnSearchUSD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
				list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchUSD,"Html.TABLE", ".text", selectTxnString);
				System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
				if(list_SelectTxnSearchResultList.size()==0){
					selectTxnString = "GBP";
					//Selecting the records to edit in transaction search list page
					RegularExpression regExTxnSearchGBP = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
					list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchGBP,"Html.TABLE", ".text", selectTxnString);
					System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
					if(list_SelectTxnSearchResultList.size()==0){
						selectTxnString = "AUD";
						//Selecting the records to edit in transaction search list page
						RegularExpression regExTxnSearchAUD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
						list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchAUD,"Html.TABLE", ".text", selectTxnString);
						System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
						if(list_SelectTxnSearchResultList.size()==0){
							selectTxnString = "EUR";
							//Selecting the records to edit in transaction search list page
							RegularExpression regExTxnSearchEUR = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
							list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchEUR,"Html.TABLE", ".text", selectTxnString);
							System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
							if(list_SelectTxnSearchResultList.size()==0){
								selectTxnString = "CAD";
								//Selecting the records to edit in transaction search list page
								RegularExpression regExTxnSearchCAD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
								list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchCAD,"Html.TABLE", ".text", selectTxnString);
								System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());	
								if(list_SelectTxnSearchResultList.size()<1){
									System.out.println("No Transaction found on Transaction List page");	
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "No Transaction found on Transaction List page", Status.BC_FAILED);
									return;
								}
							}//End of CAD select
						}//End of EUR select
					}//End of AUD select
				}//End of GBP select
			}//End of else for select string assignment
			
			
			
			
			//Setting the Txn select string in case of no ref no.
			if(refNo.isEmpty()){			
				searchedTxnString = list_SelectTxnSearchResultList.get(0).getProperty(".text").toString();
				System.out.println("searchedTxnString: "+searchedTxnString);
//				searchedTxnString = list_SelectTxnSearchResultList.get(0).getProperty(".text").toString();
				searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf(":")+6, searchedTxnString.length()).trim();
				searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();				
				refNo = searchedTxnString;
				System.out.println("Ref No: "+refNo);				
			}//End of if for Setting the Txn select string in case of no ref no.
			
			//Fetching the Transaction Type of the selected transaction from the transaction list page			
			searchedTxnString = list_SelectTxnSearchResultList.get(0).getProperty(".text").toString();
			System.out.println("searchedTxnString: "+searchedTxnString);
			searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf(refNo)+refNo.length()+1, searchedTxnString.length()).trim();
			searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
			tranType = searchedTxnString;
			System.out.println("tran type: "+tranType);
			if(tranType.isEmpty()){
				System.out.println("No Transaction Type found in Transaction Search List Page for transaction with Reference No.: "+refNo);
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No Transaction Type found in Transaction Search List Page for transaction with Reference No.: "+refNo, Status.BC_FAILED);
				return;
			}//End of Fetching the Transaction Type of the selected transaction from the transaction list page
			
			
			//Selecting the first Txn in list by clicking its ref no link			
			ArrayList<GuiTestObject> list_TxnSearchResultList = Util.getGWTMappedObjects("Html.A", ".text", refNo);
			GuiTestObject link_RefNo = null;
			System.out.println("list_TxnSearchResultList size: "+list_TxnSearchResultList.size());
			if(list_TxnSearchResultList.size()>0){
				link_RefNo = list_TxnSearchResultList.get(0);
				//Checking for the existence of the ref no link
				if(link_RefNo != null){
					link_RefNo.waitForExistence(20, 2);
					link_RefNo.click();
					sleep(10);
				}
				else{
					System.out.println("No matching link found in Transaction Search List Page for Reference No.: "+refNo);
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching link found in Transaction Search List Page for Reference No.: "+refNo, Status.BC_FAILED);
					return;
				}//End of Checking for the existence of the ref no link
			}//End of if for ref no link check
			else{
				System.out.println("No matching record found in Transaction Search List Page for Reference No.: "+refNo);
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Transaction Search List Page for Reference No.: "+refNo, Status.BC_FAILED);
				return;
			}
	
			//Selecting CNFE button			
			GuiTestObject button_CNFETxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Create New From Existing");
			if(button_CNFETxn!= null){
				button_CNFETxn.waitForExistence(10, 2);
				button_CNFETxn.ensureObjectIsVisible();
				//Checking whether the CNFE button is enabled or disabled
				if(button_CNFETxn.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("CNFE button is disabled in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "CNFE button is disabled in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
				else{
					System.out.println("CNFE button is enabled in View Transaction Details Page");
					button_CNFETxn.click();
					sleep(2);
				}			
				//End of Checking whether the CNFE button is enabled or disabled
			}
			else{
				System.out.println("CNFE button is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "CNFE button is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}

			//Checking for the existence of the CNFE Type Pop up 
			GuiTestObject popup_CNFEType = Util.getMappedObject("Html.DIV", ".text", "Transaction Entry");
			if(popup_CNFEType!=null){
				//Selecting Cancel button to cancel the CNFE Type pop up 			
				GuiTestObject button_CancelCNFEPopup = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
				if(button_CancelCNFEPopup!= null){
					button_CancelCNFEPopup.waitForExistence(10, 2);
					button_CancelCNFEPopup.click();
					sleep(2);
					button_CNFETxn.waitForExistence(10,2);
				}
				else{
					System.out.println("Cancel CNFE Type button is absent on batch delete pop-up confirmation window");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Cancel CNFE Type button is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
					return;
				}//End of else for cancel button existence check
				
				//Selecting the CNFE button again to make the CNFE Type pop up re-appear
				button_CNFETxn.click();
				sleep(10);
			}//End of if for the CNFE Type pop up
			else{
				System.out.println("CNFE Type pop up is absent after clicking CNFE button");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "CNFE Type pop up is absent after clicking CNFE button", Status.BC_FAILED);
				return;
			}//End of else for the CNFE Type pop up
		
			//Selecting the offset radio button on CNFE Type pop up 				
//			RegularExpression regExCNFEType = new RegularExpression("x-auto-[0-9].*",false);
//			ArrayList<GuiTestObject> radiobutton_CNFETypeList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".id",regExCNFEType,"Html.BUTTON", ".value", "Submit");
			ArrayList<GuiTestObject> radiobutton_CNFETypeList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id","offset","Html.INPUT.radio", ".value", "null");
			System.out.println("radiobutton_CNFETypeList size: "+radiobutton_CNFETypeList.size());
			GuiTestObject radiobutton_CNFEType = null;
			radiobutton_CNFEType = radiobutton_CNFETypeList.get(0);
			if(radiobutton_CNFEType!= null){
				radiobutton_CNFEType.waitForExistence(10, 2);
				radiobutton_CNFEType.click();
				sleep(2);				
			}
			else{
				System.out.println("Offset type radio button is absent on CNFE Type pop-up confirmation window");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Offset type radio button is absent on CNFE Type pop-up confirmation window", Status.BC_FAILED);
				return;
				
			}//End of else for clone radio button on CNFE Type pop up existence check
			
			//Selecting Submit button on CNFE Type pop up		
			ArrayList <GuiTestObject> button_SubmitCNFEpopupList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Submit");
			if(button_SubmitCNFEpopupList.size()<1){
				System.out.println("Submit button is not found in CNFE Type pop-up Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Submit button is not found in CNFE Type pop-up Page", Status.BC_FAILED);
				return;
			}
			GuiTestObject button_SubmitCNFEpopup = button_SubmitCNFEpopupList.get(button_SubmitCNFEpopupList.size()-1);
			if(button_SubmitCNFEpopup!= null){
				button_SubmitCNFEpopup.waitForExistence(10, 2);
				button_SubmitCNFEpopup.click();
				sleep(10);
			}
			else{
				System.out.println("Submit button is absent in CNFE Type pop-up Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Submit button is absent in CNFE Type pop-up Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Submit button on "Create New Transaction From Existing - Offset" page		
			GuiTestObject button_Submit = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
			if(button_Submit!= null){
				button_Submit.waitForExistence(10, 2);
				button_Submit.click();
				sleep(5);
			}
			else{
				System.out.println("Submit button is absent in \"Create New Transaction From Existing - Offset\" page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Submit button is absent in \"Create New Transaction From Existing - Offset\" page", Status.BC_FAILED);
				return;
			}
			
			//Checking for the existence of the submit confirmation pop up		
			GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.SPAN", ".text", "Confirm Action");
			if(popup_SubmitConfirm==null){			
				System.out.println("Submit confirmation pop up not present");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Submit confirmation pop up not present", Status.BC_FAILED);
				return;			
			}
			else{
				System.out.println("Submit confirmation pop up is present");	
				popup_SubmitConfirm.waitForExistence(30, 2);
				
				//Selecting the Cancel button on the confirmation pop up 		
				ArrayList<GuiTestObject> button_ConfirmCancelList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
				GuiTestObject button_ConfirmCancel = null;
				if(button_ConfirmCancelList.size()==0){			
					System.out.println("Cancel button could not be found on submit confirmation pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Cancel button could not be found on submit confirmation pop up", Status.BC_FAILED);
					return;			
				}
				button_ConfirmCancel = button_ConfirmCancelList.get(button_ConfirmCancelList.size()-1);
				if(button_ConfirmCancel!=null){
					System.out.println("Cancel button present on submit confirmation pop up");
					button_ConfirmCancel.click();	
					sleep(5);
				}
				else{
					System.out.println("Cancel button not present on submit confirmation pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
					return;
				}//End of Cancel button on the confirmation pop up
				
				button_Submit.click();
				popup_SubmitConfirm.waitForExistence(30, 2);
				
				//Selecting the Confirm button on the confirmation pop up 		
				GuiTestObject button_Confirm = Util.getMappedObject("Html.BUTTON", ".value", "Confirm");
				if(button_Confirm!=null){
					System.out.println("Confirm button present on submit confirmation pop up");
					button_Confirm.click();	
					sleep(20);
				}
				else{
					System.out.println("Confirm button not present on submit confirmation pop up");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
					return;
				}//End of Confirm button on the confirmation pop up
				
			}//End of existence of the submit confirmation pop up check
			
			//Waiting for the Txn receipt pop up page to populate on creating the clone
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Transaction is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Transaction is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Transaction is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);
			
			//Selecting View Receipt button			
			ArrayList <GuiTestObject> button_ViewReceiptList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "View Receipt");
			System.out.println("button_ViewReceiptList: "+button_ViewReceiptList);
			GuiTestObject button_ViewReceipt = null;
			if(button_ViewReceiptList.size()<1){
				System.out.println("View Receipt button is not found in create transaction page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "View Receipt button is not found in create transaction page", Status.BC_FAILED);
				return;
			}
			button_ViewReceipt = button_ViewReceiptList.get(button_ViewReceiptList.size()-1);
			if(button_ViewReceipt!= null){
				button_ViewReceipt.waitForExistence(10, 2);
				button_ViewReceipt.click();
				sleep(5);
			}
			else{
				System.out.println("View Receipt button is absent in create transaction page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "View Receipt button is absent in create transaction page", Status.BC_FAILED);
				return;
			}
			
			//Fetching the transaction id from the view receipt pop up 
//			if (Util.getGWTMappedObject("Html.DIV", ".name", "transactionId").exists()
//					|| Util.getGWTMappedObject("Html.DIV", ".name", "transactionId")!= null){
//				sleep(2);
//				transactionId = (String) Util.getGWTMappedObject("Html.DIV", ".name", "transactionId").getProperty(".value");
//				System.out.println("Tran ID: "+transactionId);
//			}
//			else if(Util.getGWTMappedObject("Html.DIV", ".name", "transactionId")== null){
//				System.out.println("Transaction Id not found on confirmation pop up page");
//				error = true;
//				Util.scenarioStatus = false;
////				CRAFT_Report.LogInfo(tsComponentName, "Transaction id not found on view receipt page", Status.BC_FAILED);
//				return;
//			}			
			RegularExpression regExTxnId = new RegularExpression("x-form-el-x-auto-[0-9].*",false);
			ArrayList<GuiTestObject> text_DoneViewReceiptTxnIdList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnId,"Html.INPUT.text", ".name", "transactionId");		
//			GuiTestObject text_DoneViewReceiptTxnId = (GuiTestObject)Util.getMappedObject("Html.INPUT.text", ".name", "transactionId");
			GuiTestObject text_DoneViewReceiptTxnId = null;
			text_DoneViewReceiptTxnId = text_DoneViewReceiptTxnIdList.get(text_DoneViewReceiptTxnIdList.size()-1);
			if(text_DoneViewReceiptTxnId!= null){
				text_DoneViewReceiptTxnId.waitForExistence(10, 2);
				transactionId = text_DoneViewReceiptTxnId.getProperty(".value").toString().trim();
				System.out.println("Tran ID: "+transactionId);
//				button_DoneViewReceipt.click();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction id field is absent in view receipt page", Status.BC_FAILED);
				return;
			}
			
			//Fetching the transaction type from the view receipt pop up 					
			RegularExpression regExTxnType = new RegularExpression("x-form-el-x-auto-[0-9].*",false);
//			RegularExpression regExOffsetTranType = new RegularExpression("x-auto-[0-9].*-input",false);
			TextGuiTestObject text_OffsetTranType = null;
//			ArrayList<GuiTestObject> text_OffsetTranTypeList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnType,"Html.INPUT.text", ".id", regExOffsetTranType);		
			ArrayList<GuiTestObject> text_OffsetTranTypeList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnType,"Html.INPUT.text", ".className", "x-form-field x-form-text");
//			GuiTestObject text_DoneViewReceiptTxnId = (GuiTestObject)Util.getMappedObject("Html.INPUT.text", ".name", "transactionId");
			
			//Searching for the tran type on the view receipt pop up
			if(text_OffsetTranTypeList.size()>0){
				int loop = 0;
				for(loop=0;loop<text_OffsetTranTypeList.size();loop++){
					if(text_OffsetTranTypeList.get(loop).getProperty(".name").toString().isEmpty()){
						text_OffsetTranType = (TextGuiTestObject) text_OffsetTranTypeList.get(loop);
					}
					else{
						continue;
					}
				}
			}
			else{
				System.out.println("No offset Transaction Type found on the View Receipt field");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No offset Transaction Type found on the View Receipt field", Status.BC_FAILED);
				return;
			}
			
			if(text_OffsetTranType!= null){
				text_OffsetTranType.waitForExistence(10, 2);
				offsetTranType = text_OffsetTranType.getProperty(".value").toString().trim();
				System.out.println("Offset Tran Type: "+offsetTranType);
//				button_DoneViewReceipt.click();
			}
			else{
				System.out.println("No offset Transaction Type could be found on the View Receipt field");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No offset Transaction Type could be found on the View Receipt field", Status.BC_FAILED);
				return;
			}
			
			//Selecting Print button to print  			
			GuiTestObject button_PrintBatchChangeStatus = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Print");
			if(button_PrintBatchChangeStatus!= null){
				System.out.println("Inside print button");
				button_PrintBatchChangeStatus.waitForExistence(10, 2);
				button_PrintBatchChangeStatus.click();
				sleep(2);
				
				//Checking the pop up in case of no printer is configured in the machine
				if(printwindowNoPrinterConfig().exists()
						&& printwindowNoPrinterConfig().ensureObjectIsVisible()){

					if(!printwindowNoPrinterConfig().isEnabled()){
						printwindowNoPrinterConfig().activate();
					}
					System.out.println("Inside No Configuration Print Selection Window");
					printwindowNoPrinterConfig().click();
					if(nobutton().exists()
							&& nobutton().ensureObjectIsVisible()){
						nobutton().click();
						sleep(2);
					}
				}
				//End of Checking the pop up in case of no printer is configured in the machine
				
				
						//checking for the existence of the printer select option box
						if(printwindow().exists()
								&& printwindow().ensureObjectIsVisible()){
							System.out.println("printwindow().exists(): "+printwindow().exists()+" printwindow().ensureObjectIsVisible(): "+printwindow().ensureObjectIsVisible());
							System.out.println("Inside print Selection Window");
							//Checking for the existence of cancel button on printer selection window
							System.out.println("cancelbutton().exists(): "+cancelbutton().exists()+" cancelbutton().ensureObjectIsVisible(): "+cancelbutton().ensureObjectIsVisible());
							if(cancelbutton().exists()
									&& cancelbutton().ensureObjectIsVisible()){											
								System.out.println("Inside print selection window cancel");
								cancelbutton().click();
								sleep(2);
							}
							else{
								System.out.println("Cancel button is absent on Printer selection window while selecting to print");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on Printer selection window while selecting to print", Status.BC_FAILED);
								return;
							}//End of Checking for the existence of cancel button on printer selection window										
						}
						else{									
							System.out.println("Printer selection window is not visible while selecting to print");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Printer selection window is not visible while selecting to print", Status.BC_FAILED);
							return;
						}//End of checking for the existence of the printer select option box
					}//End of if for print button existence check				
			else{
				System.out.println("Print Batch Change Status button is absent on batch pend pop-up confirmation window");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Print Batch Change Status button is absent on batch pend pop-up confirmation window", Status.BC_FAILED);
				return;
			}//End of else for print button existence check		
			
			//Validating the offset transaction type
			if(tranType.contains("SALE")
					|| tranType.contains("PRIOR-AUTHORIZED")){
				if(offsetTranType.contains("RETURN")){
					System.out.println("Offset Transsaction type is correct");
				}
				else{
					System.out.println("Offset Transaction type ("+offsetTranType+") is wrong for CNFE transaction type: "+tranType+" instead of being RETURN");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Offset Transaction type ("+offsetTranType+") is wrong for CNFE transaction type: "+tranType+" instead of being RETURN", Status.BC_FAILED);
					return;
				}
			}
			else if(tranType.contains("RETURN")){
				if(offsetTranType.contains("SALE")){
					System.out.println("Offset Transsaction type is correct");
				}
				else{
					System.out.println("Offset Transaction type ("+offsetTranType+") is wrong for CNFE transaction type: "+tranType+" instead of being RETURN");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Offset Transaction type ("+offsetTranType+") is wrong for CNFE transaction type: "+tranType+" instead of being RETURN", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Offset Transaction type: ("+offsetTranType+") and CNFE transaction type: ("+tranType+") are not suitable for successfull offsetting");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Offset Transaction type: ("+offsetTranType+") and CNFE transaction type: ("+tranType+") are not suitable for successfull offsetting", Status.BC_FAILED);
				return;
			}
			//End of Validating the offset transaction type
			
			
			//Selecting Done button on the view receipt pop up
//			browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}{TAB}{ENTER}");
//			sleep(5);
			RegularExpression regExDoneViewRcpt = new RegularExpression("x-auto-[0-9].*",false);
			ArrayList<GuiTestObject> button_DoneViewRcptList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".id",regExDoneViewRcpt,"Html.BUTTON", ".value", "Done");			
			GuiTestObject button_DoneViewRcpt = null;
			if(button_DoneViewRcptList.size()<1){
				System.out.println("Done button is not found in view receipt page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Done button is not found in view receipt page", Status.BC_FAILED);
				return;
			}
			button_DoneViewRcpt = button_DoneViewRcptList.get(button_DoneViewRcptList.size()-1);
			if(button_DoneViewRcpt!= null){
				button_DoneViewRcpt.click();
				sleep(5);
			}
			else{
				System.out.println("Done button is absent in view receipt page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Done button is absent in view receipt page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Done button on the transaction confirmation page			
			RegularExpression regExDone = new RegularExpression("x-auto-[0-9].*",false);
			ArrayList<GuiTestObject> button_DoneList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".id",regExDone,"Html.BUTTON", ".value", "Done");	
			GuiTestObject button_Done = null;
			if(button_DoneList.size()<1){
				System.out.println("Done button is not found in transaction confirmation page");
				error = true;
				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Done button is not found in transaction confirmation page", Status.BC_FAILED);
				return;
			}
			
			button_Done = button_DoneList.get(button_DoneList.size()-1);
			if(button_Done!= null){
				button_Done.click();
				sleep(5);
			}
			else{
				System.out.println("Done button is absent in transaction confirmation page");
				error = true;
				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Done button is absent in transaction confirmation page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Cancel button to cancel the CNFE clone			
			GuiTestObject button_CancelCNFEPopup = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
			if(button_CancelCNFEPopup!= null){
				button_CancelCNFEPopup.waitForExistence(10, 2);
				button_CancelCNFEPopup.click();
				sleep(2);				
			}
			else{
				System.out.println("Cancel button is absent on \"Create New Transaction From Existing - Offset\" page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on \"Create New Transaction From Existing - Offset\" page", Status.BC_FAILED);
				return;
			}//End of else for cancel button existence check	
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Transaction list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Transaction list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Transaction List is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(2);
			
			button_CNFETxn.waitForExistence(20, 2);
			//Selecting the home link to end in the home page				
			link_home().waitForExistence(10, 2);
			link_home().click();
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Transaction list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Transaction list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Transaction List is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);
			
			
			//Component success message
			if(!transactionId.isEmpty()){
				System.out.println("Transaction for CNFE Offset created successfully with id: "+transactionId);
				CRAFT_Report.LogInfo(BusinessComponentName, "Transaction for CNFE Offset created successfully with id: "+transactionId, Status.BC_PASSED);
			}
			else if(transactionId.isEmpty()){
				System.out.println("Transaction for CNFE Offset not created successfully");
				CRAFT_Report.LogInfo(BusinessComponentName, "Transaction for CNFE Offset not created successfully", Status.BC_FAILED);
			}

		}
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}

	}//End of Execute Component
	
}//End of class



