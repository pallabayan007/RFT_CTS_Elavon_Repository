package Business_Components;

import java.util.ArrayList;
import resources.Business_Components.BatchDeleteHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class BatchDelete extends BatchDeleteHelper
{
	/**
	 * Script Name   : <b>BatchDelete</b>
	 * Generated     : <b>Nov 15, 2011 5:42:12 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/15
	 * @author axbane1
	 */
	
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "BatchDelete";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 2)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 2 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 2 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{			
			String batchStatus = (String) args[0];		
			batchStatus = batchStatus.toUpperCase();
			String view = "";
			String multiRecordDelete = (String) args[1];
			String notes = "Automation Test Notes";
//			String batchSettleGridPropText = "";
//			String noOfBatchSettleGrid = "";
			
//			//Searching the existence of the batch settlement recap table	
//			String settleGridTable = "Batch Settlement Recap";
//			GuiTestObject table_BatchSettleGrid = (GuiTestObject)Util.getMappedObject("Html.SPAN", ".text", settleGridTable);
//			if(table_BatchSettleGrid!= null){
//				table_BatchSettleGrid.waitForExistence(90, 2);
//				table_BatchSettleGrid.ensureObjectIsVisible();
//				//Searching the existence of the batch received link
//				RegularExpression regExBatchSettleGrid = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
//				ArrayList<GuiTestObject> link_SelectBatchSettleGridList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSettleGrid,"Html.TABLE", ".text", batchStatus);
//				System.out.println("link_SelectBatchSettleGridList size: "+link_SelectBatchSettleGridList.size());
//				StatelessGuiSubitemTestObject link_SelectBatchSettleGrid = (StatelessGuiSubitemTestObject) link_SelectBatchSettleGridList.get(0);			
//				if(link_SelectBatchSettleGrid!=null){
//					link_SelectBatchSettleGrid.waitForExistence(20, 2);
//					batchSettleGridPropText = link_SelectBatchSettleGrid.getProperty(".text").toString();
//					if(batchSettleGridPropText.isEmpty()){
//						System.out.println(""+batchStatus+"  Number text is absent on Batch Settlement Recap Grid table");
//						error = true;
//						Util.scenarioStatus = false;
//						CRAFT_Report.LogInfo(tsComponentName, ""+batchStatus+"  Number text is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
//						return;	
//					}
//					noOfBatchSettleGrid = batchSettleGridPropText.substring(batchSettleGridPropText.indexOf(batchStatus)+batchStatus.length(), batchSettleGridPropText.lastIndexOf(" ")).trim();
//					System.out.println("batchSettleGridPropText:"+batchSettleGridPropText+" : noOfBatchSettleGrid :"+noOfBatchSettleGrid);
//					
//					//Verifying whether the batch list has any batch to work on
//					if(Integer.parseInt(noOfBatchSettleGrid)==0){
//						System.out.println(""+batchStatus+" has no batch record on the batch list");
//						error = true;
//						Util.scenarioStatus = false;
//						CRAFT_Report.LogInfo(tsComponentName, ""+batchStatus+" has no batch record on the batch list", Status.BC_FAILED);
//						return;
//					}
//					
//					//Selecting the link with the no of batch with supplied status
//					ArrayList<GuiTestObject> link_SelectBatchConfNoList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".text",batchSettleGridPropText,"Html.A", ".text", noOfBatchSettleGrid);
//					System.out.println("link_SelectBatchConfNoList size: "+link_SelectBatchConfNoList.size());
//					GuiTestObject link_SelectBatchConfNo = (GuiTestObject) link_SelectBatchConfNoList.get(0);
//					if(link_SelectBatchConfNo!=null){
//						link_SelectBatchConfNo.waitForExistence(20, 2);
//						link_SelectBatchConfNo.click();
////						sleep(20);
//					}
//					else{
//						System.out.println(""+batchStatus+"  Number link is absent on Batch Settlement Recap Grid table");
//						error = true;
//						Util.scenarioStatus = false;
//						CRAFT_Report.LogInfo(tsComponentName, ""+batchStatus+"  Number link is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
//						return;
//					}
//				}
//				else{
//					System.out.println(""+batchStatus+"  entry is absent on Batch Settlement Recap Grid table");
//					error = true;
//					Util.scenarioStatus = false;
//					CRAFT_Report.LogInfo(tsComponentName, ""+batchStatus+"  entry is absent on Batch Settlement Recap Grid table", Status.BC_FAILED);
//					return;
//				}
//				
//			}
//			else{
//				System.out.println("Batch Settlement Recap Grid table is absent in Page");
//				error = true;
//				Util.scenarioStatus = false;
//				CRAFT_Report.LogInfo(tsComponentName, "Batch Settlement Recap Grid table is absent in Page", Status.BC_FAILED);
//				return;
//			}	
			
			//Waiting for the batch list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The batch list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The batch list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The batch list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			
			//Verifying whether the Delete button is enabled or disabled			
			GuiTestObject button_DelBatch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Delete");
			if(button_DelBatch!= null){
				button_DelBatch.waitForExistence(20, 2);
				if(button_DelBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Delete button is enabled in Batch List Page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Delete button is enabled in Batch List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_DelBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Delete button is disabled rightly in Batch List Page while no records are selected");
				}
				
			}
			else{
				System.out.println("Delete button is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Delete button is absent in Batch List page", Status.BC_FAILED);
				return;
			}
			
			RegularExpression regExBatchSearch = new RegularExpression("batchListGrid_x-auto-[0-9].*",false);
			if(batchStatus.isEmpty()){
				view = "Expanded View";
				//Selecting the records to delete a batch in transaction search list page				
				ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", view);
				StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
				System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
				if(list_SelectBatchSearchResultList.size()!=0){
					int loopUBound = 0;
					if(multiRecordDelete.equalsIgnoreCase("false")){
						loopUBound = 1;
					}
					else if(list_SelectBatchSearchResultList.size()>4){
						loopUBound = 4;
					}
					else if(list_SelectBatchSearchResultList.size()<4){
						loopUBound = list_SelectBatchSearchResultList.size();
					}
					
					//Looping through the matching records
					for(int loop=0;loop<loopUBound;loop++){
						System.out.println("checkbox_SearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
						checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
//						System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
						if(checkbox_SearchRecord!=null){
//							System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//							System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//							checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//																Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
							checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
																atColumn(atIndex(0))));
							sleep(1);
//							break;
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
					}
				}
				else{
					System.out.println("No matching record found in Batch List Page with Expanded View");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Batch List Page with Expanded View", Status.BC_FAILED);
					return;
				}
			}
			else if(!batchStatus.isEmpty()){
				//Selecting the records to delete a batch in transaction search list page
//				RegularExpression regExBatchSearch1 = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
				ArrayList<GuiTestObject> list_SelectBatchSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSearch,"Html.TABLE", ".text", batchStatus);
				StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
				System.out.println("list_SelectBatchSearchResultList size: "+list_SelectBatchSearchResultList.size());
				if(list_SelectBatchSearchResultList.size()!=0){
					int loopUBound = 0;
					if(multiRecordDelete.equalsIgnoreCase("false")){
						loopUBound = 1;
					}
					else if(list_SelectBatchSearchResultList.size()>4){
						loopUBound = 4;
					}
					else if(list_SelectBatchSearchResultList.size()<4){
						loopUBound = list_SelectBatchSearchResultList.size();
					}
					
					//Looping through the matching records
					for(int loop=0;loop<loopUBound;loop++){
						System.out.println("checkbox_SearchRecord : "+list_SelectBatchSearchResultList.get(loop).getProperty(".text").toString());
						checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectBatchSearchResultList.get(loop);
//						System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
						if(checkbox_SearchRecord!=null){
//							System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//							System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//							checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//																Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
							checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
																atColumn(atIndex(0))));
							sleep(1);
//							break;
						}
						else{
							System.out.println("Record not matching ");
							continue;
						}
					}
				}
				else{
					System.out.println("No matching record found in Batch List Page for batch status: "+batchStatus);
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Batch List Page for batch status: "+batchStatus, Status.BC_FAILED);
					return;
				}
			}
			
			
			//Selecting the Delete button to delete the selected records			
			GuiTestObject button_DeleteBatch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Delete");
			if(button_DeleteBatch!= null){
				button_DeleteBatch.waitForExistence(20, 2);
				//Checking whether the delete button is enabled or disabled
				if(button_DeleteBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Delete button is disabled in Batch List Page even after selecting records");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Delete button is disabled in Batch List Page even after selecting records", Status.BC_FAILED);
					return;
				}
				else if(button_DeleteBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					button_DeleteBatch.click();
					sleep(10);
					//Checking for the existence of the delete batch confirm existence 
					GuiTestObject popup_DelBatchConfirm = Util.getMappedObject("Html.SPAN", ".text", "Delete Batch");
					if(popup_DelBatchConfirm!=null){
						//Selecting Cancel button to cancel the delete batch pop up 			
						GuiTestObject button_CancelBatchDel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
						if(button_CancelBatchDel!= null){
							button_CancelBatchDel.waitForExistence(10, 2);
							button_CancelBatchDel.click();
							sleep(2);
							button_DeleteBatch.waitForExistence(10,2);
						}
						else{
							System.out.println("Cancel Batch Delete button is absent on batch delete pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Cancel Batch Delete button is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for cancel button existence check
						
						//Selecting the delete button again to make the delete batch pop up re-appear
						button_DeleteBatch.click();
						sleep(10);
						
						//Selecting Print button to print the delete batch pop up 			
						GuiTestObject button_PrintBatchDel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Print");
						if(button_PrintBatchDel!= null){
							System.out.println("Inside print button");
							button_PrintBatchDel.waitForExistence(10, 2);
							button_PrintBatchDel.click();
							sleep(2);
							//Searching for the print in landscape confirmation pop-up 			
							GuiTestObject popup_PrintLandscape = (GuiTestObject)Util.getMappedObject("Html.DialogStatic", ".text", "Please print in landscape mode for best results");
							if(popup_PrintLandscape!= null){
								System.out.println("Inside print Landscape");
								popup_PrintLandscape.waitForExistence(10, 2);
								sleep(2);
								//Selecting ok button on the landscape printing warning pop up  			
								GuiTestObject button_OkPrintPopUp = (GuiTestObject)Util.getMappedObject("Html.DialogButton", ".text", "OK");
								if(button_OkPrintPopUp!= null){
									System.out.println("Inside print OK Button");
									button_OkPrintPopUp.waitForExistence(10, 2);
									button_OkPrintPopUp.click();
									sleep(2);
									
									//Checking the pop up in case of no printer is configured in the machine
									if(printwindowNoPrinterConfig().exists()
											&& printwindowNoPrinterConfig().ensureObjectIsVisible()){

										if(!printwindowNoPrinterConfig().isEnabled()){
											printwindowNoPrinterConfig().activate();
										}
										System.out.println("Inside No Configuration Print Selection Window");
										printwindowNoPrinterConfig().click();
										if(nobutton().exists()
												&& nobutton().ensureObjectIsVisible()){
											nobutton().click();
											sleep(2);
										}
									}
									//End of Checking the pop up in case of no printer is configured in the machine
									
									//checking for the existence of the printer select option box
									if(printwindow().exists()
											&& printwindow().ensureObjectIsVisible()){
										System.out.println("printwindow().exists(): "+printwindow().exists()+" printwindow().ensureObjectIsVisible(): "+printwindow().ensureObjectIsVisible());
										System.out.println("Inside print Selection Window");
										//Checking for the existence of cancel button on printer selection window
										System.out.println("cancelbutton().exists(): "+cancelbutton().exists()+" cancelbutton().ensureObjectIsVisible(): "+cancelbutton().ensureObjectIsVisible());
										if(cancelbutton().exists()
												&& cancelbutton().ensureObjectIsVisible()){											
											System.out.println("Inside print selection window cancel");
											cancelbutton().click();
											sleep(2);
										}
										else{
											System.out.println("Cancel button is absent on Printer selection window while selecting to print");
											error = true;
											Util.scenarioStatus = false;
											CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on Printer selection window while selecting to print", Status.BC_FAILED);
											return;
										}//End of Checking for the existence of cancel button on printer selection window										
									}
									else{									
										System.out.println("Printer selection window is not visible while selecting to print");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Printer selection window is not visible while selecting to print", Status.BC_FAILED);
										return;
									}//End of checking for the existence of the printer select option box
								}
								else{
									System.out.println("Ok button not available on the print landscape pop up warning window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Ok button not available on the print landscape pop up warning window", Status.BC_FAILED);
									return;
								}//End of else for ok button existence check on print landscape warning pop up
							}
							else{
								System.out.println("Landscape mode printing warning window is absent while clicked on the print button on batch delete pop-up confirmation window");
								error = true;
								Util.scenarioStatus = false;
								CRAFT_Report.LogInfo(tsComponentName, "Landscape mode printing warning window is absent while clicked on the print button on batch delete pop-up confirmation window", Status.BC_FAILED);
								return;
							}//End of else for searching for the print confirmation pop-up
						}
						else{
							System.out.println("Print Batch Delete button is absent on batch delete pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Print Batch Delete button is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for print button existence check				
					
						//Searching for the batch can't be deleted text
						String text_BatchCantDel = "Batch(s) which cannot be Deleted:"; 
						int screenTop_BatchCantDel = 0;
						GuiTestObject table_BatchCantDel = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", text_BatchCantDel);
						if(table_BatchCantDel!= null){
							table_BatchCantDel.waitForExistence(10, 2);	
							screenTop_BatchCantDel = (Integer) table_BatchCantDel.getProperty(".screenTop");
							System.out.println(screenTop_BatchCantDel);
						}
						else{
							System.out.println("Batch can't be deleted table is absent on batch delete pop-up confirmation window");
//							error = true;
//							Util.scenarioStatus = false;
//							CRAFT_Report.LogInfo(tsComponentName, "Batch can't be deleted table is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
//							return;
						}//End of else for batch can't be deleted text
						
						//Searching for the batch to be deleted text
						String text_BatchToBeDel = "Batch(s) to be Deleted:"; 
						int screenTop_BatchToBeDel = 0;
						GuiTestObject table_BatchToBeDel = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", text_BatchToBeDel);
						if(table_BatchToBeDel!= null){
							table_BatchToBeDel.waitForExistence(10, 2);	
							screenTop_BatchToBeDel=(Integer) table_BatchToBeDel.getProperty(".screenTop");
							System.out.println(screenTop_BatchToBeDel);
						}
						else{
							System.out.println("Batch to be deleted table is absent on batch delete pop-up confirmation window");
//							error = true;
//							Util.scenarioStatus = false;
//							CRAFT_Report.LogInfo(tsComponentName, "Batch to be deleted table is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
//							return;
						}//End of else for batch to be deleted text
						
						StatelessGuiSubitemTestObject table_BatchCantDelRow = null;
						StatelessGuiSubitemTestObject table_BatchToBeDelRow = null;
						//Validating Submit button			
						GuiTestObject button_SubmitBatchDel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
						if(button_SubmitBatchDel!= null){
							button_SubmitBatchDel.waitForExistence(10, 2);
							System.out.println("button_SubmitBatchDel.getProperty(aria-disabled).toString(): "+button_SubmitBatchDel.getProperty("aria-disabled").toString());
							//Validating whether the submit button is enabled/disabled
							if(button_SubmitBatchDel.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
								System.out.println("Submit Batch Delete button is disabled on batch delete pop-up confirmation window");
								//Selecting table for batch can't be deleted		
//								RegularExpression regExBatchCantDel = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);								
//								String tableBatchCantDelSearchString = ":";
								String tableBatchCantDelSearchString = ".";
//								ArrayList<GuiTestObject> table_BatchCantDelObjList = Util.getGWTMappedObjects("Html.DIV", ".id", regExBatchCantDel, "Html.TABLE", ".text", tableBatchCantDelSearchString);
								ArrayList<GuiTestObject> table_BatchCantDelObjList = Util.getGWTMappedObjects("Html.TABLE", ".text", tableBatchCantDelSearchString);
//								table_BatchCantDelRow = (StatelessGuiSubitemTestObject) Util.getGWTSelectChildMappedObject("Html.DIV", ".id", regExAddress, "Html.TABLE", ".text", tableAddressSearchString);
								System.out.println("Table_BatchCantDelObjList length: "+table_BatchCantDelObjList.size());
								for(int i=0;i<table_BatchCantDelObjList.size();i++){
									System.out.println("Obj Prop: "+table_BatchCantDelObjList.get(i).getProperty(".text").toString());
								}
								//Filling the Address Type field on the address table
								table_BatchCantDelRow = (StatelessGuiSubitemTestObject) table_BatchCantDelObjList.get(table_BatchCantDelObjList.size()-1);
								
//								//Searching the batch can't delete row with "." while ":" is unavailable
//								if(table_BatchCantDelRow== null){
//									tableBatchCantDelSearchString = ".";								
////									ArrayList<GuiTestObject> table_BatchCantDelObjList = Util.getGWTMappedObjects("Html.DIV", ".id", regExBatchCantDel, "Html.TABLE", ".text", tableBatchCantDelSearchString);
//									table_BatchCantDelObjList = Util.getGWTMappedObjects("Html.TABLE", ".text", tableBatchCantDelSearchString);
////									table_BatchCantDelRow = (StatelessGuiSubitemTestObject) Util.getGWTSelectChildMappedObject("Html.DIV", ".id", regExAddress, "Html.TABLE", ".text", tableAddressSearchString);
//									System.out.println("Table_BatchCantDelObjList length: "+table_BatchCantDelObjList.size());
//									for(int i=0;i<table_BatchCantDelObjList.size();i++){
//										System.out.println("Obj Prop: "+table_BatchCantDelObjList.get(i).getProperty(".text").toString());
//									}
//									//Filling the Address Type field on the address table
//									table_BatchCantDelRow = (StatelessGuiSubitemTestObject) table_BatchCantDelObjList.get(table_BatchCantDelObjList.size()-1);									
//								}
								
								if(table_BatchCantDelRow!= null){
									sleep(1);									
									table_BatchCantDelRow.doubleClick(atCell( atRow(atIndex(0)), 
                                            									atColumn(atIndex(4))));
									browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys(notes);
									table_BatchCantDelRow.click(atCell( atRow(atIndex(0)), 
                                            							atColumn(atIndex(5))));
									
									sleep(2);
//									table_BatchCantDelRow.doubleClick(atCell( atRow(atIndex(0)), 
//						                    atColumn(atIndex(2))));
//									browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ENTER}");			
//									browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}{ENTER}{ENTER}{TAB}{ENTER}{ENTER}{TAB}{ENTER}{ENTER}{TAB}{ENTER}");
								}
								else{
									System.out.println("Batch can't be deleted table is absent on batch delete pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Batch can't be deleted table is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
									return;
								}//End of else for Batch can't be deleted table on batch delete pop-up confirmation window							
								
								//Selecting Cancel button			
								GuiTestObject button_CancelBatchDelete = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
								if(button_CancelBatchDelete!= null){
									button_CancelBatchDelete.waitForExistence(10, 2);
									button_CancelBatchDelete.click();
									sleep(2);
									button_DeleteBatch.waitForExistence(10,2);
								}
								else{
									System.out.println("Cancel Batch Delete button is absent on batch delete pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Cancel Batch Delete button is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
									return;
								}//End of else for cancel button existence check
								
							}//End of if for submit button disabled validation							
							else if(button_SubmitBatchDel.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
								System.out.println("Submit Batch Delete button is enabled on batch delete pop-up confirmation window");
								//Selecting table for batch to be deleted		
//								RegularExpression regExBatchToBeDel = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*", false);
								System.out.println("Inside batch : to be deleted row");
//								String tableBatchToBeDelSearchString = ":";
								String tableBatchToBeDelSearchString = ".";
//								ArrayList<GuiTestObject> table_BatchToBeDelObjList = Util.getGWTMappedObjects("Html.DIV", ".id", regExBatchToBeDel, "Html.TABLE", ".text", tableBatchToBeDelSearchString);
								ArrayList<GuiTestObject> table_BatchToBeDelObjList = Util.getGWTMappedObjects("Html.TABLE", ".text", tableBatchToBeDelSearchString);
//								table_BatchCantDelRow = (StatelessGuiSubitemTestObject) Util.getGWTSelectChildMappedObject("Html.DIV", ".id", regExAddress, "Html.TABLE", ".text", tableAddressSearchString);
								System.out.println("Table_BatchToBeDelObjList length: "+table_BatchToBeDelObjList.size());
								
								for(int i=0;i<table_BatchToBeDelObjList.size();i++){
									System.out.println("Obj Prop: "+table_BatchToBeDelObjList.get(i).getProperty(".text").toString());
								}
								
								//Assigning the batch to be deleted tables
								if(table_BatchToBeDelObjList.size()>=1){									
									table_BatchToBeDelRow = (StatelessGuiSubitemTestObject) table_BatchToBeDelObjList.get(table_BatchToBeDelObjList.size()-1);
									
//									//Searching the table with "." when ":" is not available
//									if(table_BatchToBeDelRow==null){
//										tableBatchToBeDelSearchString = ".";
//										System.out.println("Inside batch . to be deleted row");
////										ArrayList<GuiTestObject> table_BatchToBeDelObjList = Util.getGWTMappedObjects("Html.DIV", ".id", regExBatchToBeDel, "Html.TABLE", ".text", tableBatchToBeDelSearchString);
//										table_BatchToBeDelObjList = Util.getGWTMappedObjects("Html.TABLE", ".text", tableBatchToBeDelSearchString);
////										table_BatchCantDelRow = (StatelessGuiSubitemTestObject) Util.getGWTSelectChildMappedObject("Html.DIV", ".id", regExAddress, "Html.TABLE", ".text", tableAddressSearchString);
//										System.out.println("Table_BatchToBeDelObjList length: "+table_BatchToBeDelObjList.size());
//										
//										for(int i=0;i<table_BatchToBeDelObjList.size();i++){
//											System.out.println("Obj Prop: "+table_BatchToBeDelObjList.get(i).getProperty(".text").toString());
//										}
//										
//										//Assigning the batch to be deleted tables
//										if(table_BatchToBeDelObjList.size()>=1){	
//											table_BatchToBeDelRow = (StatelessGuiSubitemTestObject) table_BatchToBeDelObjList.get(table_BatchToBeDelObjList.size()-1);
//										}									
//									}
									
									//Filling the batch to be delete row								
									if(table_BatchToBeDelRow!= null){
										sleep(1);
										table_BatchToBeDelRow.doubleClick(atCell( atRow(atIndex(0)), 
                                                									atColumn(atIndex(4))));
										browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys(notes);
										table_BatchToBeDelRow.click(atCell( atRow(atIndex(0)), 
                                                							atColumn(atIndex(5))));		
										sleep(2);
//										table_BatchCantDelRow.doubleClick(atCell( atRow(atIndex(0)), 
//							                    atColumn(atIndex(2))));
//										browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ENTER}");			
//										browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}{ENTER}{ENTER}{TAB}{ENTER}{ENTER}{TAB}{ENTER}{ENTER}{TAB}{ENTER}");
									}
									else{
										System.out.println("Batch to be deleted table is absent on batch delete pop-up confirmation window");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Batch to be deleted table is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
										return;
									}//End of else for Batch to be deleted table on batch delete pop-up confirmation window
									
								}								
								else if(table_BatchToBeDelObjList.size()<1){
									System.out.println("Number of tables found are not as expected on the batch delete confirm pop-up window");
									
								}//End of Assigning the batch can't be deleted and batch to be deleted tables	
								
								button_SubmitBatchDel.click();
								
								//Checking for the existence of the submit confirmation pop up		
								GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.SPAN", ".text", "Confirm Action");
								if(popup_SubmitConfirm==null){			
									System.out.println("Submit confirmation pop up not present");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Submit confirmation pop up not present", Status.BC_FAILED);
									return;			
								}
								else{
									System.out.println("Submit confirmation pop up is present");	
									popup_SubmitConfirm.waitForExistence(30, 2);
									
									//Selecting the Cancel button on the confirmation pop up 		
									ArrayList<GuiTestObject> button_ConfirmCancelList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
									GuiTestObject button_ConfirmCancel = null;
									
									if(button_ConfirmCancelList.size()<1){
										System.out.println("Cancel button not found on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not found on submit confirmation pop up", Status.BC_FAILED);
										return;
									}
									else{
										button_ConfirmCancel = button_ConfirmCancelList.get(button_ConfirmCancelList.size()-1);
									}
									
									if(button_ConfirmCancel!=null){
										button_ConfirmCancel.click();
										System.out.println("Selecting the Cancel button on submit confirmation action pop up");
										sleep(5);
									}
									else{
										System.out.println("Cancel button not present on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
										return;
									}//End of Cancel button on the confirmation pop up
									
									button_SubmitBatchDel.click();
									popup_SubmitConfirm.waitForExistence(30, 2);
									
									//Selecting the Confirm button on the confirmation pop up 		
									GuiTestObject button_Confirm = Util.getMappedObject("Html.BUTTON", ".value", "Confirm");
									if(button_Confirm!=null){
										button_Confirm.click();	
										sleep(20);
									}
									else{
										System.out.println("Confirm button not present on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
										return;
									}//End of Confirm button on the confirmation pop up
									
								}//End of existence of the submit confirmation pop up check
								
								//Searching for the successful deletion message 
								String msg_DelString = "All selected batches have been successfully deleted";
								GuiTestObject msg_BatchDelSuccess = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_DelString);
								if(msg_BatchDelSuccess!=null){
									msg_BatchDelSuccess.waitForExistence(30, 2);
									System.out.println("Batch deleted successfully");			
												
								}
								else{
									System.out.println("Batch deletion is unsuccessful");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName,"Batch deletion is unsuccessful" , Status.BC_FAILED);
									return;
								}//End of searching for the successful deletion message
								
								//Selecting the Done button on the delete batch pop-up		
								GuiTestObject button_Done = Util.getMappedObject("Html.BUTTON", ".value", "Done");
								if(button_Done!=null){
									button_Done.click();
									System.out.println("Clicking Done button on delete batch pop up");
									sleep(15);
								}
								else{
									System.out.println("Done button not present on delete batch pop up");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Done button not present on delete batch pop up", Status.BC_FAILED);
									return;
								}//End of Done button on the delete batch pop-up
								
							}//End of else if for submit button enabled validation
							
						}//End of if for submit batch delete button on batch delete pop-up confirmation window
						else{
							System.out.println("Submit Batch Delete button is absent on batch delete pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Submit Batch Delete button is absent on batch delete pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for submit button on delete batch pop-up check					
						
					}//End of if for the delete batch confirm action pop up
					else{
						System.out.println("Delete batch confirm action popup is absent after clicking delete button");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Delete batch confirm action pop-up is absent after clicking delete button", Status.BC_FAILED);
						return;
					}//End of else for the delete batch confirm action pop up
				}//End of else if for delete button enable/disable check
				
			}//End of if for delete button existence check
			else{
				System.out.println("Delete button is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Delete button is absent in Batch List page", Status.BC_FAILED);
				return;
			}
			
			//Returning to the home tab as an exit point
			if(link_home().exists()
					|| link_home().ensureObjectIsVisible()){
				link_home().waitForExistence(20, 2);
				link_home().click();
				//Checking the existence of refresh button at the welcome area on home page				
				GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
				if(button_RefreshAtHome!= null){
					button_RefreshAtHome.waitForExistence(20, 2);
					button_RefreshAtHome.ensureObjectIsVisible();
				}
				else{
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Home tab is absent in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Home tab is absent in Batch List Page", Status.BC_FAILED);
				return;
			}//End of returning to the home tab as an exit point
		
			
			//Component success message
			String cmpSuccessMsg = "Selected Batch(s) have been deleted successfully";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
		}
		catch(Exception e){			
//			StackTraceElement[] sArr = e.getStackTrace();
//			System.out.println(sArr[sArr.length-1]);
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}
		
	}//End of Execute Component
	
}//End of class

