package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.SCBatchListThruTPPBatchCountLinkHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class SCBatchListThruTPPBatchCountLink extends SCBatchListThruTPPBatchCountLinkHelper
{
	/**
	 * Script Name   : <b>SCBatchListThruTPPBatchCountLink</b>
	 * Generated     : <b>Nov 29, 2011 4:53:53 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/29
	 * @author axbane1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "SCBatchListThruTPPBatchCountLink";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 1)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 1 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 1 input, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Home page,Home Tab -> Settlement Control Tab
			 * ---Ending on Home page, i.e. , Home tab
			 */

			String tsComponentName = "SCBatchListThruTPPBatchCountLink";
			String batchStatus = (String) args[0];
			String batchSuspensePropText = "";
			String noOfBatchSuspense = "";
			String noOfBatchSuspenseSearchPg = "";


			//Selecting the settlement control tab
			link_settlementControl().waitForExistence(20, 2);
			link_settlementControl().click();
			sleep(20);

			//Searching the existence of the TPP Processing table	
			String snapShotTable = "TPP Processing";
			GuiTestObject table_TPPProcessing = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", snapShotTable);
			if(table_TPPProcessing!= null){
				table_TPPProcessing.waitForExistence(20, 2);
				//Searching the existence of the batch suspense link
				RegularExpression regExBatchSuspenseRow = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
				ArrayList<GuiTestObject> link_SelectBatchSuspenseList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExBatchSuspenseRow,"Html.TABLE", ".text", batchStatus);
				System.out.println("link_SelectBatchSuspenseList size: "+link_SelectBatchSuspenseList.size());
				StatelessGuiSubitemTestObject link_SelectBatchSuspense = (StatelessGuiSubitemTestObject) link_SelectBatchSuspenseList.get(0);			
				if(link_SelectBatchSuspense!=null){
					link_SelectBatchSuspense.waitForExistence(20, 2);
					batchSuspensePropText = link_SelectBatchSuspense.getProperty(".text").toString();
					if(batchSuspensePropText.isEmpty()){
						System.out.println("Batch Suspense Number text is absent on TPP Processing table");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Batch Suspense Number text is absent on TPP Processing table", Status.BC_FAILED);
						return;	
					}
					noOfBatchSuspense = batchSuspensePropText.substring(batchSuspensePropText.lastIndexOf(" "), batchSuspensePropText.length()).trim();
					System.out.println("batchSuspensePropText:"+batchSuspensePropText+" : noOfBatchSuspense :"+noOfBatchSuspense);
					//Selecting the link with the no of batch suspense
					ArrayList<GuiTestObject> link_SelectBatchRcvNoList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".text",batchSuspensePropText,"Html.A", ".text", noOfBatchSuspense);
					System.out.println("link_SelectBatchRcvNoList size: "+link_SelectBatchRcvNoList.size());
					GuiTestObject link_SelectBatchRcvNo = (GuiTestObject) link_SelectBatchRcvNoList.get(0);
					if(link_SelectBatchRcvNo!=null){
						link_SelectBatchRcvNo.waitForExistence(20, 2);
						link_SelectBatchRcvNo.click();
						sleep(20);
					}
					else{
						System.out.println("Batch Suspense Number link is absent on TPP Processing table");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Batch Suspense Number link is absent on TPP Processing table", Status.BC_FAILED);
						return;
					}
				}
				else{
					System.out.println("Batch Suspense entry is absent on TPP Processing table");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch Suspense entry is absent on TPP Processing table", Status.BC_FAILED);
					return;
				}
				
			}
			else{
				System.out.println("TPP Processing table is absent in Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "TPP Processing table is absent in Page", Status.BC_FAILED);
				return;
			}//End of batch suspense link click under TPP Processing table
			
			//Waiting for the batch list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The batch list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The batch list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The batch list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			//Fetching total number of records fetched on the batch list page
			sleep(5);
			ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
			System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
			GuiTestObject text_totalNoOfBatchSuspensedRecords = null;
			for(int loop=0;loop<text_PageToolbarList.size();loop++){
				text_totalNoOfBatchSuspensedRecords = text_PageToolbarList.get(loop);
				System.out.println(text_totalNoOfBatchSuspensedRecords.getProperty(".text").toString());
			}
			text_totalNoOfBatchSuspensedRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
			if(text_totalNoOfBatchSuspensedRecords!= null){
				text_totalNoOfBatchSuspensedRecords.waitForExistence(10, 2);
				String text_TotalRecordsFetched = text_totalNoOfBatchSuspensedRecords.getProperty(".text").toString();
				noOfBatchSuspenseSearchPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(":")+1,text_TotalRecordsFetched.length()).trim();
				System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfBatchSuspenseSearchPg :"+noOfBatchSuspenseSearchPg);
				sleep(1);
				
				//Checking for the number of batch suspended record on the batch list page
				if(noOfBatchSuspenseSearchPg.isEmpty()){
					System.out.println("Batch suspense Number is absent on Batch List page bottom toolbar");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch suspense Number is absent on Batch List page bottom toolbar", Status.BC_FAILED);
					return;	
				}
				else if(noOfBatchSuspenseSearchPg.equalsIgnoreCase(noOfBatchSuspense)){
					System.out.println("Batch suspense records number on batch List-summary view Page is matching with Batch suspense records number on TPP Processing table");
				}
				else{
					System.out.println("Batch suspense records number("+noOfBatchSuspense+") on batch List-summary view Page is NOT matching with Batch suspense records number("+noOfBatchSuspenseSearchPg+") on TPP Processing table");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch suspense records number("+noOfBatchSuspense+") on batch List-summary view Page is NOT matching with Batch suspense records number("+noOfBatchSuspenseSearchPg+") on TPP Processing table", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Batch suspense records number is absent on batch List-summary view Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Batch suspense records number is absent on batch List-summary view Page", Status.BC_FAILED);
				return;
			}//End of Fetching total number of records fetched on the batch list page
			
			//Clicking the home tab
			link_home().waitForExistence(30, 2);
			link_home().click();
			sleep(10);
			
			//Checking the existence of refresh button at the welcome area on home page				
			GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
			if(button_RefreshAtHome!= null){
				button_RefreshAtHome.waitForExistence(20, 2);
				button_RefreshAtHome.ensureObjectIsVisible();
			}
			else{
				System.out.println("Refresh button is absent in home page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
				return;
			}
			
			
			//Component success message
			String cmpSuccessMsg = "#"+batchStatus+" number in TPP Processing table: "+noOfBatchSuspense+
									" #"+batchStatus+" number in Batch list page: "+noOfBatchSuspenseSearchPg+
										" #The numbers are matching";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);

		}//End of try
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}//End of catch
		
	}//End of execute component
	
}//End of class

