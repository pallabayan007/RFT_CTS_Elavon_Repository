package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.GatewayBMUIHierarchyChoiceHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxsouvi
 */
public class GatewayBMUIHierarchyChoice extends GatewayBMUIHierarchyChoiceHelper
{
	/**
	 * Script Name   : <b>GatewayHierarchyChoice</b>
	 * Generated     : <b>Sep 5, 2011 9:00:44 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/09/05
	 * @author sxsouvi
	 */
	boolean error = false;
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		//Enter business component
		String BusinessComponentName = this.getClass().getName();
		setCurrentLogFilter(DISABLE_LOGGING);
		
		try
		{
			if (args.length < 2)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 2 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 2 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){		
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
				}
			}

		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.BC_FAILED);
		}

	}
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Transaction Management home page, i.e. , transaction search tab
			 * ---Ending on Transaction Management home page, i.e. , transaction search tab
			 */
			
			//Input parameters for the hierarchy choice
			String hierarchyName = (String) args[0];
			String view = (String) args[1];
			
			//Selecting the Transaction management tab
//			link_transactionManagement().waitForExistence(10, 2);
//			link_transactionManagement().click();
//			sleep(10);
			
			//Selecting the change hierarchy link
			text_changeHierarchy().waitForExistence(15, 2);
			text_changeHierarchy().click();
			sleep(5);
//			image_clearGif().click();
//			html_xAuto402().drag(atPoint(189,25), atPoint(188,66));
			
			//Selecting Hierarchy Name			
//			SelectGuiSubitemTestObject selectText_HierarchyName = (SelectGuiSubitemTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "hierarchyName");
			TextGuiTestObject text_HierarchyName = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "hierarchyName");
			if(text_HierarchyName!= null){
				text_HierarchyName.click();
				text_HierarchyName.setText(hierarchyName);
				sleep(2);
				//Selecting the hierarchy name from the drop down
//				RegularExpression regExHierNameDropDwn = new RegularExpression("x-auto-[0-9].*",false);
				
				if(hierarchyName.isEmpty()){
					System.out.println("The hierarchy name search string is empty");
				}
				else{
//					ArrayList<GuiTestObject> list_hierarchyNameList = Util.getGWTMappedObjects("Html.DIV",".id",regExHierNameDropDwn, "Html.DIV",".text", hierarchyName);
					ArrayList<GuiTestObject> list_hierarchyNameList = Util.getGWTMappedObjects("Html.DIV",".text", hierarchyName);
					System.out.println("list_hierarchyNameList Size: "+list_hierarchyNameList.size());
					GuiTestObject list_hierarchyName = list_hierarchyNameList.get(list_hierarchyNameList.size()-1);
					for(int i=0;i<list_hierarchyNameList.size();i++){
						System.out.println("list_hierarchyNameList: "+list_hierarchyNameList.get(i).getProperty(".text").toString());
					}
					if(list_hierarchyName!=null){
						System.out.println("Inside the Hierarchy name dropdown list");	
						list_hierarchyName.click();
					}
					else{
						System.out.println("Mandatory Field(s) Hierarchy name list dropdown not found on Hierarchy Search Page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo("GatewayGBMHierarchyChoice", "Mandatory field(s) Hierarchy name list dropdown not found on Hierarchy Search Page", Status.BC_FAILED);
						return;
					}
				}
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("GatewayGBMHierarchyChoice", "Mandatory field(s) Hierarchy Name is absent in Hierarchy search page", Status.BC_FAILED);
				return;
			}
			
//			html_xAuto402().drag(atPoint(190,65), atPoint(194,38));
//			html_xAuto383().click(atPoint(76,310));
//			image_clearGif2().click();
//			html_xAuto386().click(atPoint(25,10));
			
			//Selecting view			
//			SelectGuiSubitemTestObject selectText_ViewName = (SelectGuiSubitemTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "viewName");
			TextGuiTestObject text_ViewName = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "viewName");
			if(text_ViewName!= null){
				text_ViewName.setText(view);
				sleep(2);
				//Selecting the view from the drop down
//				RegularExpression regExViewDropDwn = new RegularExpression("x-auto-[0-9].*",false);
				if(view.isEmpty()){
					System.out.println("The view search string is empty");
				}
				else{
//					ArrayList<GuiTestObject> list_viewList = Util.getGWTMappedObjects("Html.DIV",".id",regExViewDropDwn, "Html.DIV",".text", view);
					ArrayList<GuiTestObject> list_viewList = Util.getGWTMappedObjects("Html.DIV",".text", view);
					System.out.println("list_viewList Size: "+list_viewList.size());
					GuiTestObject list_view = list_viewList.get(list_viewList.size()-1);
					for(int i=0;i<list_viewList.size();i++){
						System.out.println("list_hierarchyNameList: "+list_viewList.get(i).getProperty(".text").toString());
					}
					if(list_view!=null){
						System.out.println("Inside the View dropdown list");	
						list_view.click();
					}
					else{
						System.out.println("Mandatory Field(s) View list dropdown not found on Hierarchy Search Page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo("GatewayGBMHierarchyChoice", "Mandatory field(s) View list dropdown not found on Hierarchy Search Page", Status.BC_FAILED);
						return;
					}
				}
			}
			else{
				System.out.println("Mandatory field(s) View is absent in Hierarchy search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("GatewayGBMHierarchyChoice", "Mandatory field(s) View is absent in Hierarchy search page", Status.BC_FAILED);
				return;
			}
//			button_searchAndUseSelectionbu().click();
			
			//Selecting Search And Use Selection button			
			GuiTestObject button_searchAndUseSelection = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Search And Use Selection");
			if(button_searchAndUseSelection!= null){
				button_searchAndUseSelection.click();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo("GatewayGBMHierarchyChoice", "Search And Use Selection button is absent in Hierarchy search page", Status.BC_FAILED);
				return;
			}
			
			sleep(10);
			
			//Selecting the Transaction management tab
		//	link_transactionManagement().waitForExistence(60, 2);
		//	link_transactionManagement().click();
		//	sleep(5);
			
			//Selecting the transaction search tab to end there
		//	button_transactionSearchbutton().click();
		//	sleep(2);
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
//				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int loopcount=0;loopcount<progressBar_LoadingList.size();loopcount++){
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(loopcount).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(10);
			
			//Component success message
			CRAFT_Report.LogInfo("GatewayGBMHierarchyChoice", "Hierarchy "+hierarchyName+" selected successfully", Status.BC_PASSED);
			
		}//End of try block
		catch(Exception e){
			e.getMessage();
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[sArr.length-1]);
			error = true;
//			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}//End of catch block		

	}//End of ExecuteComponenet
}

