package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.TxnAddNoteHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class TxnAddNote extends TxnAddNoteHelper
{
	/**
	 * Script Name   : <b>TxnAddNote</b>
	 * Generated     : <b>Jan 3, 2012 7:46:30 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/01/03
	 * @author axbane1
	 */
	
	boolean error = false;
	String transactionId = "";
	String tsComponentName = "TxnAddNote";
	String BusinessComponentName = this.getClass().getName();
	
	public void testMain(Object[] args) 
	{
		setCurrentLogFilter(DISABLE_LOGGING);
		// TODO Insert code here
		try
		{
			if (args.length < 3)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 3 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 3 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
		return;
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
	
		// TODO Insert code here
		//Place your Code here
		try{
			/*
			 * ---Starting from Txn List page,Transaction Search -> Transaction List
			 * ---Ending on Home page, i.e. , Home tab
			 */
		
			String tranStatus = (String) args[0];
			if(tranStatus.isEmpty()){
				tranStatus = "APPROVED";
			}
			tranStatus = tranStatus.toUpperCase();
			String notes = (String) args[1];
			String multiRecNoteReq = (String) args[2];
			int loopUBound = 0;
			
			

			//Verifying whether the Add Notes button is enabled or disabled			
			GuiTestObject button_AddNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Add Note");
			if(button_AddNotes!= null){
				button_AddNotes.waitForExistence(10, 2);
				if(button_AddNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Add Note button is enabled in Transaction List page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Add Note button is enabled in Transaction List page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_AddNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Add Note button is disabled rightly in Transaction List page while no records are selected");
				}

			}
			else{
				System.out.println("Add Note button is absent in Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Add Note button is absent in Transaction List page", Status.BC_FAILED);
				return;
			}
			
			RegularExpression regExTxnSearch = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
			System.out.println("After regex");
			ArrayList<GuiTestObject> list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearch,"Html.TABLE", ".text", tranStatus);
			System.out.println("After arraylist");
			StatelessGuiSubitemTestObject checkbox_SearchRecord = null;
			System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
			if(list_SelectTxnSearchResultList.size()!=0){
				
				if(multiRecNoteReq.equalsIgnoreCase("yes")){
					if(list_SelectTxnSearchResultList.size()>2){
						loopUBound = 2;
					}
					else if(list_SelectTxnSearchResultList.size()<=2){
						loopUBound = 1;
					}					
				}				
				else{
					loopUBound = 1;
				}
				
				//Looping through the matching records
				for(int loop=0;loop<loopUBound;loop++){
					System.out.println("checkbox_SearchRecord : "+list_SelectTxnSearchResultList.get(loop).getProperty(".text").toString());
					checkbox_SearchRecord = (StatelessGuiSubitemTestObject)list_SelectTxnSearchResultList.get(loop);
//					System.out.println("checkbox_SearchRecord : "+checkbox_SearchRecord.getDescriptiveName());
					if(checkbox_SearchRecord!=null){
//						System.out.println("checkbox_SearchRecord Left: "+checkbox_SearchRecord.getProperty(".screenLeft").toString());
//						System.out.println("checkbox_SearchRecord Top: "+checkbox_SearchRecord.getProperty(".screenTop").toString());
//						checkbox_SearchRecord.click(atPoint(Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString()),
//															Integer.parseInt(checkbox_SearchRecord.getProperty(".screenLeft").toString())+1));					
						checkbox_SearchRecord.click(atCell(atRow(atIndex(0)), 
															atColumn(atIndex(0))));
						sleep(1);
//						break;
					}
					else{
						System.out.println("Record not matching ");
						continue;
					}
				}
			}
			else{
				System.out.println("No matching record found in Transaction Search List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Transaction Search List Page", Status.BC_FAILED);
				return;
			}

			//Selecting the Add Notes button to add a note to the selected records			
			GuiTestObject button_AddTxnNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Add Note");
			if(button_AddTxnNotes!= null){
				button_AddTxnNotes.waitForExistence(10, 2);
				//Checking whether the add notes button is enabled or disabled
				if(button_AddTxnNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Add Note button is disabled in Transaction List Page even after selecting records");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Add Note button is disabled in Transaction List Page even after selecting records", Status.BC_FAILED);
					return;
				}
				else if(button_AddTxnNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					button_AddTxnNotes.click();
					sleep(6);
					//Checking for the existence of the Add Transaction Notes confirm existence 
					GuiTestObject popup_AddNotesConfirm = Util.getMappedObject("Html.SPAN", ".text", "Add Transaction Notes");
					if(popup_AddNotesConfirm!=null){
						//Selecting Cancel button to cancel the Add Transaction Notes pop up 			
						GuiTestObject button_CancelAddNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
						if(button_CancelAddNotes!= null){
							button_CancelAddNotes.waitForExistence(10, 2);
							button_CancelAddNotes.click();
							sleep(2);
							button_AddTxnNotes.waitForExistence(10,2);
						}
						else{
							System.out.println("Cancel button is absent on add Transaction notes pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent on add Transaction notes pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for cancel button existence check

						//Selecting the add notes button again to make the add Transaction notes pop up re-appear
						button_AddTxnNotes.click();
						sleep(10);
						
						//Validating Submit button			
						GuiTestObject button_SubmitAddBatchNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Submit");
						if(button_SubmitAddBatchNotes!= null){
							button_SubmitAddBatchNotes.waitForExistence(10, 2);
							System.out.println("button_SubmitAddBatchNotes.getProperty(aria-disabled).toString(): "+button_SubmitAddBatchNotes.getProperty("aria-disabled").toString());
							//Validating whether the submit button is enabled/disabled
							if(button_SubmitAddBatchNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
								System.out.println("Submit button is disabled on add Transaction notes pop-up confirmation window");
								//Selecting Cancel button			
								ArrayList<GuiTestObject> button_CancelAddTxnNotesList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
								GuiTestObject button_CancelAddTxnNotes = null;
								if(button_CancelAddTxnNotesList.size()<1){
									System.out.println("Cancel button is not found on add Transaction notes pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Cancel is not found on add Transaction notes pop-up confirmation window", Status.BC_FAILED);
									return;
								}
								button_CancelAddTxnNotes = button_CancelAddTxnNotesList.get(button_CancelAddTxnNotesList.size()-1);
								if(button_CancelAddTxnNotes!= null){
									button_CancelAddTxnNotes.waitForExistence(10, 2);
									button_CancelAddTxnNotes.click();
									sleep(2);
									button_AddTxnNotes.waitForExistence(10,2);
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Submit button is disabled on add Transaction notes pop-up confirmation window", Status.BC_FAILED);
									return;
								}
								else{
									System.out.println("Cancel button is absent on add Transaction notes pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Cancel is absent on add Transaction notes pop-up confirmation window", Status.BC_FAILED);
									return;
								}//End of else for cancel button existence check

							}//End of if for submit button disabled validation	
//							else if(button_SubmitAddBatchNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
							else{
								System.out.println("Submit button is enabled on add Transaction pop-up confirmation window");

								//Selecting the transactions for adding notes for the same
								ArrayList<GuiTestObject> text_TxnIdList = Util.getGWTMappedObjects("Html.DIV", ".text", "Transaction notes for:");
								GuiTestObject text_TxnId = null;
								if(text_TxnIdList.size()<1){
									System.out.println("Transaction Id(s)are not found on add Transaction notes pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Transaction Id(s)are not found on add Transaction notes pop-up confirmation window", Status.BC_FAILED);
									return;
								}
								text_TxnId = text_TxnIdList.get(text_TxnIdList.size()-1);
								
								if(text_TxnId != null){
									String searchTxnIds = text_TxnId.getProperty(".text").toString();
									transactionId = searchTxnIds.substring(searchTxnIds.indexOf(":")+1, searchTxnIds.length()).trim();
								}
								else{
									System.out.println("Transaction Id(s)could not be found on add Transaction notes pop-up confirmation window");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Transaction Id(s)could not be found on add Transaction notes pop-up confirmation window", Status.BC_FAILED);
									return;
								}
								// End of Selecting the transactions for adding notes for the same
								
								
								//Selecting Enter Notes in the Add Transaction Notes pop-up
								RegularExpression regExNotes = new RegularExpression("x-auto-[0-9].*-input",false);
								//TextGuiTestObject text_VoidTransactionNotesNotes = (TextGuiTestObject)Util.getMappedObject("Html.TEXTAREA", ".className", "x-form-field x-form-textarea");
								TextGuiTestObject text_TxnNotes = (TextGuiTestObject)Util.getGWTMappedObject("Html.TEXTAREA", ".id", regExNotes);
								if(text_TxnNotes!= null){
									text_TxnNotes.waitForExistence(10, 2);
									text_TxnNotes.click();
									text_TxnNotes.setText(notes);
									sleep(1);
								}
								else{
									System.out.println("Enter Notes area is absent in Add Transaction Notes popup");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Enter Notes area is absent in Add Transaction Notes popup", Status.BC_FAILED);
									return;
								}

								//Selecting Visible to external user check box in the Add Transaction Notes popup			
								ArrayList<GuiTestObject> checkbox_VisibleExtUserList = Util.getGWTMappedObjects("Html.DIV", ".text", "Visible to External Users");
								GuiTestObject checkbox_VisibleExtUser = null;
								if(checkbox_VisibleExtUserList.size()!=0){
									checkbox_VisibleExtUser = checkbox_VisibleExtUserList.get(checkbox_VisibleExtUserList.size()-1);
									if(checkbox_VisibleExtUser!= null){				
										checkbox_VisibleExtUser.waitForExistence(10, 2);
										checkbox_VisibleExtUser.click();			
										sleep(1);
									}
									else{
										System.out.println("Visible to external user checkbox is absent in Add Transaction Notes popup");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Visible to external user check box is absent in Add Transaction Notes popup", Status.BC_FAILED);
										return;
									}
								}

								else{
									System.out.println("Visible to external user checkbox not found in Add Transaction Notes popup");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Visible to external user check box not found in Add Transaction Notes popup", Status.BC_FAILED);
									return;
								}


								button_SubmitAddBatchNotes.click();

								//Checking for the existence of the submit confirmation pop up		
								GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.SPAN", ".text", "Confirm Action");
								if(popup_SubmitConfirm==null){			
									System.out.println("Submit confirmation pop up not present");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Submit confirmation pop up not present", Status.BC_FAILED);
									return;			
								}
								else{
									System.out.println("Submit confirmation pop up is present");	
									popup_SubmitConfirm.waitForExistence(30, 2);

									//Selecting the Cancel button on the confirmation pop up 		
									ArrayList<GuiTestObject> button_ConfirmCancelList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
									GuiTestObject button_ConfirmCancel = null;
									if(button_ConfirmCancelList.size()<1){
										System.out.println("Cancel button is not found on submit pop-up confirmation window");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Cancel is not found on submit pop-up confirmation window", Status.BC_FAILED);
										return;
									}
									button_ConfirmCancel = button_ConfirmCancelList.get(button_ConfirmCancelList.size()-1);
									if(button_ConfirmCancel!=null){
										button_ConfirmCancel.click();	
										sleep(5);
									}
									else{
										System.out.println("Cancel button not present on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
										return;
									}//End of Cancel button on the confirmation pop up

									button_SubmitAddBatchNotes.click();
									popup_SubmitConfirm.waitForExistence(10, 2);

									//Selecting the Confirm button on the confirmation pop up 		
									GuiTestObject button_Confirm = Util.getMappedObject("Html.BUTTON", ".value", "Confirm");
									if(button_Confirm!=null){
										button_Confirm.click();	
										sleep(20);
									}
									else{
										System.out.println("Confirm button not present on submit confirmation pop up");
										error = true;
										Util.scenarioStatus = false;
										CRAFT_Report.LogInfo(tsComponentName, "Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
										return;
									}//End of Confirm button on the confirmation pop up

								}//End of existence of the submit confirmation pop up check

								//Searching for the successful note addition message 
								String msg_NoteAddString = "Notes Added Successfully";
								GuiTestObject msg_NoteAddSuccess = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_NoteAddString);
								if(msg_NoteAddSuccess!=null){
									msg_NoteAddSuccess.waitForExistence(30, 2);
									System.out.println("Notes addition is Successful");			

								}
								else{
									System.out.println("Notes addition is unsuccessful");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName,"Notes addition is unsuccessful" , Status.BC_FAILED);
									return;
								}//End of searching for the successful note addition message

								//Selecting Cancel button on Add Transaction Note pop-up		
								GuiTestObject button_Cancel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Cancel");
								if(button_Cancel!= null){
									button_Cancel.waitForExistence(10, 2);
									button_Cancel.click();
									sleep(15);
								}
								else{
									System.out.println("Cancel button is absent in Add Transaction Note pop-up	");
									error = true;
									Util.scenarioStatus = false;
									CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent in Add Transaction Note pop-up	", Status.BC_FAILED);
									return;
								}//End of Cancel button on the add Transaction note pop-up
							}//End of else if for submit button enabled validation


						}//End of if for submit add Transaction note button on add Transaction note pop-up confirmation window
						else{
							System.out.println("Submit button is absent on add Transaction note pop-up confirmation window");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Submit button is absent on add Transaction note pop-up confirmation window", Status.BC_FAILED);
							return;
						}//End of else for submit button on add Transaction note pop-up check					

					}//End of if for the add Transaction note confirm action pop up
					else{
						System.out.println("Add Transaction Note confirm action popup is absent after clicking Submit button");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Add Transaction Note confirm action popup is absent after clicking Submit button", Status.BC_FAILED);
						return;
					}//End of else for the add Transaction note confirm action pop up
				}//End of else if for add note button enable/disable check

			}//End of if for Add Notes button existence check
			else{
				System.out.println("Add Notes button is absent in Transaction List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Add Notes button is absent in Transaction List page", Status.BC_FAILED);
				return;
			}
			
			//Selecting the home link to end in the home page				
			link_home().waitForExistence(10, 2);
			link_home().click();
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Transaction list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Transaction list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Transaction List is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);
			
			
			//Component success message
			String cmpSuccessMsg = "Notes added successfully for Transaction(s): "+transactionId;
			System.out.println(cmpSuccessMsg);
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
			

		}
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}

	}//End of Execute Component

		

}//End of class

