package Business_Components;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import resources.Business_Components.BatchSearchHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxghos1
 */
public class BatchSearch extends BatchSearchHelper
{
	/**
	 * Script Name   : <b>BatchSearch</b>
	 * Generated     : <b>Nov 5, 2011 5:28:19 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2011/11/05
	 * @author sxghos1
	 */
	
	boolean error = false;
	//Enter Business Component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "BatchSearch";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 10)
			{
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 9 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 9 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					
				}
						       		
			}
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			
		}
		
	}//End of testMain()

	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			String merBatchNo = (String) args[0];
			String sysBatchNo = (String) args[1];
			String siteId = (String) args[2];
			String tppName = (String) args[3];
			String batchStatus = (String) args[4];
			batchStatus = batchStatus.toUpperCase();
			int listPosition = 0;
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			String yesterdayDt = new SimpleDateFormat("MM/dd/yyyy").format(cal.getTime());
			String startDate = (String) args[5];
			cal.add(Calendar.DATE, 2);
			String endDt = (String) args[6];
			String voyage = (String) args[7];
			String statusList = (String) args[8];
			String enterDate = (String) args[9];
			String noOfBatchSearchPg = "";
			int totalBatchNoSearchPg = 0;
					
			System.out.println(""+yesterdayDt);
			System.out.println(""+endDt);
			
			//Selecting the Batch Management tab
			link_batchManagement().waitForExistence(20, 2);
			link_batchManagement().click();
			sleep(5);

			//Selecting the batch search tab		
			GuiTestObject button_BatchSearch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Batch Search");
			if(button_BatchSearch!= null){
				button_BatchSearch.waitForExistence(20, 2);
				button_BatchSearch.click();
				sleep(5);
			}
			else{
				System.out.println("Batch Search Tab is absent in Batch Search Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Batch Search Tab is absent in Batch Search Page", Status.BC_FAILED);
				return;
			}
			//Selecting Merchant Batch number			
			TextGuiTestObject text_MerBatchNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "posBatchId");
			if(text_MerBatchNo!= null){
				text_MerBatchNo.waitForExistence(10, 2);
				text_MerBatchNo.click();
				text_MerBatchNo.setText(merBatchNo);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Merchant Batch No. is absent in batch search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Merchant Batch No. is absent in batch search page", Status.BC_FAILED);
				return;
			}
			
			//Selecting System Batch No			
			TextGuiTestObject text_SysBatchNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "batchId");
			if(text_SysBatchNo!= null){
				text_SysBatchNo.waitForExistence(10, 2);
				text_SysBatchNo.click();
				text_SysBatchNo.setText(sysBatchNo);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("System Batch number is absent in batch search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "System Batch number is absent in batch search page", Status.BC_FAILED);
				return;
			}
			
			//Selecting site id			
			TextGuiTestObject text_SiteId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "siteIdStr");
			if(text_SiteId!= null){
				text_SiteId.waitForExistence(10, 2);
				text_SiteId.click();
				text_SiteId.setText(siteId);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Site Id is absent in batch search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Site Id is absent in batch search page", Status.BC_FAILED);
				return;
			}
			

			//Adding TPP Name
			if(tppName.isEmpty()){
				System.out.println("The tpp name search string is empty");
			}
			else{
				TextGuiTestObject text_TppName = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "tppId");
				if(text_TppName!=null){			
					text_TppName.click();			
					text_TppName.setText(tppName);
					sleep(2);
					//Selecting the TPP Name from the drop down
//					RegularExpression regExTppNameDropDwn = new RegularExpression("x-auto-[0-9].*",false);
					if(tppName.isEmpty()){
						System.out.println("The tpp name search string is empty");
					}
					else{
//						ArrayList<GuiTestObject> list_TppNameList = Util.getGWTMappedObjects("Html.DIV",".id",regExTppNameDropDwn, "Html.DIV",".text", tppName);
						ArrayList<GuiTestObject> list_TppNameList = Util.getGWTMappedObjects("Html.DIV",".text", tppName);
						GuiTestObject list_TppName = list_TppNameList.get(list_TppNameList.size()-1);
						for(int i=0;i<list_TppNameList.size();i++){
							System.out.println("list_TppNameList: "+list_TppNameList.get(i).getProperty(".text").toString());
						}
						if(list_TppNameList!=null){
							System.out.println("Inside the Tpp Name dropdown list");	
							list_TppName.click();
						}
//						else{
//							System.out.println("TPP Name list dropdown not found on Batch Search Page");
//							error = true;
//							Util.scenarioStatus = false;
//							CRAFT_Report.LogInfo(tsComponentName, "TPP Name list dropdown not found on Batch Search Page", Status.BC_FAILED);
//							return;
//						}
					}
					//End of selection of View Batch By from drop down
					System.out.println(""+text_TppName.getScreenPoint());
					//Setting the focus out of the view Batch by field 
//					if(text_ViewTranBy.hasFocus()){
//						text_ViewTranBy.setProperty(".hasFocus", false);
//					}
				}
				else{
					System.out.println("TPP Name list dropdown not found on Batch Search Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "TPP Name list dropdown not found on Batch Search Page", Status.BC_FAILED);
					return;
				}
			
			}//End of TPP Name
			
			/*==========================
			 * Selecting the Batch Status
			 *///=======================				
			
			//Searching for the status position in the status list
			int statusCount = (int) Util.commaSeparatedWordCount(statusList);
			String[] statusListDet = new String[statusCount];
			statusListDet = (String[]) Util.commaSeparatedWordDetails(statusList, Util.commaSeparatedWordCount(statusList)); 
			for(int loopCount=0;loopCount<statusListDet.length;loopCount++){
				if(statusListDet[loopCount].toUpperCase().equalsIgnoreCase(batchStatus)){
					listPosition = loopCount;
					break;
				}
				else{
					continue;
				}
			}//End of Searching for the status position in the status list
			
			if(!batchStatus.isEmpty()
					&& listPosition >= 0){			
				//Selecting Status	
				ArrayList<GuiTestObject> select_BatchStatusList = Util.getGWTMappedObjects("Html.DIV", ".text", batchStatus);
				System.out.println(select_BatchStatusList.size());
				GuiTestObject select_BatchStatus = null;
				//Checking whether the list box exists or not
				if(select_BatchStatusList.size()!=0){
					//For statement w.r.t. status list box mapping
					for(int i=0;i<select_BatchStatusList.size();i++){
						System.out.println("I: "+i);
						System.out.println("Id: "+select_BatchStatusList.get(i).getProperty(".id").toString());
						System.out.println("Text: "+select_BatchStatusList.get(i).getProperty(".text").toString());
						System.out.println("ROLE: "+select_BatchStatusList.get(i).getProperty("role").toString());
						//Checking and mapping the status list box
						if(select_BatchStatusList.get(i).getProperty("role").toString().equalsIgnoreCase("listbox")){
							select_BatchStatus = select_BatchStatusList.get(i);
							break;
						}
						else{
							continue;
						}//End of else for Checking and mapping the status list box
						
					}//End of for statement w.r.t. status list box mapping
					
					//Selecting the status
					if(select_BatchStatus!=null){
						select_BatchStatus.click();
						browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtUp}");		
						browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtUp}");
						//Browsing to the status by using down Arrow key
						for(int loop=0;loop<listPosition;loop++){
							browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtDown}");
							sleep(1);
						}//End of Browsing to the status by using down Arrow key
					}
					else{
						System.out.println("Batch Status listbox not found in batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Batch Status listbox not found in batch search page", Status.BC_FAILED);
						return;
					}//End of Selecting the status
					
				}//End of if for Checking whether the list box exists or not
				else{
					System.out.println("Batch Status listbox is absent in batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch Status listbox is absent in batch search page", Status.BC_FAILED);
					return;
				}//Checking whether the list box exists or not	
			}//End of if for file status & list position validation

			/*+++++++++++++++++++++++++++++++++
			 * End of Selecting the Batch Status
			 *///++++++++++++++++++++++++++++++
			
			
			//Searching and selecting Enter Date check-box			
			GuiTestObject checkbox_EnterDt = Util.getMappedObject("Html.DIV", ".text", "Enter Date");
			if(checkbox_EnterDt!= null 
					&& checkbox_EnterDt.ensureObjectIsVisible()){
				checkbox_EnterDt.waitForExistence(10, 2);
				if(enterDate.equalsIgnoreCase("Yes")
						&& !sysBatchNo.isEmpty()){
					checkbox_EnterDt.click();
					//Selecting Start Date			
					TextGuiTestObject text_StartDt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", yesterdayDt);
					if(text_StartDt!= null){
						text_StartDt.waitForExistence(10, 2);
						text_StartDt.click();
						text_StartDt.setText(startDate);
						sleep(2);
//						browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
					}
					else{
						System.out.println("Mandatory field(s) Start Date is absent in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Start Date is absent in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}//End of Start Date
					
					//Selecting End Date	
					ArrayList<GuiTestObject> text_EndDtList = Util.getGWTMappedObjects("Html.INPUT.text", ".value", Util.getCurrentDatenTime("MM/dd/yyyy"));
					if(text_EndDtList.size()!=0){
						TextGuiTestObject text_EndDt = (TextGuiTestObject) text_EndDtList.get(text_EndDtList.size()-1);
						if(text_EndDt!= null){
							text_EndDt.waitForExistence(10, 2);
							text_EndDt.click();
							text_EndDt.setText(endDt);
							sleep(2);
//							browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
						}
						else{
							System.out.println("Mandatory field(s) End Date is absent in Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in Settlement Control batch search page", Status.BC_FAILED);
							return;
						}
					}
					else{
						System.out.println("Mandatory field(s) End Date not found in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date not found in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}//End of End Date
				}
				else{
					System.out.println("Enter date is not needed");
				}										
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				//Selecting Start Date			
				TextGuiTestObject text_StartDt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", yesterdayDt);
				if(text_StartDt!= null){
					text_StartDt.waitForExistence(10, 2);
					text_StartDt.click();
					text_StartDt.setText(startDate);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("Mandatory field(s) Start Date is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Start Date is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Start Date
				
				//Selecting End Date	
				ArrayList<GuiTestObject> text_EndDtList = Util.getGWTMappedObjects("Html.INPUT.text", ".value", Util.getCurrentDatenTime("MM/dd/yyyy"));
				if(text_EndDtList.size()!=0){
					TextGuiTestObject text_EndDt = (TextGuiTestObject) text_EndDtList.get(text_EndDtList.size()-1);
					if(text_EndDt!= null){
						text_EndDt.waitForExistence(10, 2);
						text_EndDt.click();
						text_EndDt.setText(endDt);
						sleep(2);
//						browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
					}
					else{
						System.out.println("Mandatory field(s) End Date is absent in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}
				}
				else{
					System.out.println("Mandatory field(s) End Date not found in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date not found in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of End Date
				
			}//End of Enter date
					
			//Selecting Voyage			
			TextGuiTestObject text_Voyage = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "voyage");
			if(text_Voyage!= null){
				text_Voyage.waitForExistence(10, 2);
				text_Voyage.click();
				text_Voyage.setText(voyage);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Voyage is absent in batch search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Voyage is absent in batch search page", Status.BC_FAILED);
				return;
			}
			//Selecting Search button			
			GuiTestObject button_Search = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Search");
			if(button_Search!= null){
				button_Search.waitForExistence(10, 2);
				button_Search.click();
				sleep(20);
			}
			else{
				System.out.println("Search button is absent in Batch Search Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Search button is absent in Batch Search Page", Status.BC_FAILED);
				return;
			}
			
			//Checking whether the search result has data or not
			GuiTestObject msg_NoSearchResult = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "No records found for Batch List.");
			if(msg_NoSearchResult!= null){
				msg_NoSearchResult.waitForExistence(40, 2);
				System.out.println("Search result has no data in Batch List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Search result has no data in Batch Search List Page", Status.BC_FAILED);
				return;
			}
			else if(msg_NoSearchResult== null){
				//Fetching total number of records fetched on the Batch list page
				ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
				System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
				GuiTestObject text_totalNoOfTxnRecords = null;
				if(text_PageToolbarList.size()==0
						|| !text_PageToolbarList.get(text_PageToolbarList.size()-1).ensureObjectIsVisible()){
					System.out.println("Batch search fetched NO DATA on the Batch list page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch search fetched NO DATA on the Batch list page", Status.BC_FAILED);
					return;
				}
				for(int loop=0;loop<text_PageToolbarList.size();loop++){
					text_totalNoOfTxnRecords = text_PageToolbarList.get(loop);
					System.out.println(text_totalNoOfTxnRecords.getProperty(".text").toString());
					System.out.println("DISABLED: "+text_totalNoOfTxnRecords.getProperty("disabled").toString());
					System.out.println("ARIA-HIDDEN: "+text_totalNoOfTxnRecords.getProperty("aria-hidden").toString());
					System.out.println("ARIA-DISABLED: "+text_totalNoOfTxnRecords.getProperty("aria-disabled").toString());
					System.out.println("ARIA-SECRET: "+text_totalNoOfTxnRecords.getProperty("aria-secret").toString());
					System.out.println("EXISTS:"+text_totalNoOfTxnRecords.exists());
					System.out.println("ENSURE OBJ:"+text_totalNoOfTxnRecords.ensureObjectIsVisible());
				}
				text_totalNoOfTxnRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
				if(text_totalNoOfTxnRecords!= null){
					text_totalNoOfTxnRecords.waitForExistence(10, 2);
					String text_TotalRecordsFetched = text_totalNoOfTxnRecords.getProperty(".text").toString();
					noOfBatchSearchPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(":")+1,text_TotalRecordsFetched.length()).trim();
					System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfBatchSearchPg :"+noOfBatchSearchPg);
					sleep(1);
					//Checking for the number of Batch received record on the Batch list page
					if(noOfBatchSearchPg.isEmpty()
							|| noOfBatchSearchPg==null){
						System.out.println("Batch Number is absent on Batch List page bottom toolbar");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Batch Number is absent on Batch List page bottom toolbar", Status.BC_FAILED);
						return;	
					}			
					else{
						totalBatchNoSearchPg = Integer.parseInt(noOfBatchSearchPg);
						if(totalBatchNoSearchPg == 0){
							System.out.println("No records fetched and displayed on the Batch list page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "No records fetched and displayed on the Batch list page", Status.BC_FAILED);
							return;
						}
						else{
							System.out.println("Batch records fetched and displayed on the Batch List-summary view Page is: "+totalBatchNoSearchPg);
						}
						
					}//End of Batch number check
					
				}//End of Batch number fetching
				else{
					System.out.println("Batch records number is absent on Batch List-summary view Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch records number is absent on Batch List-summary view Page", Status.BC_FAILED);
					return;
				}
		        
			}//End of else if for no record message search
			
			//Component success message
			CRAFT_Report.LogInfo(BusinessComponentName, "Batch records fetched and displayed on the Batch List-summary view Page is: "+totalBatchNoSearchPg, Status.BC_PASSED);			
			
		}
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}

	}//End of ExecuteComponenet
}
	