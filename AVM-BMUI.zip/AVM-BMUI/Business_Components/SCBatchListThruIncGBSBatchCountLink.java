package Business_Components;
import java.util.ArrayList;

import resources.Business_Components.SCBatchListThruIncGBSBatchCountLinkHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxghos1
 */
public class SCBatchListThruIncGBSBatchCountLink extends SCBatchListThruIncGBSBatchCountLinkHelper
{
	/**
	 * Script Name   : <b>SCBatchListThruIncGBSBatchCountLink</b>
	 * Generated     : <b>Dec 29, 2011 4:33:28 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/12/29
	 * @author sxghos1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "SCBatchListThruIncGBSBatchCountLink";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 2)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 2 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 2 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Home page,Home Tab -> Settlement Control Tab
			 * ---Ending on Home page, i.e. , Home tab
			 */

			String tsComponentName = "SCBatchListThruIncGBSBatchCountLink";
			String batchStatus = (String) args[0];			
			String batchStage = (String) args[1];
			String StatusPropText = "";
			String noOfStatus = "";
			String noOfStatusSearchPg = "";


			//Selecting the settlement control tab
			link_settlementControl().waitForExistence(20, 2);
			link_settlementControl().click();
			sleep(20);

			//Searching the existence of the Inc/GBS Processing table	
			String snapShotTable = "Settlement Control Recap";
			StatelessGuiSubitemTestObject link_SelectStatus = null;
			GuiTestObject table_IncGBSProcessing = (GuiTestObject)Util.getMappedObject("Html.SPAN", ".text", snapShotTable);
			if(table_IncGBSProcessing!= null){
				table_IncGBSProcessing.waitForExistence(20, 2);
				//Searching the existence of the suspended link on Inc or GBS processing
				RegularExpression regExSuspendedRow = new RegularExpression("x-auto-[0-9].*_x-auto-[0-9].*",false);
				ArrayList<GuiTestObject> link_SelectStatusList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExSuspendedRow,"Html.TABLE", ".text", batchStatus);
				System.out.println("link_SelectStatusList size: "+link_SelectStatusList.size());
				//Checking for the status
				if(batchStage.equalsIgnoreCase("GBS Processing")
						&& batchStatus.equalsIgnoreCase("Suspended")){
					link_SelectStatus = (StatelessGuiSubitemTestObject) link_SelectStatusList.get(link_SelectStatusList.size()-1);
				}
				else{
					link_SelectStatus = (StatelessGuiSubitemTestObject) link_SelectStatusList.get(0);
				}
							
				if(link_SelectStatus!=null){
					link_SelectStatus.waitForExistence(20, 2);
					StatusPropText = link_SelectStatus.getProperty(".text").toString();
					if(StatusPropText.isEmpty()){
						System.out.println("Status Number text is absent on Inc/GBS Processing table");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Status Number text is absent on Inc/GBS Processing table", Status.BC_FAILED);
						return;	
					}
					noOfStatus = StatusPropText.substring(StatusPropText.lastIndexOf(" "), StatusPropText.length()).trim();
					System.out.println("StatusPropText:"+StatusPropText+" : noOfStatus :"+noOfStatus);
					//Selecting the link with the no of Status
					ArrayList<GuiTestObject> link_SelectStatusNoList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".text",StatusPropText,"Html.A", ".text", noOfStatus);
					System.out.println("link_SelectStatusNoList size: "+link_SelectStatusNoList.size());
					GuiTestObject link_SelectStatusNo = (GuiTestObject) link_SelectStatusNoList.get(0);
					if(link_SelectStatusNo!=null){
						link_SelectStatusNo.waitForExistence(20, 2);
						link_SelectStatusNo.click();
						sleep(20);
					}
					else{
						System.out.println("Status Number link is absent on Inc/GBS Processing table");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Status Number link is absent on Inc/GBS Processing table", Status.BC_FAILED);
						return;
					}
				}
				else{
					System.out.println("Status entry is absent on Inc/GBS Processing table");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Status entry is absent on Inc/GBS Processing table", Status.BC_FAILED);
					return;
				}
				
			}
			else{
				System.out.println("Inc/GBS Processing table is absent in Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Inc/GBS Processing table is absent in Page", Status.BC_FAILED);
				return;
			}//End of Status link click under Inc/GBS Processing table
			
			//Waiting for the batch list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The batch list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The batch list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The batch list is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			//Fetching total number of records fetched on the batch list page
			sleep(5);
			ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
			System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
			GuiTestObject text_totalNoOfSuspendedRecords = null;
			for(int loop=0;loop<text_PageToolbarList.size();loop++){
				text_totalNoOfSuspendedRecords = text_PageToolbarList.get(loop);
				System.out.println(text_totalNoOfSuspendedRecords.getProperty(".text").toString());
			}
			text_totalNoOfSuspendedRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
			if(text_totalNoOfSuspendedRecords!= null){
				text_totalNoOfSuspendedRecords.waitForExistence(10, 2);
				String text_TotalRecordsFetched = text_totalNoOfSuspendedRecords.getProperty(".text").toString();
				noOfStatusSearchPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(":")+1,text_TotalRecordsFetched.length()).trim();
				System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfStatusSearchPg :"+noOfStatusSearchPg);
				sleep(1);
				
				//Checking for the number of batch suspended record on the batch list page
				if(noOfStatusSearchPg.isEmpty()){
					System.out.println("Status Number is absent on Batch List page bottom toolbar");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Status Number is absent on Batch List page bottom toolbar", Status.BC_FAILED);
					return;	
				}
				else if(noOfStatusSearchPg.equalsIgnoreCase(noOfStatus)){
					System.out.println("Status records number on batch List-summary view Page is matching with Status records number on Inc/GBS Processing table");
				}
				else{
					System.out.println("Status records number("+noOfStatus+") on batch List-summary view Page is NOT matching with Status records number("+noOfStatusSearchPg+") on Inc/GBS Processing table");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Status records number("+noOfStatus+") on batch List-summary view Page is NOT matching with Status records number("+noOfStatusSearchPg+") on Inc/GBS Processing table", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Status records number is absent on batch List-summary view Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Status records number is absent on batch List-summary view Page", Status.BC_FAILED);
				return;
			}//End of Fetching total number of records fetched on the batch list page
			
//			//Clicking the home tab
//			link_home().waitForExistence(30, 2);
//			link_home().click();
//			sleep(10);
			
			//Checking the existence of refresh button at the welcome area on home page				
			GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
			if(button_RefreshAtHome!= null){
				button_RefreshAtHome.waitForExistence(20, 2);
				button_RefreshAtHome.ensureObjectIsVisible();
			}
			else{
				System.out.println("Refresh button is absent in home page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
				return;
			}
			
			
			//Component success message
			String cmpSuccessMsg = "#"+batchStatus+" number in Inc/GBS Processing table: "+noOfStatus+
									" #"+batchStatus+" number in Batch list page: "+noOfStatusSearchPg+
										" #The numbers are matching";
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);

		}//End of try
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}//End of catch
		
	}//End of execute component
	
}//End of class
