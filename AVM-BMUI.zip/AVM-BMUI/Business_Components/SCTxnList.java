package Business_Components;

import java.util.ArrayList;

import resources.Business_Components.SCTxnListHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author sxghos1
 */
public class SCTxnList extends SCTxnListHelper
{
	/**
	 * Script Name   : <b>SCTxnList</b>
	 * Generated     : <b>Jan 10, 2012 7:05:29 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2012/01/10
	 * @author sxghos1
	 */
	
	boolean error = false;
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "SCTxnList";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 0)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 0 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 0 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
		return;
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Txn List page,Transaction Search -> Transaction List
			 * ---Ending on Home page, i.e. , Home tab
			 */
			

			//Verifying whether the Change Search button is enabled or disabled			
			GuiTestObject button_ChangeSearch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Change Search");
			if(button_ChangeSearch!= null){
				button_ChangeSearch.waitForExistence(10, 2);
				if(button_ChangeSearch.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Change Search button is enabled rightly in Transaction List page while no records are selected");
					
				}
				else if(button_ChangeSearch.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Change Search button is disabled in Transaction List page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Change Search button is disabled in Transaction List page while no records are selected", Status.BC_FAILED);
					return;
				}
				else{
					System.out.println("Change Search button is enabled rightly in Transaction List page while no records are selected");
				}
			}
			else{
				System.out.println("Change Search button is absent in Transaction Search List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Change Search button is absent in Transaction Search List page", Status.BC_FAILED);
				return;
			}
			
			//Verifying whether the Create Batch button is enabled or disabled			
			GuiTestObject button_CreateBatch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Create Batch");
			if(button_CreateBatch!= null){
				button_CreateBatch.waitForExistence(10, 2);
				if(button_CreateBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Create Batch button is enabled in Transaction List page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Create Batch button is enabled in Transaction List page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_CreateBatch.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Create Batch button is disabled rightly in Transaction List page while no records are selected");
				}
				else{
					System.out.println("Create Batch button is enabled in Transaction List page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Create Batch button is enabled in Transaction List page while no records are selected", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Create Batch button is absent in Transaction Search List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Create Batch button is absent in Transaction Search List page", Status.BC_FAILED);
				return;
			}
			
			//Verifying whether the Void Transaction  button is enabled or disabled			
			GuiTestObject button_VoidTxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Void Transaction");
			if(button_VoidTxn!= null){
				button_VoidTxn.waitForExistence(20, 2);
				if(button_VoidTxn.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Void Transaction  button is enabled in Transaction search list page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Void Transaction  button is enabled in Transaction List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_VoidTxn.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Void Transaction  button is disabled rightly in Transaction search list page while no records are selected");
//					button_VoidTxn.click();
//					sleep(2);
				}
				else{
					System.out.println("Void Transaction  button is enabled in Transaction search list page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Void Transaction  button is enabled in Transaction List Page while no records are selected", Status.BC_FAILED);
					return;
				}
				
			}
			else{
				System.out.println("Void Transaction  button is absent in Transaction search list page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Void Transaction  button is absent in Transaction search list page", Status.BC_FAILED);
				return;
			}//End of Verifying whether the Void Transaction  button is enabled or disabled

			
			//Verifying whether the Add Notes button is enabled or disabled			
			GuiTestObject button_AddNotes = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Add Note");
			if(button_AddNotes!= null){
				button_AddNotes.waitForExistence(10, 2);
				if(button_AddNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("false")){
					System.out.println("Add Note button is enabled in Transaction List page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Add Note button is enabled in Transaction List page while no records are selected", Status.BC_FAILED);
					return;
				}
				else if(button_AddNotes.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Add Note button is disabled rightly in Transaction List page while no records are selected");
				}
				else{
					System.out.println("Add Note button is enabled in Transaction List page while no records are selected");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Add Note button is enabled in Transaction List page while no records are selected", Status.BC_FAILED);
					return;
				}
			}
			else{
				System.out.println("Add Note button is absent in Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Add Note button is absent in Transaction List page", Status.BC_FAILED);
				return;
			}
			
			//Searching Property ID column in the Transaction List page			
			GuiTestObject column_PropertyID = Util.getMappedObject("Html.DIV", ".text", "Property ID");
			if(column_PropertyID!= null){
				column_PropertyID.waitForExistence(10, 2);			
				System.out.println("Property ID column is available on the Transaction List page");				
			}
			else{
				System.out.println("Property ID column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Property ID column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Site ID column in the Transaction List page			
			GuiTestObject column_SiteID = Util.getMappedObject("Html.DIV", ".text", "Site ID");
			if(column_SiteID!= null){
				column_SiteID.waitForExistence(10, 2);			
				System.out.println("Site ID column is available on the Transaction List page");				
			}
			else{
				System.out.println("Site ID column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Site ID column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Site Name column in the Transaction List page			
			GuiTestObject column_SiteName = Util.getMappedObject("Html.DIV", ".text", "Site Name");
			if(column_SiteName!= null){
				column_SiteName.waitForExistence(10, 2);			
				System.out.println("Site Name column is available on the Transaction List page");				
			}
			else{
				System.out.println("Site Name column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Site Name column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Transaction Date/Time column in the Transaction List page			
			GuiTestObject column_TransactionDateTime = Util.getMappedObject("Html.DIV", ".text", "Transaction Date|Time");
			if(column_TransactionDateTime!= null){
				column_TransactionDateTime.waitForExistence(10, 2);			
				System.out.println("Transaction Date/Time column is available on the Transaction List page");				
			}
			else{
				System.out.println("Transaction Date/Time column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Date/Time column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Reference No. column in the Transaction List page			
			GuiTestObject column_ReferenceNo = Util.getMappedObject("Html.DIV", ".text", "Reference No.");
			if(column_ReferenceNo!= null){
				column_ReferenceNo.waitForExistence(10, 2);			
				System.out.println("Reference No. column is available on the Transaction List page");				
			}
			else{
				System.out.println("Reference No. column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Reference No. column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Tran Type column in the Transaction List page			
			GuiTestObject column_TranType = Util.getMappedObject("Html.DIV", ".text", "Tran Type");
			if(column_TranType!= null){
				column_TranType.waitForExistence(10, 2);			
				System.out.println("Tran Type column is available on the Transaction List page");				
			}
			else{
				System.out.println("Tran Type column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Tran Type column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Card Type column in the Transaction List page			
			GuiTestObject column_CardType = Util.getMappedObject("Html.DIV", ".text", "Card Type");
			if(column_CardType!= null){
				column_CardType.waitForExistence(10, 2);			
				System.out.println("Card Type column is available on the Transaction List page");				
			}
			else{
				System.out.println("Card Type column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Card Type column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Account No. column in the Transaction List page			
			GuiTestObject column_AccountNo = Util.getMappedObject("Html.DIV", ".text", "Account No.");
			if(column_AccountNo!= null){
				column_AccountNo.waitForExistence(10, 2);			
				System.out.println("Account No. column is available on the Transaction List page");				
			}
			else{
				System.out.println("Account No. column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Account No. column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Transaction Amount column in the Transaction List page			
			GuiTestObject column_TransactionAmount = Util.getMappedObject("Html.DIV", ".text", "Transaction Amount");
			if(column_TransactionAmount!= null){
				column_TransactionAmount.waitForExistence(10, 2);			
				System.out.println("Transaction Amount column is available on the Transaction List page");				
			}
			else{
				System.out.println("Transaction Amount column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Amount column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Auth Code column in the Transaction List page			
			GuiTestObject column_AuthCode = Util.getMappedObject("Html.DIV", ".text", "Auth Code");
			if(column_AuthCode!= null){
				column_AuthCode.waitForExistence(10, 2);			
				System.out.println("Auth Code column is available on the Transaction List page");				
			}
			else{
				System.out.println("Auth Code column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Auth Code column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Transaction Status column in the Transaction List page			
			GuiTestObject column_TransactionStatus = Util.getMappedObject("Html.DIV", ".text", "Transaction Status");
			if(column_TransactionStatus!= null){
				column_TransactionStatus.waitForExistence(10, 2);			
				System.out.println("Transaction Status column is available on the Transaction List page");				
			}
			else{
				System.out.println("Transaction Status column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Status column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Settlement Currency column in the Transaction List page			
			GuiTestObject column_SettlementCurrency = Util.getMappedObject("Html.DIV", ".text", "Settlement Currency");
			if(column_SettlementCurrency!= null){
				column_SettlementCurrency.waitForExistence(10, 2);			
				System.out.println("Settlement Currency column is available on the Transaction List page");				
			}
			else{
				System.out.println("Settlement Currency column is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Settlement Currency column is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Searching Select All check box in the Transaction List page			
			GuiTestObject checkbox_SelectAll = Util.getMappedObject("Html.DIV", ".text", "All");
			if(checkbox_SelectAll!= null){
				checkbox_SelectAll.waitForExistence(10, 2);			
				System.out.println("Select All checkbox is available on the Transaction List page");				
			}
			else{
				System.out.println("Select All checkbox is not available on the Transaction List page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Select All checkbox is not available on the Transaction List page", Status.BC_FAILED);
				return;			
			}
			
			//Selecting the home link to end in the home page				
			link_home().waitForExistence(10, 2);
			link_home().click();
			
			//Waiting for the home page to populate
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Transaction list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Transaction list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Transaction List is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);			
			
			//Component success message
			String cmpSuccessMsg = "SC Transaction List is having all the buttons,columns and select All checkbox properly";
			System.out.println(cmpSuccessMsg);
			CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);			

		}//End of try block 
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();
//			e.printStackTrace();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);

		}

	}//End of Execute Component()
	
}//End of class

