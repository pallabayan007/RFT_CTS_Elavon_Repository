package Business_Components;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import resources.Business_Components.TxnSearchHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class TxnSearch extends TxnSearchHelper
{
	/**
	 * Script Name   : <b>TransactionSearch</b>
	 * Generated     : <b>Oct 20, 2011 4:25:07 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/10/20
	 * @author axbane1
	 */
	
	boolean error = false;
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "TransactionSearch";
	
	
	public void testMain(Object[] args) 
	{
		setCurrentLogFilter(DISABLE_LOGGING);
		// TODO Insert code here
		try
		{
			if (args.length < 14)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 13 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 13 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			
		}
		
	}//End of testMain()
	
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			String acNo = (String) args[0];
			String refNo = (String) args[1];
			String clientRefNo = (String) args[2];
			String tokenId = (String) args[3];
			String sysBatchNo = (String) args[4];
			String siteId = (String) args[5];
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			String yesterdayDt = new SimpleDateFormat("MM/dd/yyyy").format(cal.getTime());
			String startDate = (String) args[6];
			cal.add(Calendar.DATE, 2);
			String endDt = (String) args[7];
			String batchStatus = (String) args[8];
			batchStatus = batchStatus.toUpperCase();
			int listPosition = 0;
			String viewTranBy = (String) args[9];
			String tranType = (String) args[10];
			String txnId = (String) args[11];
			String statusList = (String) args[12];
			String enterDate = (String) args[13];
			String noOfTxnSearchPg = "";
			int totalTxnNoSearchPg = 0;
					
			System.out.println(""+yesterdayDt);
			System.out.println(""+endDt);
			
			//Selecting the transaction Management tab
			link_transactionManagement().waitForExistence(10, 2);
			link_transactionManagement().click();
			sleep(5);

			//Selecting the transaction search tab		
			GuiTestObject button_TranSearch = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Transaction Search");
			if(button_TranSearch!= null){
				button_TranSearch.waitForExistence(20, 2);
				button_TranSearch.click();
				sleep(5);
			}
			else{
				System.out.println("Transaction Search Tab is absent in Transaction Search Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Search Tab is absent in Transaction Search Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Account number			
			TextGuiTestObject text_AcNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "accountLast4");
			if(text_AcNo!= null){
				text_AcNo.waitForExistence(10, 2);
				text_AcNo.click();
				text_AcNo.setText(acNo);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Mandatory field(s) Account number is absent in transaction search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Account number is absent in transaction search page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Reference number			
			TextGuiTestObject text_RefNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "referenceNumber");
			if(text_RefNo!= null){
				text_RefNo.waitForExistence(10, 2);
				text_RefNo.click();
				text_RefNo.setText(refNo);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Mandatory field(s) Reference number is absent in transaction search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Reference number is absent in transaction search page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Client Reference number			
			TextGuiTestObject text_ClientRefNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "clientReferenceNumber");
			if(text_ClientRefNo!= null){
				text_ClientRefNo.waitForExistence(10, 2);
				text_ClientRefNo.click();
				text_ClientRefNo.setText(clientRefNo);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Mandatory field(s) Client Reference number is absent in transaction search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Client Reference number is absent in transaction search page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Token number			
			TextGuiTestObject text_TokenId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "uniqueId");
			if(text_TokenId!= null){
				text_TokenId.waitForExistence(10, 2);
				text_TokenId.click();
				text_TokenId.setText(tokenId);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Mandatory field(s) Token is absent in transaction search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Token is absent in transaction search page", Status.BC_FAILED);
				return;
			}
			
			//Selecting System Batch No			
			TextGuiTestObject text_SysBatchNo = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "lightningBatchNumber");
			if(text_SysBatchNo!= null){
				text_SysBatchNo.waitForExistence(10, 2);
				text_SysBatchNo.click();
				text_SysBatchNo.setText(sysBatchNo);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Mandatory field(s) System Batch number is absent in transaction search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) System Batch number is absent in transaction search page", Status.BC_FAILED);
				return;
			}
			
			//Selecting site id			
			TextGuiTestObject text_SiteId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "siteIdStr");
			if(text_SiteId!= null){
				text_SiteId.waitForExistence(10, 2);
				text_SiteId.click();
				text_SiteId.setText(siteId);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Mandatory field(s) Site Id is absent in transaction search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Site Id is absent in transaction search page", Status.BC_FAILED);
				return;
			}
			
			//Searching and selecting Enter Date check-box			
			GuiTestObject checkbox_EnterDt = Util.getMappedObject("Html.DIV", ".text", "Enter Date");
			if(checkbox_EnterDt!= null 
					&& checkbox_EnterDt.ensureObjectIsVisible()){
				checkbox_EnterDt.waitForExistence(10, 2);
				if(enterDate.equalsIgnoreCase("Yes")
						&& !sysBatchNo.isEmpty()){
					checkbox_EnterDt.click();
					//Selecting Start Date			
					TextGuiTestObject text_StartDt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", yesterdayDt);
					if(text_StartDt!= null){
						text_StartDt.waitForExistence(10, 2);
						text_StartDt.click();
						text_StartDt.setText(startDate);
						sleep(2);
//						browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
					}
					else{
						System.out.println("Mandatory field(s) Start Date is absent in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Start Date is absent in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}//End of Start Date
					
					//Selecting End Date	
					ArrayList<GuiTestObject> text_EndDtList = Util.getGWTMappedObjects("Html.INPUT.text", ".value", Util.getCurrentDatenTime("MM/dd/yyyy"));
					if(text_EndDtList.size()!=0){
						TextGuiTestObject text_EndDt = (TextGuiTestObject) text_EndDtList.get(text_EndDtList.size()-1);
						if(text_EndDt!= null){
							text_EndDt.waitForExistence(10, 2);
							text_EndDt.click();
							text_EndDt.setText(endDt);
							sleep(2);
//							browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
						}
						else{
							System.out.println("Mandatory field(s) End Date is absent in Settlement Control batch search page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in Settlement Control batch search page", Status.BC_FAILED);
							return;
						}
					}
					else{
						System.out.println("Mandatory field(s) End Date not found in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date not found in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}//End of End Date
				}
				else{
					System.out.println("Enter date is not needed");
				}										
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				//Selecting Start Date			
				TextGuiTestObject text_StartDt = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", yesterdayDt);
				if(text_StartDt!= null){
					text_StartDt.waitForExistence(10, 2);
					text_StartDt.click();
					text_StartDt.setText(startDate);
					sleep(2);
//					browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
				}
				else{
					System.out.println("Mandatory field(s) Start Date is absent in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Start Date is absent in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of Start Date
				
				//Selecting End Date	
				ArrayList<GuiTestObject> text_EndDtList = Util.getGWTMappedObjects("Html.INPUT.text", ".value", Util.getCurrentDatenTime("MM/dd/yyyy"));
				if(text_EndDtList.size()!=0){
					TextGuiTestObject text_EndDt = (TextGuiTestObject) text_EndDtList.get(text_EndDtList.size()-1);
					if(text_EndDt!= null){
						text_EndDt.waitForExistence(10, 2);
						text_EndDt.click();
						text_EndDt.setText(endDt);
						sleep(2);
//						browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
					}
					else{
						System.out.println("Mandatory field(s) End Date is absent in Settlement Control batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in Settlement Control batch search page", Status.BC_FAILED);
						return;
					}
				}
				else{
					System.out.println("Mandatory field(s) End Date not found in Settlement Control batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date not found in Settlement Control batch search page", Status.BC_FAILED);
					return;
				}//End of End Date
				
			}//End of Enter date
		
			
			/*==========================
			 * Selecting the Batch Status
			 *///=======================				
			
			//Searching for the status position in the status list
			int statusCount = (int) Util.commaSeparatedWordCount(statusList);
			String[] statusListDet = new String[statusCount];
			statusListDet = (String[]) Util.commaSeparatedWordDetails(statusList, Util.commaSeparatedWordCount(statusList)); 
			for(int loopCount=0;loopCount<statusListDet.length;loopCount++){
				if(statusListDet[loopCount].toUpperCase().equalsIgnoreCase(batchStatus)){
					listPosition = loopCount;
					break;
				}
				else{
					continue;
				}
			}//End of Searching for the status position in the status list
			
			if(!batchStatus.isEmpty()
					&& listPosition >= 0){			
				//Selecting Status	
				ArrayList<GuiTestObject> select_BatchStatusList = Util.getGWTMappedObjects("Html.DIV", ".text", batchStatus);
				System.out.println(select_BatchStatusList.size());
				GuiTestObject select_BatchStatus = null;
				//Checking whether the list box exists or not
				if(select_BatchStatusList.size()!=0){
					//For statement w.r.t. status list box mapping
					for(int i=0;i<select_BatchStatusList.size();i++){
						System.out.println("I: "+i);
						System.out.println("Id: "+select_BatchStatusList.get(i).getProperty(".id").toString());
						System.out.println("Text: "+select_BatchStatusList.get(i).getProperty(".text").toString());
						System.out.println("ROLE: "+select_BatchStatusList.get(i).getProperty("role").toString());
						//Checking and mapping the status list box
						if(select_BatchStatusList.get(i).getProperty("role").toString().equalsIgnoreCase("listbox")){
							select_BatchStatus = select_BatchStatusList.get(i);
							break;
						}
						else{
							continue;
						}//End of else for Checking and mapping the status list box
						
					}//End of for statement w.r.t. status list box mapping
					
					//Selecting the status
					if(select_BatchStatus!=null){
						select_BatchStatus.click();
						browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtUp}");		
						browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtUp}");
						//Browsing to the status by using down Arrow key
						for(int loop=0;loop<listPosition;loop++){
							browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{ExtDown}");
							sleep(1);
						}//End of Browsing to the status by using down Arrow key
					}
					else{
						System.out.println("Batch Status listbox not found in batch search page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Batch Status listbox not found in batch search page", Status.BC_FAILED);
						return;
					}//End of Selecting the status
					
				}//End of if for Checking whether the list box exists or not
				else{
					System.out.println("Batch Status listbox is absent in batch search page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Batch Status listbox is absent in batch search page", Status.BC_FAILED);
					return;
				}//Checking whether the list box exists or not	
			}//End of if for file status & list position validation

			/*+++++++++++++++++++++++++++++++++
			 * End of Selecting the Batch Status
			 *///++++++++++++++++++++++++++++++
			
			
			
			//Adding View Transaction By
			TextGuiTestObject text_ViewTranBy = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".value", "All");
			if(text_ViewTranBy!=null){			
				text_ViewTranBy.click();			
				text_ViewTranBy.setText(viewTranBy);
				sleep(2);
				//Selecting the View Transaction By from the drop down
//				RegularExpression regExTxnByDropDwn = new RegularExpression("x-auto-[0-9].*",false);
				if(viewTranBy.isEmpty()){
					System.out.println("The view transaction type search string is empty");
				}
				else{
//					ArrayList<GuiTestObject> list_ViewTranByList = Util.getGWTMappedObjects("Html.DIV",".id",regExTxnByDropDwn, "Html.DIV",".text", viewTranBy);
					ArrayList<GuiTestObject> list_ViewTranByList = Util.getGWTMappedObjects("Html.DIV",".text", viewTranBy);
					GuiTestObject list_ViewTranBy = list_ViewTranByList.get(list_ViewTranByList.size()-1);
					for(int i=0;i<list_ViewTranByList.size();i++){
						System.out.println("list_ViewTranByList: "+list_ViewTranByList.get(i).getProperty(".text").toString());
					}
					if(list_ViewTranBy!=null){
						System.out.println("Inside the View Transaction By dropdown list");	
						list_ViewTranBy.click();
					}
					else{
						System.out.println("Mandatory Field(s) View Transaction By list dropdown not found on Transaction Search Page");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) View Transaction By list dropdown not found on Transaction Search Page", Status.BC_FAILED);
						return;
					}
				}
				//End of selection of View Transaction By from drop down
				System.out.println(""+text_ViewTranBy.getScreenPoint());
				//Setting the focus out of the view transaction by field 
//				if(text_ViewTranBy.hasFocus()){
//					text_ViewTranBy.setProperty(".hasFocus", false);
//				}
			}
			else{
				System.out.println("Mandatory Field(s) View Transaction By list dropdown not found on Transaction Search Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) View Transaction By list dropdown not found on Transaction Search Page", Status.BC_FAILED);
				return;
			}//End of View Transaction By
			
//			//Selecting Batch Status
//			String batchStatList = "BACK OFFICE COMPLETE " +
//									"BACK OFFICE DUP RE-RELEASE BACK OFFICE DUPLICATE SUSPENDE BACK OFFICE " +
//									"ERROR SUSPENDED BACK OFFICE IN PROGRESS BACK OFFICE PKG IN PROGRESS BACK " +
//									"OFFICE RE-RELEASE BACK OFFICE TRANSMIT ERROR BATCH DATA ERROR BATCH DUPLICATE " +
//									"SUSPENDED BATCH FORCED SUSPENDED BATCH OUT OF BALANCE SUSPENDED BATCH PARTIAL " +
//									"DUPLICATE SUSPEN BATCH SETUP ERROR CAPTURED CONFIRMED DELETED ERROR GOOD " +
//									"BATCH IN PROGRESS OPEN PENDING REVERSAL BATCH RELEASE SETTLE SETTLED " +
//									"SUSPENDED SUSPENSE DELETED TIP COLLECTOR SUSPENDED TPP FILE OUT OF " +
//									"BALANCE TPP REJECTED BATCH TPP REJECTED SUB-BATCH TRANSMITTED USER " +
//									"DEFINED DELETED USER DEFINED OPEN";
//			ArrayList<GuiTestObject> text_BatchStatList = Util.getGWTMappedObjects("Html.DIV", ".text", batchStatList);
//			for(int i=0;i<text_BatchStatList.size();i++){
//				System.out.println(""+text_BatchStatList.get(i).getProperty(".text").toString());
//				System.out.println(""+text_BatchStatList.get(i).getProperty(".id").toString());			
//			}
//			if(text_BatchStat!= null){
//				text_BatchStat.waitForExistence(10, 2);
//				text_BatchStat.click();
////				text_BatchStat.setText(endDt);
//				sleep(2);
////				browser_htmlBrowsser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");	
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputChars("{TAB}");
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputChars("{TAB}");
//				sleep(2);
//			}
//			else{
//				error = true;
////				Util.scenarioStatus = false;
////				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) End Date is absent in transaction search page", Status.BC_FAILED);
////				return;
//			}	
		
			//Adding Transaction Type		
//			RegularExpression regExTranTypeText = new RegularExpression("x-auto-[0-9].*",false);
//			RegularExpression regExTranTypeTextChild = new RegularExpression("x-auto-[0-9].*-input",false);
//			ArrayList<GuiTestObject> text_TranTypeList = Util.getGWTMappedObjects("Html.DIV",".id",regExTranTypeText, "Html.DIV",".id", RegularExpression.toString(regExTranTypeTextChild));
//			for(int i=0;i<text_TranTypeList.size();i++){
//				System.out.println("text_TranTypeList: "+text_TranTypeList.get(i).getProperty(".id").toString());
//			}
//			TextGuiTestObject text_TranType = (TextGuiTestObject) text_TranTypeList.get(0);
			RegularExpression regExTranTypeTextChild = new RegularExpression("x-auto-[0-9].*-input",false);
			ArrayList<GuiTestObject> text_TranTypeList = Util.getGWTMappedObjects("Html.INPUT.text",".id",regExTranTypeTextChild, ".className"," x-form-field x-form-text  x-form-empty-field");
//			ArrayList<GuiTestObject> text_TranTypeList = Util.getGWTMappedObjects(".className"," x-form-field x-form-text  x-form-empty-field");
			System.out.println("text_TranTypeList: "+text_TranTypeList.size());
			TextGuiTestObject text_TranType = null;
			
			if(text_TranTypeList.size()!=0){	
				//Searching for the transaction type text box object
				for(int i=0;i<text_TranTypeList.size();i++){
					System.out.println("text_TranTypeList Name: "+text_TranTypeList.get(i).getDescriptiveName());
					System.out.println("text_TranTypeList: "+text_TranTypeList.get(i).getProperty(".id").toString());
//					if(text_TranTypeList.get(i).getProperty(".id").toString().equals(regExTranTypeTextChild)){
						text_TranType = (TextGuiTestObject) text_TranTypeList.get(i);
//						break;
//					}
//					else{
//						System.out.println("Not Matched continue"+text_TranTypeList.get(i).getProperty(".id").toString());
//						continue;
//					}
				}
				if(text_TranType!=null){			
//					text_TranType.click();			
//					text_TranType.setText(tranType);
//					sleep(2);
					//Selecting the Transaction Type from the drop down
//					RegularExpression regExTranTypeDropDwn = new RegularExpression("x-auto-[0-9].*",false);
					if(tranType.isEmpty()){
						System.out.println("The transaction type contains no value to search for");
					}
					else{
						text_TranType.click();			
						text_TranType.setText(tranType);
						sleep(2);
//						ArrayList<GuiTestObject> list_TranTypeList = Util.getGWTMappedObjects("Html.DIV",".id",regExTranTypeDropDwn, "Html.DIV",".text", tranType);
						ArrayList<GuiTestObject> list_TranTypeList = Util.getGWTMappedObjects("Html.DIV",".text", tranType);
						GuiTestObject list_TranType = list_TranTypeList.get(list_TranTypeList.size()-1);
						for(int i=0;i<list_TranTypeList.size();i++){
							System.out.println("list_TranTypeList: "+list_TranTypeList.get(i).getProperty(".text").toString());
						}
						if(list_TranType!=null){
							System.out.println("Inside the Transaction Type dropdown list");	
							list_TranType.click();
						}
						else{
							System.out.println("Mandatory Field(s) Transaction Type list dropdown not found on Transaction Search Page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Transaction Type list dropdown not found on Transaction Search Page", Status.BC_FAILED);
							return;
						}
					}
					//End of selection the Transaction Type from the drop down
				}
				else{
					System.out.println("Mandatory Field(s) Transaction Type text box not found on Transaction Search Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Transaction Type text box not found on Transaction Search Page", Status.BC_FAILED);
					return;
				}//End of else for text transaction type selection
			}
			else{
				System.out.println("Mandatory Field(s) Transaction Type text box list not found on Transaction Search Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Transaction Type text box list not found on Transaction Search Page", Status.BC_FAILED);
				return;			
			}//End of Transaction Type
			
			//Selecting transaction id			
			TextGuiTestObject text_TxnId = (TextGuiTestObject) Util.getMappedObject("Html.INPUT.text", ".name", "transactionId");
			if(text_TxnId!= null){
				text_TxnId.waitForExistence(10, 2);
				text_TxnId.click();
				text_TxnId.setText(txnId);
				sleep(2);
//				browser_htmlBrowser(document_elavonPortal(),DEFAULT_FLAGS).inputKeys("{TAB}");		
			}
			else{
				System.out.println("Mandatory field(s) Transaction Id is absent in transaction search page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Transaction Id is absent in transaction search page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Search button			
			GuiTestObject button_Search = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Search");
			if(button_Search!= null){
				button_Search.waitForExistence(10, 2);
				button_Search.click();
				sleep(20);
			}
			else{
				System.out.println("Search button is absent in Transaction Search Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Search button is absent in Transaction Search Page", Status.BC_FAILED);
				return;
			}
			
			//Waiting for the Txn list to populate on the batch list page and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Transaction list is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Transaction list is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Transaction List is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);
			
			//Checking whether the search result has data or not
			GuiTestObject msg_NoSearchResult = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", "No records found for Transaction List.");
			if(msg_NoSearchResult!= null){
				msg_NoSearchResult.waitForExistence(30, 2);
				System.out.println("Search result has no data in Transaction List Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Search result has no data in Transaction Search List Page", Status.BC_FAILED);
				return;
			}
			else if(msg_NoSearchResult== null){
				//Fetching total number of records fetched on the Txn list page
				ArrayList<GuiTestObject> text_PageToolbarList = Util.getGWTSelectChildMappedObjects("Html.TABLE",".className","x-toolbar-ct","Html.DIV", ".text", "Total number of records:");
				System.out.println("text_PageToolbarList size: "+text_PageToolbarList.size());
				GuiTestObject text_totalNoOfTxnRecords = null;
				if(text_PageToolbarList.size()==0
						|| !text_PageToolbarList.get(text_PageToolbarList.size()-1).ensureObjectIsVisible()){
					System.out.println("Transaction search fetched NO DATA on the transaction list page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction search fetched NO DATA on the transaction list page", Status.BC_FAILED);
					return;
				}
				for(int loop=0;loop<text_PageToolbarList.size();loop++){
					text_totalNoOfTxnRecords = text_PageToolbarList.get(loop);
//					System.out.println(text_totalNoOfTxnRecords.getProperty(".text").toString());
//					System.out.println("DISABLED: "+text_totalNoOfTxnRecords.getProperty("disabled").toString());
//					System.out.println("ARIA-HIDDEN: "+text_totalNoOfTxnRecords.getProperty("aria-hidden").toString());
//					System.out.println("ARIA-DISABLED: "+text_totalNoOfTxnRecords.getProperty("aria-disabled").toString());
//					System.out.println("ARIA-SECRET: "+text_totalNoOfTxnRecords.getProperty("aria-secret").toString());
//					System.out.println("EXISTS:"+text_totalNoOfTxnRecords.exists());
//					System.out.println("ENSURE OBJ:"+text_totalNoOfTxnRecords.ensureObjectIsVisible());
				}
				text_totalNoOfTxnRecords = text_PageToolbarList.get(text_PageToolbarList.size()-1);
				if(text_totalNoOfTxnRecords!= null){
					text_totalNoOfTxnRecords.waitForExistence(10, 2);
					String text_TotalRecordsFetched = text_totalNoOfTxnRecords.getProperty(".text").toString();
					noOfTxnSearchPg = text_TotalRecordsFetched.substring(text_TotalRecordsFetched.lastIndexOf(":")+1,text_TotalRecordsFetched.length()).trim();
					System.out.println("text_TotalRecordsFetched: "+text_TotalRecordsFetched+" : noOfTxnSearchPg :"+noOfTxnSearchPg);
					sleep(1);
					//Checking for the number of Txn received record on the Txn list page
					if(noOfTxnSearchPg.isEmpty()
							|| noOfTxnSearchPg==null){
						System.out.println("Transaction Number is absent on Transaction List page bottom toolbar");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Transaction Number is absent on Transaction List page bottom toolbar", Status.BC_FAILED);
						return;	
					}			
					else{
						totalTxnNoSearchPg = Integer.parseInt(noOfTxnSearchPg);
						if(totalTxnNoSearchPg == 0){
							System.out.println("No records fetched and displayed on the transaction list page");
							error = true;
							Util.scenarioStatus = false;
							CRAFT_Report.LogInfo(tsComponentName, "No records fetched and displayed on the transaction list page", Status.BC_FAILED);
							return;
						}
						else{
							System.out.println("Transaction records fetched and displayed on the Transaction List-summary view Page is: "+totalTxnNoSearchPg);
						}
						
					}//End of Txn number check
					
				}//End of Txn number fetching
				else{
					System.out.println("Transaction records number is absent on Transaction List-summary view Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction records number is absent on Transaction List-summary view Page", Status.BC_FAILED);
					return;
				}
		        
			}//End of else if for no record message search			
			
			//Component success message
			CRAFT_Report.LogInfo(BusinessComponentName, "Transaction records fetched and displayed on the Transaction List-summary view Page is: "+totalTxnNoSearchPg, Status.BC_PASSED);			
			
		}
		catch(Exception e){
			e.getMessage();
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occured on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}

	}//End of ExecuteComponenet
	
}//End of class

