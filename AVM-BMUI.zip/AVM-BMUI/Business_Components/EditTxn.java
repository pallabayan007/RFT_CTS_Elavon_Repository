package Business_Components;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import resources.Business_Components.EditTxnHelper;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author axbane1
 */
public class EditTxn extends EditTxnHelper
{
	/**
	 * Script Name   : <b>EditTxn</b>
	 * Generated     : <b>Nov 23, 2011 5:03:32 AM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2011/11/23
	 * @author axbane1
	 */
	
	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "EditTxn";
	
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
		try
		{
			if (args.length < 3)
			{	
				Util.scenarioStatus = false;
				Util.skipKeyword = true;
				System.out.println( "Expected at least 3 args, but got:"+args.length);
				CRAFT_Report.LogInfo("Input Error","Expected at least 3 inputs, but got:"+args.length+" in "+BusinessComponentName,Status.DONE);
				return;
			}
			else
			{
				System.out.println( "Got: "+args.length+" args");
						        				
				CRAFT_Report.LogInfo("Start Business Component","Invoking Component: "+this.getScriptName(),Status.DONE);
				ExecuteComponent(args);
				CRAFT_Report.LogInfo("End Business Component","Exiting Component: "+this.getScriptName(),Status.DONE);
				//Invoking user log off in case of error
				if(error){	
					Util.scenarioStatus = false;
					Util.skipKeyword = true;
					//Calling business component user log off
					String businessComponent = "Business_Components.UserLogoff";			
					callScript(businessComponent);
					//---------End of business component---------
					return;
				}
						       		
			}		
					
		}//End of try block
		catch(Exception ex)
		{
			CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing: "+BusinessComponentName,ex.toString(),Status.FAIL);
			return;
		}
		
	}//End of testMain()
	
	//Executable user interface actions
	public void ExecuteComponent(Object[] args)
	{
		//Place your Code here
		try{
			/*
			 * ---Starting from Transaction List page, i.e. , transaction search tab
			 * ---Ending on Home page, i.e. , Home tab
			 */
			
			String tsComponentName = "EditTxn";			
			String refNo = (String) args[0];
			String selectTxnString = "";
			String txnAmt = (String) args[1];
			String merchantBatchNo = (String) args[2];
			Random rand = new Random();
			String authCode ="Test"+Integer.toString(rand.nextInt(10)+1);
			String chargeType = "Default";
			String chargeDesc = "Lodging";
			String checkIn = "03/02/2009";			
			String checkOut = new SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().getTime());
			String txnId = "";
			
			//Setting the Txn select string in case of no ref no.
			if(refNo.isEmpty()){
				ArrayList<GuiTestObject> list_SelectTxnSearchResultList = new ArrayList<GuiTestObject>();
				selectTxnString = "USD";
				//Selecting the records to edit in transaction search list page
				RegularExpression regExTxnSearchUSD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
				list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchUSD,"Html.TABLE", ".text", selectTxnString);
				System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
				if(list_SelectTxnSearchResultList.size()==0){
					selectTxnString = "GBP";
					//Selecting the records to edit in transaction search list page
					RegularExpression regExTxnSearchGBP = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
					list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchGBP,"Html.TABLE", ".text", selectTxnString);
					System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
					if(list_SelectTxnSearchResultList.size()==0){
						selectTxnString = "AUD";
						//Selecting the records to edit in transaction search list page
						RegularExpression regExTxnSearchAUD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
						list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchAUD,"Html.TABLE", ".text", selectTxnString);
						System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
						if(list_SelectTxnSearchResultList.size()==0){
							selectTxnString = "EUR";
							//Selecting the records to edit in transaction search list page
							RegularExpression regExTxnSearchEUR = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
							list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchEUR,"Html.TABLE", ".text", selectTxnString);
							System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
							if(list_SelectTxnSearchResultList.size()==0){
								selectTxnString = "CAD";
								//Selecting the records to edit in transaction search list page
								RegularExpression regExTxnSearchCAD = new RegularExpression("transactionListGrid_x-auto-[0-9].*",false);
								list_SelectTxnSearchResultList = Util.getGWTSelectChildMappedObjects("Html.DIV",".id",regExTxnSearchCAD,"Html.TABLE", ".text", selectTxnString);
								System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());							
							}//End of CAD select
						}//End of EUR select
					}//End of AUD select
				}//End of GBP select
				
				String searchedTxnString = list_SelectTxnSearchResultList.get(0).getProperty(".text").toString();
				searchedTxnString = searchedTxnString.substring(searchedTxnString.indexOf(":")+6, searchedTxnString.length()).trim();
				searchedTxnString = searchedTxnString.substring(0, searchedTxnString.indexOf(" ")).trim();
				System.out.println("searchedTxnString: "+searchedTxnString);
				refNo = searchedTxnString;
				
			}//End of if for Setting the Txn select string in case of no ref no.
			
			//Selecting the first Txn in list by clicking its ref no link			
			ArrayList<GuiTestObject> list_SelectTxnSearchResultList = Util.getGWTMappedObjects("Html.A", ".text", refNo);
			GuiTestObject link_RefNo = null;
			System.out.println("list_SelectTxnSearchResultList size: "+list_SelectTxnSearchResultList.size());
			if(list_SelectTxnSearchResultList.size()>0){
				link_RefNo = list_SelectTxnSearchResultList.get(0);
				//Checking for the existence of the ref no link
				if(link_RefNo != null){
					link_RefNo.waitForExistence(20, 2);
					link_RefNo.click();
					sleep(10);
				}
				else{
					System.out.println("No matching link found in Transaction Search List Page for Reference No.: "+refNo);
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "No matching link found in Transaction Search List Page for Reference No.: "+refNo, Status.BC_FAILED);
					return;
				}//End of Checking for the existence of the ref no link
			}//End of if for ref no link check
			else{
				System.out.println("No matching record found in Transaction Search List Page for Reference No.: "+refNo);
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "No matching record found in Transaction Search List Page for Reference No.: "+refNo, Status.BC_FAILED);
				return;
			}
			
			//Selecting Edit Txn button			
			GuiTestObject button_EditTxn = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Edit");
			if(button_EditTxn!= null){
				button_EditTxn.waitForExistence(10, 2);
				button_EditTxn.ensureObjectIsVisible();
				//Checking whether the edit button is enabled or disabled
				if(button_EditTxn.getProperty("aria-disabled").toString().equalsIgnoreCase("true")){
					System.out.println("Edit button is disabled in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Edit button is disabled in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
				else{
					button_EditTxn.click();
					sleep(2);
				}			
				//End of Checking whether the edit button is enabled or disabled
			}
			else{
				System.out.println("Edit button is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Edit button is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Edit Cancel button			
			GuiTestObject button_EditCancel = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".value", "Cancel");
			if(button_EditCancel!= null){
				button_EditCancel.waitForExistence(10, 2);				
				//Checking whether the button_EditCancel button is enabled & visible or not
				if(!button_EditCancel.getProperty("aria-disabled").toString().equalsIgnoreCase("true")
						&& button_EditCancel.ensureObjectIsVisible()){
					System.out.println("Fields are editable in View Transaction Details Page");					
				}
				else{
					System.out.println("Fields are not editable in View Transaction Details Page even after clicking the edit button");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Fields are not editable in View Transaction Details Page even after clicking the edit button", Status.BC_FAILED);
					return;
				}			
				//End of Checking whether the button_EditCancel button is enabled & visible or not
			}
			else{
				System.out.println("Cancel button is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Cancel button is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
		
//		// HTML Browser
//		// Document: ElavonPortal: https://gatewaytest.novainfo.net/ui/portal.html?ticket=ST-198-Ofs21aoOZ2l9gzCfkDQ9-cas
//		link_basicTransaction().click();
//		link_expandedDetail().click();
//		link_customer().click();
//		link_compliance().click();
			
			
		//Selecting Basic Txn tab			
		ArrayList<GuiTestObject> link_BasicTxnList = Util.getGWTMappedObjects("Html.A", ".text", "Basic Transaction");
		GuiTestObject link_BasicTxn = null;
		if(link_BasicTxnList.size()==0){
			System.out.println("Basic Transaction Tab returns nil in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Basic Transaction Tab returns nil in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		link_BasicTxn = link_BasicTxnList.get(link_BasicTxnList.size()-1);
		if(link_BasicTxn!= null){
			link_BasicTxn.waitForExistence(10, 2);
			link_BasicTxn.ensureObjectIsVisible();
			link_BasicTxn.click();
			sleep(2);
			
			//Selecting Transaction Amount text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TxnAmtList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "transactionAmount");
			TextGuiTestObject text_TxnAmt = null;
			if(text_TxnAmtList.size()==0){
				System.out.println("Transaction Amount returns nil absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Amount returns nil absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_TxnAmtList.size();i++){
				System.out.println("Id: "+text_TxnAmtList.get(i).getProperty(".id").toString());			
			}
			text_TxnAmt = (TextGuiTestObject)text_TxnAmtList.get(Math.round(text_TxnAmtList.size()/2));			
			if(text_TxnAmt!= null){
				text_TxnAmt.waitForExistence(10, 2);
				System.out.println("text_TxnAmt.getProperty: "+text_TxnAmt.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_TxnAmt.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Transaction Amount textbox is disabled in View Transaction Details Page");
				}
				else if(text_TxnAmt.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Txn Amount");					
					text_TxnAmt.click();
					text_TxnAmt.setText(txnAmt);
					sleep(1);
				}//End of Checking whether readonly or not				
			}
			else{
				System.out.println("Transaction Amount textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Amount textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Merchant Batch Number text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_MerchantBatchNoList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "merchantBatchNumber");
			TextGuiTestObject text_MerchantBatchNo = null;
			if(text_MerchantBatchNoList.size()==0){
				System.out.println("Merchant Batch Number returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Merchant Batch Number returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_MerchantBatchNoList.size();i++){
				System.out.println("Id: "+text_MerchantBatchNoList.get(i).getProperty(".id").toString());			
			}
			text_MerchantBatchNo = (TextGuiTestObject)text_MerchantBatchNoList.get(Math.round(text_MerchantBatchNoList.size()/2));			
			if(text_MerchantBatchNo!= null){
				text_MerchantBatchNo.waitForExistence(10, 2);
				System.out.println("text_MerchantBatchNo.getProperty: "+text_MerchantBatchNo.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_MerchantBatchNo.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Merchant Batch Number textbox is disabled in View Transaction Details Page");					
				}
				else if(text_MerchantBatchNo.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside merchant batch number");					
					text_MerchantBatchNo.click();
					text_MerchantBatchNo.setText(merchantBatchNo);
					sleep(1);
				}//End of Checking whether readonly or not				
			}
			else{
				System.out.println("Merchant Batch Number textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Merchant Batch Number textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Auth Code text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_AuthCodeList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "authorizationCode");
			TextGuiTestObject text_AuthCode = null;
			if(text_AuthCodeList.size()==0){
				System.out.println("Auth Code returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Auth Code returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			for(int i=0;i<text_AuthCodeList.size();i++){
				System.out.println("Id: "+text_AuthCodeList.get(i).getProperty(".id").toString());			
			}
			text_AuthCode = (TextGuiTestObject)text_AuthCodeList.get(Math.round(text_AuthCodeList.size()/2));			
			if(text_AuthCode!= null){
				text_AuthCode.waitForExistence(10, 2);
				System.out.println("text_AuthCode.getProperty: "+text_AuthCode.getProperty(".readOnly").toString());
				//Checking whether read only or not
				if(text_AuthCode.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Auth Code textbox is disabled in View Transaction Details Page");					
				}
				else if(text_AuthCode.getProperty(".readOnly").toString().equalsIgnoreCase("false")){
					System.out.println("Inside Txn Amount");					
					text_AuthCode.click();
					text_AuthCode.setText(authCode);
					sleep(1);
				}//End of Checking whether read-only or not				
			}
			else{
				System.out.println("Auth Code textbox is absent in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Auth Code textbox is absent in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			
			//Selecting Charge Type in the View Transaction Details page			
			TextGuiTestObject text_ChargeType = (TextGuiTestObject)Util.getMappedObject("Html.INPUT.text", ".id", "lodgingChargeType-input");
			if(text_ChargeType!= null){
				text_ChargeType.waitForExistence(10, 2);
				//Checking whether read only or not
				if(text_ChargeType.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Charge Type textbox is disabled in View Transaction Details Page");
					
				}
				else{
					text_ChargeType.click();
					text_ChargeType.setText(chargeType);
					sleep(1);
				}//End of Checking whether readonly or not				
			}
			else{
				System.out.println("Charge Type textbox is absent in View Transaction Details Page");
				
			}
			
			//Selecting Charge Description in the View Transaction Details page			
			TextGuiTestObject text_ChargeDesc = (TextGuiTestObject)Util.getMappedObject("Html.INPUT.text", ".id", "lodgingChargeDescription-input");
			if(text_ChargeDesc!= null){
				text_ChargeDesc.waitForExistence(10, 2);
				//Checking whether read only or not
				if(text_ChargeDesc.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Charge Description textbox is disabled in View Transaction Details Page");
					text_ChargeDesc.setProperty(".readOnly", false);
					text_ChargeDesc.click();
					text_ChargeDesc.setText("Health Spa");
					sleep(1);
					text_ChargeDesc.setProperty(".readOnly", true);
					System.out.println("text_ChargeDesc.getProperty: "+text_ChargeDesc.getProperty(".readOnly").toString());				
				}
				else{
					text_ChargeDesc.click();
					text_ChargeDesc.setText(chargeDesc);
					sleep(1);
				}//End of Checking whether readonly or not				
			}
			else{
				System.out.println("Charge Description textbox is absent in View Transaction Details Page");
				
			}
			
			//Selecting Check In in the View Transaction Details page			
			TextGuiTestObject text_CheckIn = (TextGuiTestObject)Util.getMappedObject("Html.INPUT.text", ".id", "lodgingCheckIn-input");
			if(text_CheckIn!= null){
				text_CheckIn.waitForExistence(10, 2);
				//Checking whether read only or not
				if(text_CheckIn.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Check In field is disabled in View Transaction Details Page");
					
				}
				else{
					text_CheckIn.click();
					text_CheckIn.setText(checkIn);
					sleep(1);
				}//End of Checking whether readonly or not				
			}
			else{
				System.out.println("Check In Field is absent in View Transaction Details Page");
				
			}
			
			//Selecting Check Out in the View Transaction Details page			
			TextGuiTestObject text_CheckOut = (TextGuiTestObject)Util.getMappedObject("Html.INPUT.text", ".id", "lodgingCheckOut-input");
			if(text_CheckOut!= null){
				text_CheckOut.waitForExistence(10, 2);
				//Checking whether read only or not
				if(text_CheckOut.getProperty(".readOnly").toString().equalsIgnoreCase("true")){
					System.out.println("Check Out field is disabled in View Transaction Details Page");
										
				}
				else{
					text_CheckOut.click();
					text_CheckOut.setText(checkOut);
					sleep(1);
				}//End of Checking whether readonly or not				
			}
			else{
				System.out.println("Check Out Field is absent in View Transaction Details Page");
				
			}
			
		}
		else{
			System.out.println("Basic Transaction Tab is absent in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Basic Transaction Tab is absent in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		//End of Selecting Basic Txn tab
		
		//Selecting Expanded Detail tab	
		ArrayList<GuiTestObject> link_ExpandDetList = Util.getGWTMappedObjects("Html.A", ".text", "Expanded Detail");
		GuiTestObject link_ExpandDet = null;
		if(link_ExpandDetList.size()==0){
			System.out.println("Expanded Detail Tab returns nil in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Expanded Detail Tab returns nil in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		link_ExpandDet = link_ExpandDetList.get(link_ExpandDetList.size()-1);		
		if(link_ExpandDet!= null){
			link_ExpandDet.waitForExistence(10, 2);
			link_ExpandDet.ensureObjectIsVisible();
			link_ExpandDet.click();
			sleep(5);			
		}
		else{
			System.out.println("Expanded Detail Tab is absent in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Expanded Detail Tab is absent in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		//End of Selecting Expanded Detail tab
		
		//Selecting Customer tab
		ArrayList<GuiTestObject> link_CustomerList = Util.getGWTMappedObjects("Html.A", ".text", "Customer");
		GuiTestObject link_Customer = null;
		if(link_CustomerList.size()==0){
			System.out.println("Customer Tab returns nil in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Customer Tab returns nil in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		link_Customer = link_CustomerList.get(link_CustomerList.size()-1);		
		if(link_Customer!= null){
			link_Customer.waitForExistence(10, 2);
			link_Customer.ensureObjectIsVisible();
			link_Customer.click();
			sleep(5);
			
		}
		else{
			System.out.println("Customer Tab is absent in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Customer Tab is absent in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		//End of Selecting Customer tab
		
		//Selecting Compliance tab	
		ArrayList<GuiTestObject> link_ComplianceList = Util.getGWTMappedObjects("Html.A", ".text", "Compliance");
		GuiTestObject link_Compliance = null;
		if(link_ComplianceList.size()==0){
			System.out.println("Compliance Tab returns nil in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Compliance Tab returns nil in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		link_Compliance = link_ComplianceList.get(link_ComplianceList.size()-1);		
		if(link_Compliance!= null){
			link_Compliance.waitForExistence(10, 2);
			link_Compliance.ensureObjectIsVisible();
			link_Compliance.click();
			sleep(5);
			//Selecting Transaction Id text in the View Transaction Details page	
			ArrayList<GuiTestObject> text_TxnIdList = Util.getGWTMappedObjects("Html.INPUT.text", ".name", "transactionId");
			System.out.println("text_TxnIdList Size: "+text_TxnIdList.size());
			TextGuiTestObject text_TxnId = null;
			if(text_TxnIdList.size()==0){
				System.out.println("Transaction Id returns nil in View Transaction Details Page");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Transaction Id returns nil in View Transaction Details Page", Status.BC_FAILED);
				return;
			}
			else if(text_TxnIdList.size()==1){
				for(int i=0;i<text_TxnIdList.size();i++){
					System.out.println("Id: "+text_TxnIdList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_TxnIdList.get(i).getProperty(".value").toString());
				}
				text_TxnId = (TextGuiTestObject)text_TxnIdList.get(text_TxnIdList.size()-1);			
				if(text_TxnId!= null){
					text_TxnId.waitForExistence(10, 2);
					System.out.println("text_TxnId.getProperty: "+text_TxnId.getProperty(".value").toString().trim());
					txnId = text_TxnId.getProperty(".value").toString().trim();					
				}
				else{
					System.out.println("Transaction Id textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction Id textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			else{
				for(int i=0;i<text_TxnIdList.size();i++){
					System.out.println("Id: "+text_TxnIdList.get(i).getProperty(".id").toString());			
					System.out.println("Value: "+text_TxnIdList.get(i).getProperty(".value").toString());
				}
				text_TxnId = (TextGuiTestObject)text_TxnIdList.get(Math.round(text_TxnIdList.size()/2)-1);			
				if(text_TxnId!= null){
					text_TxnId.waitForExistence(10, 2);
					System.out.println("text_TxnId.getProperty: "+text_TxnId.getProperty(".value").toString().trim());
					txnId = text_TxnId.getProperty(".value").toString().trim();					
				}
				else{
					System.out.println("Transaction Id textbox is absent in View Transaction Details Page");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Transaction Id textbox is absent in View Transaction Details Page", Status.BC_FAILED);
					return;
				}
			}
			
			
			
		}
		else{
			System.out.println("Compliance Tab is absent in View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Compliance Tab is absent in View Transaction Details Page", Status.BC_FAILED);
			return;
		}
		//End of Selecting Compliance tab
		
		//Selecting Basic Transaction Tab again
		link_BasicTxn.click();
		sleep(15);
		
		
		
		//Selecting the Submit button on View Transaction Details Page	
		GuiTestObject button_Submit = Util.getMappedObject("Html.BUTTON", ".value", "Submit");
		if(button_Submit!=null){
			button_Submit.click();	
			sleep(5);
			//Searching for the error in update message 
			String msg_EditError = "The following errors were found";
			GuiTestObject msg_EditErrorFound = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_EditError);
			if(msg_EditErrorFound!=null
					&& msg_EditErrorFound.exists()){
				System.out.println("Error found during updation of Transaction");
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName,"Error found during updation of Transaction" , Status.BC_FAILED);
				return;						
			}
			else{
				System.out.println("Txn edit continued");
				
				//Checking for the existence of the submit confirmation pop up		
				GuiTestObject popup_SubmitConfirm = Util.getMappedObject("Html.SPAN", ".text", "Confirm Action");
				if(popup_SubmitConfirm==null){			
					System.out.println("Submit confirmation pop up not present");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Submit confirmation pop up not present", Status.BC_FAILED);
					return;			
				}
				else{
					System.out.println("Submit confirmation pop up is present");	
					popup_SubmitConfirm.waitForExistence(30, 2);
					
					//Selecting the Cancel button on the confirmation pop up 		
					ArrayList<GuiTestObject> button_ConfirmCancelList = Util.getGWTMappedObjects("Html.BUTTON", ".value", "Cancel");
					GuiTestObject button_ConfirmCancel = null;
					if(button_ConfirmCancelList.size()==0){			
						System.out.println("Cancel button could not be found on submit confirmation pop up");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Cancel button could not be found on submit confirmation pop up", Status.BC_FAILED);
						return;			
					}
					button_ConfirmCancel = button_ConfirmCancelList.get(button_ConfirmCancelList.size()-1);
					if(button_ConfirmCancel!=null){
						System.out.println("Cancel button present on submit confirmation pop up");
						button_ConfirmCancel.click();	
						sleep(5);
					}
					else{
						System.out.println("Cancel button not present on submit confirmation pop up");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Cancel button not present on submit confirmation pop up", Status.BC_FAILED);
						return;
					}//End of Cancel button on the confirmation pop up
					
					button_Submit.click();
					popup_SubmitConfirm.waitForExistence(30, 2);
					
					//Selecting the Confirm button on the confirmation pop up 		
					GuiTestObject button_Confirm = Util.getMappedObject("Html.BUTTON", ".value", "Confirm");
					if(button_Confirm!=null){
						System.out.println("Confirm button present on submit confirmation pop up");
						button_Confirm.click();	
						sleep(20);
					}
					else{
						System.out.println("Confirm button not present on submit confirmation pop up");
						error = true;
						Util.scenarioStatus = false;
						CRAFT_Report.LogInfo(tsComponentName, "Mandatory field(s) Confirm button not present on submit confirmation pop up", Status.BC_FAILED);
						return;
					}//End of Confirm button on the confirmation pop up
					
				}//End of existence of the submit confirmation pop up check
				
				//Searching for the successful edit message 
				String msg_EditString = "The Selected Transaction Was Edited Successfully";
				GuiTestObject msg_TxnEditSuccess = (GuiTestObject)Util.getMappedObject("Html.DIV", ".text", msg_EditString);
				if(msg_TxnEditSuccess!=null){
					msg_TxnEditSuccess.waitForExistence(30, 2);
					System.out.println("Transaction Edited successfully");							
				}
				else{
					System.out.println("Transaction Edit is unsuccessful");
					error = true;
					Util.scenarioStatus = false;
					CRAFT_Report.LogInfo(tsComponentName,"Transaction Edit is unsuccessful" , Status.BC_FAILED);
					return;
				}//End of searching for the successful edit message
			
			}//End of Searching for the error in update message
			
			//Selecting the cancel button
			button_EditCancel.click();
			//Waiting for the view transaction details page to be displayed and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The view transaction details page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The view transaction details page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The view transaction details page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(5);			
			link_BasicTxn.waitForExistence(20, 2);
			
		}
		else{
			System.out.println("Submit button not present on View Transaction Details Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Mandatory button(s) Submit button not present on View Transaction Details Page", Status.BC_FAILED);
			return;
		}//End of Submit button on View Transaction Details Page
		
		//Returning to the home tab as an exit point
		if(link_home().exists()
				|| link_home().ensureObjectIsVisible()){
			link_home().waitForExistence(20, 2);
			link_home().click();
			//Waiting for the Home page to be displayed and loading message to disappear
			for(int loop=0;loop<20;loop++){
				ArrayList<GuiTestObject> progressBar_LoadingList = Util.getGWTMappedObjects("Html.DIV", ".text", "Please wait Loading items...");
				System.out.println("progressBar_LoadingList size: "+progressBar_LoadingList.size());
				if(progressBar_LoadingList.size()>=1){
					for(int i=0;i<progressBar_LoadingList.size();i++){
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".id").toString());
						System.out.println("Field values: "+progressBar_LoadingList.get(i).getProperty(".text").toString());
					}
					GuiTestObject progressBar_Loading = progressBar_LoadingList.get(progressBar_LoadingList.size()-1);				
					System.out.println("Progressbar checking loopcount: "+loop);
					if(progressBar_Loading!=null){
						System.out.println("The Home page is still NOT populated");
						sleep(2);
						continue;					
					}
					else{
						System.out.println("The Home page is populated");
						break;
					}
				}//End of if for progress bar loading
				else{
					System.out.println("The Home page is populated");
					break;
				}//End of else for progress bar loading
				
			}//End of for statement to check the progress bar loading 
			
			sleep(2);
			//Checking the existence of refresh button at the welcome area on home page				
			GuiTestObject button_RefreshAtHome = (GuiTestObject)Util.getMappedObject("Html.BUTTON", ".text", "Refresh");
			if(button_RefreshAtHome!= null){
				button_RefreshAtHome.waitForExistence(20, 2);
				button_RefreshAtHome.ensureObjectIsVisible();
			}
			else{
				error = true;
				Util.scenarioStatus = false;
				CRAFT_Report.LogInfo(tsComponentName, "Refresh button is absent in home page", Status.BC_FAILED);
				return;
			}
			sleep(10);
		}
		else{
			System.out.println("Home tab is absent in View Transaction Detail Page");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Home tab is absent in View Transaction Detail Page", Status.BC_FAILED);
			return;
		}//End of returning to the home tab as an exit point
	
		
		//Component success message
		String cmpSuccessMsg = "Selected Transaction with Id: "+txnId+" :have been Edited successfully";
		CRAFT_Report.LogInfo(BusinessComponentName, cmpSuccessMsg, Status.BC_PASSED);
		
		}
		catch(Exception e){			
			StackTraceElement[] sArr = e.getStackTrace();
			System.out.println(sArr[0]);			
			e.getMessage();			
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo("Unhandled Exception occurred on Business Component: "+this.getScriptName(),e.toString(),Status.BC_FAILED);
			
		}

	}//End of Execute Component
	
}//End of class

