

import java.net.InetAddress;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import org.eclipse.hyades.edit.datapool.IDatapool;
import org.eclipse.hyades.execution.runtime.datapool.IDatapoolRecord;


import resources.UnitTest_Script2Helper;
import sun.misc.Resource;
import SupportLibraries.CRAFT_DB;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.Util;
import SupportLibraries.CRAFT_Report.Status;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
/**
 * Description   : Functional Test Script
 * @author sxsouvi
 *� 2011, Cognizant Technology Solutions. All Rights Reserved. The information contained herein is subject to change without notice.
 */
public class UnitTest_Script2 extends UnitTest_Script2Helper
{	
	/**
	 * Script Name   : <b>UnitTest_Script2</b>
	 * Generated     : <b>Sep 14, 2011 3:46:10 AM</b>
	 * Subject   	 : 
	 * Test Purpose  : 
	 * /Requirement(s)
	 * Covered
	 * Original Host : WinXP Version2002 Service Pack 3
	 * Assumption(s) : 
	 * @since  2011/09/14
	 * @author sxsouvi
	 */
	

	boolean error = false;	
	//Enter business component
	String BusinessComponentName = this.getClass().getName();
	String tsComponentName = "ReverseTPPSubBatch";
	
	public void testMain(Object[] args) throws Exception 
	{
//		String tsComponentName = "CNFECloneTxn";
		//--------------------------------------------------------------------------------------
//		String dbPath = "C:\\Documents and Settings\\axbane1.NA\\Desktop\\Elavon\\Track-MICR_Data_VM_Test_RFIDs-2.xlsx";
//		String sheetName = "Sheet1";
//		CRAFT_DB.initialize(dbPath, sheetName);
//		String query = "select * from ["+sheetName+"$]";
//		System.out.println(CRAFT_DB.executequery(query, dbPath).getRow());
		
		
		
		// HTML Browser
		// Document: Login - Jazz Team Server: https://kpqatapp01.nova.prv:9443/jazz/web/console/Fusebox#action=com.ibm.rqm.planning.home.actionDispatcher&subAction=viewUserHome
//		text_j_username().click(atPoint(69,12));
//		browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).inputChars("test");
//		text_j_password().click(atPoint(49,8));
//		browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).inputChars("test");
		
//		text_username().setText("mxbane1");
		
//		System.out.println("EXISTS: "+browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).exists());
//		System.out.println("HAS FOCUS: "+browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).hasFocus());
//		
//		if(browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).exists()){
//			browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).minimize();
//		}

//		browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).minimize();
//		text_username().setText("mxbane1");
//		sleep(2);
//		browser_htmlBrowser(document_loginJazzTeamServer(),DEFAULT_FLAGS).maximize();
//		sleep(1);
//		for(int loop=0;loop<100;loop++){
//			System.out.println(browser_htmlBrowser().isShowing());
//			System.out.println(browser_htmlBrowser().activate());
//			System.out.println(browser_htmlBrowser().getProperty(".readyState").toString());		
//			int windowId = browser_htmlBrowser().hasFocus();
		
//		String[] to = new String[1];
//		to[0] = "";
//		callScript("Fusebox_BMUI_TxnAlerts_040",to);
		
//		try {
//			
//			String iterations="All Iterations";
//			String scenarioName = "Fusebox_BMUI_TxnAlerts_040";
////			resetDatatable(scenarioName);
//			Connection con = null;
//		    String val2="TRUE";
//		    String excelPath = Util.homePath+"\\Run Manager.xls";
//		    con = CRAFT_DB.getExcelODBCConnection(excelPath);
////		    System.out.println(con.toString());
//		    Statement stat = con.createStatement();
//			stat = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);				
//		    
////		    String sql3 = "SELECT * FROM [Main$] WHERE [TS ID]='"+scenarioName+"'";
////		    ResultSet rs = stat.executeQuery(sql3);
////		    
////		    while(rs.next()){
//////		    	String runStatus = rs.getString("Run");
//////		    	String iteration = rs.getString("IterationRequired");
////		    	rs.updateString("Run", val2);
//////		    	rs.updateString("IterationRequired", iterations);
////		    	rs.updateRow();
////		    }
////			String sql2 = "INSERT INTO [Main$] ([TS ID],[Run],[IterationRequired]) VALUES('xx',TRUE,'All Iterations')";
////			String sql2 = "DELETE FROM [Main$] WHERE [TS ID]='xx'";
//			String sql2 = "UPDATE [Main$] SET [Run]=TRUE,[IterationRequired]= 'All Iterations' WHERE [TS ID]='"+scenarioName+"'";
//			stat.executeUpdate(sql2);
//			stat.close();
//            con.close();
//			
//		} catch (SQLException Ex) {
//			System.out.println(Ex.getMessage());
//			logError(Ex.getMessage());
//		}

//		while(!dpDone()){
//			if(dpString("Run").equalsIgnoreCase("false")){
//				dpNext();
//			}
//			else{
//				System.out.println(dpString("TS ID"));
//			}
//			System.out.println("Before dpNext()");
//			dpNext();
//		}
		
		//Searching fee details pop up
		ArrayList<GuiTestObject> popup_FeedetailsList = Util.getGWTMappedObjects("Html.DIV", ".text", "Fee Details");
		GuiTestObject popup_Feedetails = null;
		System.out.println("popup_FeedetailsList sizes: "+popup_FeedetailsList.size());
//		for(int loop=0;loop<popup_FeedetailsList.size();loop++){
//			System.out.println("popup_FeedetailsList Value: "+popup_FeedetailsList.get(loop).getProperty(".id").toString());
//		}
		if(popup_FeedetailsList.size()>0){
			popup_Feedetails = popup_FeedetailsList.get(popup_FeedetailsList.size()-1);
		}
		
		if(popup_Feedetails!= null){
			popup_Feedetails.waitForExistence(10, 2);
			System.out.println("Fee details pop-up appeared correctly");
			sleep(2);		
		}
		else{
			System.out.println("Fee details pop-up did not appear");
			error = true;
			Util.scenarioStatus = false;
			CRAFT_Report.LogInfo(tsComponentName, "Fee details pop-up did not appear", Status.BC_FAILED);
			return;
		}
		
		
		
		
		
		




		
}
	

}
